package Model;

import java.util.Date;

public class Visita
{
    public Utente visitatore;
    public Pagina paginaVisitata;
    public Integer recensione = 3;
    public Date dataVisita;
    public Visita(Utente utente, Pagina daVisitare)
    {
        paginaVisitata = daVisitare;
        visitatore = utente;
        dataVisita = new Date();
    }
}
