package Model;

public class Utente {

    private int id;

    public Utente(int id)
    {
        this.id = id;
    }
    public int ottieniIdUtente()
    {
        return id;
    }
}
