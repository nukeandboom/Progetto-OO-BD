package Controller;

import Model.*;
import ImplementazioneDAO.*;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Controller extends GestioneAnomalia
{
        private static Utente utente;
        private static Autore autoreLoggato;
        private Autore destinatarioTemporaneo;
        private static Pagina paginaTemporanea;
        private static Collegamento collegamentoDaImplementare;
        private String messaggioTemporaneo;

        public void creaUtente()
        {
               ImplementazionePostgresDAO.connectDAO();
               int id = ImplementazionePostgresDAO.nuovoutentedaDB();
               
               ImplementazionePostgresDAO.connectDAO();
               ImplementazionePostgresDAO.confermaNuovoIdUtenteDB(id);

               utente = new Utente(id);
        }

        public  void scartaUtenteInUso()
        {
                utente = null;
        }

        public  boolean accessoAutore(String username, String password)
        {
                ImplementazionePostgresDAO.connectDAO();
                boolean check = ImplementazionePostgresDAO.confermacredenzialiDB(username,password);

                if(!check)
                        return false;


                return check;
        }

        public static void caricaAutoreLoggato(String username, String password,Date dataIscrizione, int punteggio){

                autoreLoggato = new Autore(username,password,dataIscrizione,punteggio);

        }

        public  boolean creaAutore(String username, String password)
        {
                if(!determinaAnomalie(new String[]{username,null},0))
                        return false;

                if(!determinaAnomalie(new String[]{password,null},0))
                        return false;

                if(username.isBlank())
                        return false;

                if(password.isBlank())
                        return false;

                Date dataAttuale = new Date(System.currentTimeMillis());

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.caricaNuovoAutoreSulDB(username, password,dataAttuale );

                autoreLoggato = new Autore(username, password, dataAttuale, 0);

                return true;
        }

        public static void impostaPaginaTemporanea(String titolo, String nomeAutore){

                Controller.paginaTemporanea =  new Pagina(titolo,nomeAutore);

        }

        public void svuotaDatiPaginaTemporanea(){

                paginaTemporanea = null;
                destinatarioTemporaneo = null;
        }

        public  HashMap<String, HashMap<Integer, ArrayList<String[]>>>  ottieniInfoNotifiche()
        {

                ArrayList<String> titoliPagine =  ImplementazionePostgresDAO.ottieniListaNomiPagineSoggetteAProposte(autoreLoggato.ottieniUsername());

                HashMap<String,HashMap<Integer,ArrayList<String[]>>> hashMapNotifiche = new HashMap<>();
                HashMap<Integer,ArrayList<String[]>> hashMapIndiciParagrafi;

                for(String str : titoliPagine)
                {
                        hashMapIndiciParagrafi = ImplementazionePostgresDAO.ottieniHashMapIndiceParagrafiInAttesa(str);
                        hashMapNotifiche.put(str, hashMapIndiciParagrafi);
                }

                return hashMapNotifiche;
        }

        public void implementaParagrafoInPagina(String contenuto)
        {
                LocalDate dateCorrente = LocalDate.now();
                LocalTime orarioCorrente = LocalTime.now();
                java.sql.Date sqlData = java.sql.Date.valueOf(dateCorrente);
                Time sqlTime = Time.valueOf(orarioCorrente);


                Paragrafo p = new Paragrafo(contenuto,paginaTemporanea.ottieniTesto().size(),paginaTemporanea,sqlData,sqlTime);

                String statoDiParagrafo = "in attesa";

                if(autoreLoggato.ottieniUsername().equals(paginaTemporanea.ottieniSoloNomeAutore())){

                        statoDiParagrafo = "accettato";
                }


                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.caricaParagrafoSulDB(contenuto,paginaTemporanea.ottieniTesto().size(),paginaTemporanea.ottieniTitolo(),sqlData,sqlTime,statoDiParagrafo);


                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.caricaPropostaSulDB(autoreLoggato.ottieniUsername(),paginaTemporanea.ottieniTesto().size(),paginaTemporanea.ottieniTitolo(),sqlData,sqlTime);


                if(collegamentoDaImplementare != null){
                        ImplementazionePostgresDAO.connectDAO();
                        ImplementazionePostgresDAO.caricaCollegamentoSulDB(collegamentoDaImplementare.ottieniTitoloPaginaCorrente(),
                                collegamentoDaImplementare.ottieniTitoloPaginaDiDestinazione(),
                                paginaTemporanea.ottieniTesto().size(),
                                sqlData,
                                sqlTime);

                }

                paginaTemporanea.ottieniTesto().add(p);

                svuotaCollegamentoTemporaneo();
                impostaMessaggioTemporaneo(null);
        }




        public  HashMap<Integer, ArrayList<Paragrafo>> ottieniStorico( Pagina paginaDiRiferimento)
        {
                // richiedi al database (da fare nel model)
                HashMap<Integer, ArrayList<Paragrafo>> storico  = paginaDiRiferimento.ottieniStoricoPagina();
                return storico ;
        }

        public void memorizzaPaginaTemporaneaSulDB()
        {
                LocalDate currentDate = LocalDate.now();
                java.sql.Date sqlData = java.sql.Date.valueOf(currentDate);

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.memorizzaPaginaSulDB(paginaTemporanea.ottieniTitolo(),sqlData,autoreLoggato.ottieniUsername());
        }

        public void caricaDatiSuPaginaTemporanea(String titoloPaginaDiRiferimento, String proprietario)
        {
                paginaTemporanea = new Pagina(titoloPaginaDiRiferimento,proprietario);
                destinatarioTemporaneo = paginaTemporanea.ottieniAutore();
        }

        public  boolean controllaEsistenzaPaginaSulDB(String titoloPagina)
        {
                if(titoloPagina == null)
                        return false;

                if(titoloPagina.isBlank())
                        return false;

                ImplementazionePostgresDAO.connectDAO();
                boolean check =  ImplementazionePostgresDAO.ottieniInfoGeneraliPagina(titoloPagina);

                return check;
        }

        public boolean ottieniPaginaDalDB(String titoloPagina)
        {
                if(titoloPagina == null)
                        return false;

                if(titoloPagina.isBlank())
                        return false;

                ImplementazionePostgresDAO.connectDAO();
                boolean check =  ImplementazionePostgresDAO.ottieniInfoGeneraliPagina(titoloPagina);

                if(check == true){
                ottieniTestoDiunaPagina(paginaTemporanea.ottieniTitolo());}

                return check;
        }

        public void ottieniTestoDiunaPagina(String titoloPagina)
        {

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.raccogliTesto(titoloPagina,paginaTemporanea.ottieniTitolo());

        }

        public static void aggiungiParagrafoaPaginaTemporanea(String contenuto, int posizione, Date data, Time orario){


                Paragrafo p = new Paragrafo(contenuto,posizione,paginaTemporanea,data,orario);
                paginaTemporanea.ottieniTesto().add(p);

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.cercaCollegamentisuDB(posizione,paginaTemporanea.ottieniTitolo(),data,orario);

                if(collegamentoDaImplementare != null){

                        p.impostaCollegamento(collegamentoDaImplementare);
                        svuotaCollegamentoTemporaneo();
                }

        }

        public static void creaCollegamentoTemporaneo(String titolopagPartenza, String titolopagDestinazione){

                collegamentoDaImplementare = new Collegamento(titolopagPartenza,titolopagDestinazione);

        }

        public void salvaValutazioneEVisita(int Valutazione)
        {
                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.MandaValutazioneEVisita( Valutazione, paginaTemporanea.ottieniTitolo(),utente.ottieniIdUtente());
        }

        public void impostaCollegamentoTemporaneo(String titoloPaginaDiDestinazione){

                collegamentoDaImplementare = new Collegamento(paginaTemporanea.ottieniTitolo(), titoloPaginaDiDestinazione);
        }

        public  HashMap<String,HashMap<Integer,ArrayList<String>>> ottieniListaStorici()
        {
                HashMap<String,HashMap<Integer,ArrayList<String>>> hashMapStorici;
                ArrayList<String> pagineStoriciAccessibili; // Prima cerchiamo i titoli delle pagine ai cui storici l'autore loggato ha accesso.

                ImplementazionePostgresDAO.connectDAO();
                pagineStoriciAccessibili = ImplementazionePostgresDAO.ottieniStoriciAccessibili(autoreLoggato.ottieniUsername());

                autoreLoggato.setStoriciAccessibili(pagineStoriciAccessibili);

                hashMapStorici = ImplementazionePostgresDAO.ottieniStoricoAutore(autoreLoggato.ottieniStoriciAccessibili());

                return hashMapStorici;
        }
        public Autore ottieniAutore()
        {
                return  autoreLoggato;
        }
        public Pagina ottieniPaginaTemporanea(){
                return paginaTemporanea;
        }
        public Collegamento ottieniCollegamentoTemporaneo(){return  collegamentoDaImplementare;}
        public static void svuotaCollegamentoTemporaneo(){
                collegamentoDaImplementare = null;
        }

        public void scartaPagina() {

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.rimuoviPaginaScartataDalDB(paginaTemporanea.ottieniTitolo());
                paginaTemporanea = null;
        }

        public int ottieniPunteggioPagina() {

                ImplementazionePostgresDAO.connectDAO();
               return  ImplementazionePostgresDAO.ottieniPunteggioPagina(paginaTemporanea.ottieniTitolo());
        }

        public String elaboraCodiceHtml() {

                String stringHTML = "<html>";

                for (Paragrafo par : paginaTemporanea.ottieniTesto())
                {
                        if (par.ottienicollegamento() != null)
                        {
                                // Se il paragrafo possiede un collegamneto,
                                // allora viene creato un hypertext, il quale
                                //  consente la visualizzazione di un' altra pagina se cliccato.

                                stringHTML += "<a href = \"";
                                stringHTML += par.ottienicollegamento().ottieniTitoloPaginaDiDestinazione();
                                stringHTML += "\">";
                                stringHTML += par.ottieniContenuto();
                                stringHTML += "</a>";

                        } else {

                                stringHTML += "<p style=\"background-color:White;\">";
                                stringHTML += par.ottieniContenuto();
                                stringHTML += "</p>";

                        }
                }

                stringHTML += "</html>";

                return stringHTML;
        }


        public String ottieniMessaggioTemporaneo()
        {
                return messaggioTemporaneo;
        }

        public void impostaMessaggioTemporaneo(String messaggio)
        {
                messaggioTemporaneo = messaggio;
        }

        public void aggiornaNotificheAutore(String chiavePagina, int indiceParagrafo)
        {
                autoreLoggato.ottieniProposteInAttesa().get(chiavePagina).remove(indiceParagrafo);
        }


        public void implementaParagrafoInPaginaEsistente(String chiavePagina,int indiceParagrafo,int indiceVoci) {


                Paragrafo paragrafoInAccettazione = autoreLoggato.ottieniProposteInAttesa().get(chiavePagina).get(indiceParagrafo).get(indiceVoci);

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.confermaParagrafoSulDB(paragrafoInAccettazione.ottieniPosizione(),paragrafoInAccettazione.ottieniData(),paragrafoInAccettazione.ottieniOrario(),chiavePagina);
        }


        public ArrayList<String> ottieniListaPagineStorico() {

                return autoreLoggato.ottieniStoriciAccessibili();
        }
}
