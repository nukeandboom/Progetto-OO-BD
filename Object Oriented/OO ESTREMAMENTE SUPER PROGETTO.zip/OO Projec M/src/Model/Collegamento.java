package Model;

public class Collegamento extends GestioneAnomalia
{
    private String titoloPaginaCorrente;
    private String titoloPaginaDiDestinazione;

    public Collegamento(String titoloPaginaCorrente, String titoloPaginaDiDestinazione)
    {
        this.titoloPaginaCorrente = titoloPaginaCorrente;
        this.titoloPaginaDiDestinazione = titoloPaginaDiDestinazione;
    }

    public String ottieniTitoloPaginaCorrente(){return titoloPaginaCorrente;}

    public String ottieniTitoloPaginaDiDestinazione(){return titoloPaginaDiDestinazione;}
}
