package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Autore extends GestioneAnomalia
{
    private final String username;
    private final Date dataIscrizione;
    private final String password;
    private int punteggio = 0;
    private ArrayList<String> pagScritte = new ArrayList<>();
    private ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
    private ArrayList<String> storiciAccessibili = new ArrayList<>();
    private HashMap<String, HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password, Date dataIscrizione, int punteggio)
    {
        this.username = username;
        this.password = password;
        this.dataIscrizione = dataIscrizione;
        this.punteggio = punteggio;
    }

    public String ottieniUsername(){return username;}

    public Date ottienidataIscrizione(){return dataIscrizione;}

    public String ottieniPassword(){return password;}

    public int ottieniPunteggio(){return punteggio;}

    public ArrayList<String> ottieniPagScritte() {
        return pagScritte;
    }

    public ArrayList<Paragrafo> ottieniParagrafiScritti() {
        return paragrafiScritti;
    }

    public ArrayList<String> ottieniStoriciAccessibili(){
        return storiciAccessibili;
    }

    public void setStoriciAccessibili(ArrayList<String> listaTitoliPagine){
        this.storiciAccessibili = listaTitoliPagine;
    }

    public HashMap<String, HashMap<Integer, ArrayList<Paragrafo>>> ottieniProposteInAttesa() {
        return proposteInAttesa;
    }
}