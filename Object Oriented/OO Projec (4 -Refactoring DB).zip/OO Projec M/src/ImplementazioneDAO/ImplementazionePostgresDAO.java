package ImplementazioneDAO;

import Database.ConnessioneDatabase;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class ImplementazionePostgresDAO {

    private static Connection connection;
    private static final String INSERT_USERS_SQL = "INSERT INTO utente" + "(idutente) VALUES " + " (?);";
    private static final String GET_PAGINA_SQL = "SELECT * FROM pagina  WHERE titolo = ? ";
    private static final String POPULATE_TEXT_PAGINA_VISITATA = "SELECT * FROM paragrafo WHERE titolopag = ? AND stato = 'accettato' ";
    private static final String SEARCH_COLLEGAMENTO = "SELECT titolopag_destinazione FROM collegamento WHERE titolopag_origin = ? AND data_origin = ?  AND posizione_origin = ? AND orario_origin = ?";
    private static final String INSERT_NEW_AUTHOR_SQL = "INSERT INTO autore " + "(username,password,data_iscrizione,punteggio) VALUES" + "(?,?,?,?)";
    private static final String INSERT_NEW_VISITandVALUTATION_SQL = "INSERT INTO visita " + "(idutente_in_visita,data_visita,valutazione,titolo_pagina_visitata) VALUES" + "(?,?,?,?)";


    //private static final String GET_AUTORE_PROPRIETARIO = "SELECT username, password, data_iscrizione, punteggio FROM pagina JOIN paragrafo WHERE titolo = ? ORDER BY posizione ASC ";

    //private static final String GET_PAGINE_FROMDB = "SELECT * FROM \"pagina\"";

    //private static final String LOAD_AUTORI_FROM_DB = "SELECT * FROM \"autore\"";

    public  static void connectDAO() {
        try {
            connection = ConnessioneDatabase.getInstance().connection;
            System.out.println("Istanza avviata");
        } catch (SQLException e) {
            System.out.println("Errore connessione al database " + e.getMessage());
        }

    }

    public static int nuovoutentedaDB()
    {
        int last_user_value = 0;

        try {

            Statement leggiutentiPS = connection.createStatement
                    (ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = leggiutentiPS.executeQuery("SELECT * FROM \"utente\"");

            while (rs.next())
            {
                last_user_value = rs.getInt("idutente");
            }

            System.out.println("ultimo utente = " + (last_user_value + 1));

            rs.close();
            leggiutentiPS.close();
            connection.close();
        } catch (Exception e) {
            System.out.println("Errore lettura utenti " + e.getMessage());
        }

        return last_user_value + 1;
    }

    public static void confermaNuovoIdUtenteDB(int id){

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL))
        {
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            e.getMessage();
        }

    }

    public  static boolean confermacredenzialiDB(String username,String password){

        boolean check = false;

        try {PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM autore WHERE username =?  AND password = ?");

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {

                System.out.println("Trovata corrispondenza nel database");
                check = true;
            }else
                System.out.println("Nessun account corrispondente");

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            e.getMessage();
        }

        return check;
    }


    public static void ottieniInfoAutoreEsistente(String username, String password, java.util.Date dataCreazione, int punteggio){

        try {

            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM autore WHERE username = ? AND password = ?");

            preparedStatement.setString(1,username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            username = resultSet.getString("username");
            password = resultSet.getString("password");
            Date dataDaConvertire = resultSet.getDate("data_iscrizione");
            dataCreazione = new java.util.Date(dataDaConvertire.getTime());
            punteggio = resultSet.getInt("punteggio");

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){
            e.getMessage();
        }
    }

    public static boolean ottieniInfoGeneraliPagina(String titoloPagina, String nomeAutore) {

       try {

           PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINA_SQL);

           preparedStatement.setString(1, titoloPagina);

           ResultSet resultSet = preparedStatement.executeQuery();

           resultSet.next();
           nomeAutore = resultSet.getString(3);

           resultSet.close();
           preparedStatement.close();
           connection.close();

       }catch (SQLException e){
          return false;
       }

       if(nomeAutore == null)
           return false;

       return true;
    }

    public static int ottieniPunteggioPagina(String titolo) {


        // X Matt, qui serve recuperare il punteggio di una pagina

        int punteggio = 0;

        return punteggio;
    }
     public static void aumentaPunteggioAutore(String mittente)
     {
         // X MAtt, si ricerca l'autore tramite nome e si aumenta il punteggio di +1
     }

     public static void caricaPropostaNelDB(String contenuto, String collegamentoPagAttuale, String collegamentoPagArrivo, int posizione, String pagina, String mittente)
     {
         // X Matt, qui viene caricata la proposta come notifica

         // controlla se il mittente è il proprietario

         // inoltre si deve mettere lo stato accettato se mittente  è il proprietario
     }

    public static void caricaParagrafoSulDB(String contenuto, String collegamentoPagAttuale, String collegamentoPagArrivo, int posizione, String pagina, String mittente) {

        // X Matt carica paragrafo sul db

    }

     public static ArrayList<Pagina> ottieniStoricoAutore(Autore autore)
     {
         // X Matt, qui serve un pizzico della tua magia da elfo birmano per trovare le pagine a cui è associato lo storico;
         // ti ricordo che nello storico ci sono tutte le pagine che ha scritto ed a cui lui ha contribuito con una proposta

         return null; //da modificare
     }

     public static ArrayList<String> ottieniListaNomiPagineSoggetteAProposte()
     {
         ArrayList<String> titoliPagine = new ArrayList<>();

         // X Matt, qui servirebbe una lista di titoli di pagine che HANNO PROPOSTE

         return  titoliPagine;
     }

     public static  HashMap<Integer,ArrayList<String[]>> ottieniHashMapIndiceParagrafiInAttesa(String titoloPagina)
     {
         // X MATT, qui credo che serva cercare la pagina (magari puoi usare la funzione ottieniInfoGeneraliPagina() )
         // e ritornare tutti i paragrafi in attesa dentro un arraylist
         // E' INDISPENSABILE CHE I PARAGRAFI ABBIANO AL LORO INTERNO INDICATO IL NOME DEL PROPRIETARIO


         HashMap<Integer,ArrayList<String[]>>  hashMapTemporanea = new HashMap<>();

         //esempio popolamento hashmap
         //hashMapTemporanea.get(0).add(new String[]{"ciao", "bob", "pagAttuale","pagDestinazione"});

         return hashMapTemporanea;
     }

     public static void eliminaProposteInerentiAdUnParagrafo(String pagina, int indiceParagrafo)
     {
         // X MATT, qui sto considerando che il paragrafo accettato dall'autore sia già
         // stato rimosso dalla lista delle notifiche e che siano rimaste solo quelle da eliminare

         // IMPORTANTE: SI DEVE SETTARE LO STATO DELLE PROPOSTE COME RIFIUTATO
     }

     public static void rimuoviPaginaScartataDalDB(String paginaDaScartare)
     {
         // X Matt, qui serve eliminare la pagina che è stata scartata durante la creazione con paragrafi annessi.
     }

    public static void raccogliTesto(String titolo, ArrayList<String> contenutoParagrafo,  ArrayList<Time> listaOrariCreazioneParagrafi, ArrayList<java.util.Date> listaDateCrezioneParagrafi)
    {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(POPULATE_TEXT_PAGINA_VISITATA);
            preparedStatement.setString(1, titolo);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                String stringaTemp = resultSet.getString("contenuto");
                listaDateCrezioneParagrafi.add(resultSet.getDate("data"));
                listaOrariCreazioneParagrafi.add(resultSet.getTime("orario"));
                contenutoParagrafo.add(stringaTemp);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch(SQLException e){

            System.out.println("Errore nella raccolta del testo" + e.getMessage());
        }
    }

    public static void cercaCollegamentisuDB(int index, String paginaDiRiferifemento, String titoloPaginaDestinazione){

        try {

            PreparedStatement preparedStatement = connection.prepareStatement(SEARCH_COLLEGAMENTO);

            preparedStatement.setString(1, paginaDiRiferifemento);
            preparedStatement.setInt(3, index);

            ResultSet resultSet = preparedStatement.executeQuery();

            while ( resultSet.next() ){

                titoloPaginaDestinazione = resultSet.getString("titolopag_destinazione");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            e.getMessage();
        }
    }


    public static void caricaNuovoAutoreSulDB(String username, String password, java.util.Date dataIscrizione) {

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_AUTHOR_SQL)) {

            Date conversioneData = new java.sql.Date(dataIscrizione.getTime());
            int punteggio = 0;

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setDate(3,conversioneData);
            preparedStatement.setInt(4, punteggio);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            e.getMessage();
        }
    }


    public static void MandaValutazioneEVisita(int valutazione, String TitolopaginaVisitata, int idutente){


        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_VISITandVALUTATION_SQL)){

            LocalDate currentDate = LocalDate.now();
            Date sqlDate = Date.valueOf(currentDate);

            preparedStatement.setInt(1, idutente);
            preparedStatement.setDate(2, sqlDate);
            preparedStatement.setInt(3, valutazione);
            preparedStatement.setString(4,TitolopaginaVisitata);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            e.getMessage();
        }
    }
}
