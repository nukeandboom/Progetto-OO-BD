package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

public class SchermataRevisioneNotifiche extends FunzioniDiSupportoGUI {

    private JPanel pannelloPrincipale;
    private JComboBox selezionaPaginaCbBox;
    private JComboBox indiceParagrafoCbBox;
    private JComboBox indicePropostaCbBox;
    private JTextArea propostaTxArea;
    private JLabel selezionaPaginaLabel;
    private JLabel indiceParagrafoLabel;
    private JLabel indicePropostaLabel;
    private JButton confermaBtn;
    private JButton indietroBtn;
    private JButton rifiutaBtn;
    private JButton impostaCollegamentoBtn;
    private JFrame frameCorrente;
    private boolean statoCollegamentoButton = false;

    public SchermataRevisioneNotifiche(Controller controller, JFrame chiamante) {

        frameCorrente = inizializzaNuovaFinestra("SchermataRevisioneNotifiche", pannelloPrincipale);

        HashMap<String, HashMap<Integer, ArrayList<String[]>>> hashMapParagrafi = controller.ottieniInfoNotifiche();

        // I trattini simboleggiano lo stato di default delle comboBox
        selezionaPaginaCbBox.addItem("---");
        indiceParagrafoCbBox.addItem("---");
        indicePropostaCbBox.addItem("---");


        selezionaPaginaCbBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                // Pulire le opzioni della comboBox ad ogni selezione,
                // previene eventuali errori causati dall'aggiornamento
                // della pagina. Se ciò non accadesse, quando si accetta una proposta,
                // o si rifiutano tutte le proposte, è possibile che alcune voci,
                // che dovrebbero essere eliminate dalle comboBox,
                // rimangano. Tale situazione consentirebbe di cliccare opzioni che
                // dovrebbero essere inesistenti.

                indiceParagrafoCbBox.removeAllItems();
                indiceParagrafoCbBox.addItem("---");

                // da notare che la selezione dell'indice della comboBox viene ridotta di uno,
                // in quanto non si deve tenere conto dell'opzione di default
                if (selezionaPaginaCbBox.getSelectedItem() != selezionaPaginaCbBox.getItemAt(0))
                {
                    String chiave = hashMapParagrafi.values (selezionaPaginaCbBox.getSelectedIndex() - 1);

                    for (int index : hashMapParagrafi.get(chiave).keySet()) {
                        indiceParagrafoCbBox.addItem(String.valueOf(index));
                    }
                }
            }
        });

        indiceParagrafoCbBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                indicePropostaCbBox.removeAllItems();
                indicePropostaCbBox.addItem("---");

                if (indiceParagrafoCbBox.getSelectedItem() != indiceParagrafoCbBox.getItemAt(0)) {

                    String chiave = listaTitoliPagine.get(selezionaPaginaCbBox.getSelectedIndex() - 1);
                    int chiaveParagrafo = indiceParagrafoCbBox.getSelectedIndex() - 1;
                    int numParagrafi = hashMapParagrafi.get(chiave).get(chiaveParagrafo).size();

                    for (int index = 0; index < numParagrafi; index++) {
                        indicePropostaCbBox.addItem(String.valueOf(index));
                    }
                }
            }
        });

        indicePropostaCbBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                if (indicePropostaCbBox.getSelectedItem() != indicePropostaCbBox.getItemAt(0)) {

                    String chiavePagina = listaTitoliPagine.get(selezionaPaginaCbBox.getSelectedIndex() - 1);
                    int chiaveParagrafo = indiceParagrafoCbBox.getSelectedIndex() - 1;
                    int indiceParagrafo = indicePropostaCbBox.getSelectedIndex() - 1;
                    Paragrafo paragrafo = hashMapParagrafi.get(chiavePagina).get(chiaveParagrafo).get(indiceParagrafo);

                    propostaTxArea.setText(paragrafo.ottieniContenuto());
                } else {
                    propostaTxArea.setText(null);
                }
            }
        });

        indietroBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chiudiFinestra(chiamante, frameCorrente);
            }
        });

        confermaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (propostaTxArea.getText().isBlank()) {

                    JOptionPane.showMessageDialog(null, "Nessuna proposta selezionata!",
                            "Revisione notifiche -> Attenzione", JOptionPane.WARNING_MESSAGE);

                    return;
                }

                String chiavePagina = listaTitoliPagine.get(selezionaPaginaCbBox.getSelectedIndex() - 1);
                int chiaveParagrafo = indiceParagrafoCbBox.getSelectedIndex() - 1;
                int indiceParagrafo = indicePropostaCbBox.getSelectedIndex() - 1;
                Paragrafo paragrafo = hashMapParagrafi.get(chiavePagina).get(chiaveParagrafo).get(indiceParagrafo);

                controller.implementaParagrafoInPaginaEsistente(paragrafo, chiaveParagrafo, chiavePagina);
                controller.scartaOgniPropostaDiUnIndice(chiavePagina, chiaveParagrafo);
                hashMapParagrafi.get(chiavePagina).remove(chiaveParagrafo);
            }
        });

        rifiutaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (indiceParagrafoCbBox.getSelectedIndex() == 0) {

                    JOptionPane.showMessageDialog(null, "E' necessario specificare l'indice di un paragrafo, per rifiutare tutte le proposte!",
                            "Revisione notifiche -> Attenzione", JOptionPane.WARNING_MESSAGE);

                    return;
                }

                String chiavePagina = listaTitoliPagine.get(selezionaPaginaCbBox.getSelectedIndex() - 1);
                int chiaveParagrafo = indiceParagrafoCbBox.getSelectedIndex() - 1;

                controller.scartaOgniPropostaDiUnIndice(chiavePagina, chiaveParagrafo);
                hashMapParagrafi.get(chiavePagina).remove(chiaveParagrafo);
            }
        });
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        pannelloPrincipale = new JPanel();
        pannelloPrincipale.setLayout(new GridBagLayout());
        pannelloPrincipale.setBackground(new Color(-14145496));
        pannelloPrincipale.setOpaque(true);
        pannelloPrincipale.setPreferredSize(new Dimension(1200, 720));
        selezionaPaginaCbBox = new JComboBox();
        selezionaPaginaCbBox.setBackground(new Color(-14342875));
        Font selezionaPaginaCbBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, selezionaPaginaCbBox.getFont());
        if (selezionaPaginaCbBoxFont != null) selezionaPaginaCbBox.setFont(selezionaPaginaCbBoxFont);
        selezionaPaginaCbBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        selezionaPaginaCbBox.setModel(defaultComboBoxModel1);
        selezionaPaginaCbBox.setOpaque(true);
        selezionaPaginaCbBox.setPreferredSize(new Dimension(200, 50));
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.1;
        gbc.insets = new Insets(0, 0, 100, 0);
        pannelloPrincipale.add(selezionaPaginaCbBox, gbc);
        indiceParagrafoCbBox = new JComboBox();
        indiceParagrafoCbBox.setBackground(new Color(-14342875));
        Font indiceParagrafoCbBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceParagrafoCbBox.getFont());
        if (indiceParagrafoCbBoxFont != null) indiceParagrafoCbBox.setFont(indiceParagrafoCbBoxFont);
        indiceParagrafoCbBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel2 = new DefaultComboBoxModel();
        indiceParagrafoCbBox.setModel(defaultComboBoxModel2);
        indiceParagrafoCbBox.setOpaque(true);
        indiceParagrafoCbBox.setPreferredSize(new Dimension(200, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridheight = 2;
        gbc.weightx = 0.1;
        gbc.insets = new Insets(0, 0, 100, 0);
        pannelloPrincipale.add(indiceParagrafoCbBox, gbc);
        indicePropostaCbBox = new JComboBox();
        indicePropostaCbBox.setBackground(new Color(-14342875));
        Font indicePropostaCbBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indicePropostaCbBox.getFont());
        if (indicePropostaCbBoxFont != null) indicePropostaCbBox.setFont(indicePropostaCbBoxFont);
        indicePropostaCbBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel3 = new DefaultComboBoxModel();
        indicePropostaCbBox.setModel(defaultComboBoxModel3);
        indicePropostaCbBox.setOpaque(true);
        indicePropostaCbBox.setPreferredSize(new Dimension(200, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridheight = 3;
        gbc.weightx = 0.1;
        gbc.insets = new Insets(0, 0, 100, 0);
        pannelloPrincipale.add(indicePropostaCbBox, gbc);
        propostaTxArea = new JTextArea();
        propostaTxArea.setBackground(new Color(-14342875));
        propostaTxArea.setEditable(false);
        Font propostaTxAreaFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, propostaTxArea.getFont());
        if (propostaTxAreaFont != null) propostaTxArea.setFont(propostaTxAreaFont);
        propostaTxArea.setForeground(new Color(-331531));
        propostaTxArea.setPreferredSize(new Dimension(300, 200));
        propostaTxArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.gridheight = 4;
        gbc.weightx = 0.1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(50, 0, 0, 50);
        pannelloPrincipale.add(propostaTxArea, gbc);
        selezionaPaginaLabel = new JLabel();
        Font selezionaPaginaLabelFont = this.$$$getFont$$$("Monospaced", Font.BOLD, 20, selezionaPaginaLabel.getFont());
        if (selezionaPaginaLabelFont != null) selezionaPaginaLabel.setFont(selezionaPaginaLabelFont);
        selezionaPaginaLabel.setForeground(new Color(-331531));
        selezionaPaginaLabel.setHorizontalAlignment(0);
        selezionaPaginaLabel.setHorizontalTextPosition(0);
        this.$$$loadLabelText$$$(selezionaPaginaLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "seleziona.pagina"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.anchor = GridBagConstraints.SOUTH;
        gbc.insets = new Insets(50, 0, 0, 0);
        pannelloPrincipale.add(selezionaPaginaLabel, gbc);
        indiceParagrafoLabel = new JLabel();
        Font indiceParagrafoLabelFont = this.$$$getFont$$$("Monospaced", Font.BOLD, 20, indiceParagrafoLabel.getFont());
        if (indiceParagrafoLabelFont != null) indiceParagrafoLabel.setFont(indiceParagrafoLabelFont);
        indiceParagrafoLabel.setForeground(new Color(-331531));
        indiceParagrafoLabel.setHorizontalAlignment(0);
        indiceParagrafoLabel.setHorizontalTextPosition(0);
        this.$$$loadLabelText$$$(indiceParagrafoLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "indice.paragrafo"));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.SOUTH;
        gbc.insets = new Insets(50, 0, 0, 0);
        pannelloPrincipale.add(indiceParagrafoLabel, gbc);
        indicePropostaLabel = new JLabel();
        Font indicePropostaLabelFont = this.$$$getFont$$$("Monospaced", Font.BOLD, 20, indicePropostaLabel.getFont());
        if (indicePropostaLabelFont != null) indicePropostaLabel.setFont(indicePropostaLabelFont);
        indicePropostaLabel.setForeground(new Color(-331531));
        indicePropostaLabel.setHorizontalAlignment(0);
        indicePropostaLabel.setHorizontalTextPosition(0);
        this.$$$loadLabelText$$$(indicePropostaLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "proposta"));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.SOUTH;
        gbc.insets = new Insets(50, 0, 0, 100);
        pannelloPrincipale.add(indicePropostaLabel, gbc);
        confermaBtn = new JButton();
        confermaBtn.setBorderPainted(true);
        confermaBtn.setContentAreaFilled(false);
        confermaBtn.setFocusPainted(false);
        Font confermaBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, confermaBtn.getFont());
        if (confermaBtnFont != null) confermaBtn.setFont(confermaBtnFont);
        confermaBtn.setForeground(new Color(-331531));
        confermaBtn.setPreferredSize(new Dimension(150, 50));
        this.$$$loadButtonText$$$(confermaBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "avanti"));
        gbc = new GridBagConstraints();
        gbc.gridx = 5;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 20);
        pannelloPrincipale.add(confermaBtn, gbc);
        indietroBtn = new JButton();
        indietroBtn.setAlignmentX(0.5f);
        indietroBtn.setAutoscrolls(false);
        indietroBtn.setBorderPainted(true);
        indietroBtn.setContentAreaFilled(false);
        indietroBtn.setFocusPainted(false);
        Font indietroBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietroBtn.getFont());
        if (indietroBtnFont != null) indietroBtn.setFont(indietroBtnFont);
        indietroBtn.setForeground(new Color(-331531));
        indietroBtn.setMaximumSize(new Dimension(250, 50));
        indietroBtn.setPreferredSize(new Dimension(150, 50));
        this.$$$loadButtonText$$$(indietroBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "indietro"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 0);
        pannelloPrincipale.add(indietroBtn, gbc);
        rifiutaBtn = new JButton();
        rifiutaBtn.setBorderPainted(true);
        rifiutaBtn.setContentAreaFilled(false);
        rifiutaBtn.setFocusPainted(false);
        Font rifiutaBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, rifiutaBtn.getFont());
        if (rifiutaBtnFont != null) rifiutaBtn.setFont(rifiutaBtnFont);
        rifiutaBtn.setForeground(new Color(-331531));
        rifiutaBtn.setPreferredSize(new Dimension(150, 50));
        this.$$$loadButtonText$$$(rifiutaBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "rifiuta.tutto"));
        gbc = new GridBagConstraints();
        gbc.gridx = 4;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 20);
        pannelloPrincipale.add(rifiutaBtn, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    private static Method $$$cachedGetBundleMethod$$$ = null;

    private String $$$getMessageFromBundle$$$(String path, String key) {
        ResourceBundle bundle;
        try {
            Class<?> thisClass = this.getClass();
            if ($$$cachedGetBundleMethod$$$ == null) {
                Class<?> dynamicBundleClass = thisClass.getClassLoader().loadClass("com.intellij.DynamicBundle");
                $$$cachedGetBundleMethod$$$ = dynamicBundleClass.getMethod("getBundle", String.class, Class.class);
            }
            bundle = (ResourceBundle) $$$cachedGetBundleMethod$$$.invoke(null, path, thisClass);
        } catch (Exception e) {
            bundle = ResourceBundle.getBundle(path);
        }
        return bundle.getString(key);
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadLabelText$$$(JLabel component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setDisplayedMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadButtonText$$$(AbstractButton component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return pannelloPrincipale;
    }

}
