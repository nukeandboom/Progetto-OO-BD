package Model;

import javax.swing.*;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;

public class Paragrafo
{
    private String contenuto;
    private Stato stato = Stato.InAttesa;
    private Azione operazioneDaEffettuare;
    private Date data_creazione;
    private Time orario_creazione;
    private int posizione;
    private Autore proprietario;
    private Pagina paginaDiRiferimento;
    private Collegamento collegamento = null;


    //COSTRUTTORE GENERICO
    public Paragrafo(String contenuto, int posizione, Azione azione, Pagina pagina, Autore proprietario)
    {
        if(azione == Azione.Svuotare)
            contenuto = "";

        this.contenuto = contenuto;
        this.proprietario = proprietario;
        this.posizione = posizione;

        paginaDiRiferimento = pagina;

        long current_date=System.currentTimeMillis();
        LocalTime current_Time = LocalTime.now();

        this.orario_creazione = Time.valueOf(current_Time);

        this.data_creazione = new java.sql.Date(current_date);

        operazioneDaEffettuare  = azione;

        proprietario.paragrafiScritti.add(this);
    }

    //COSTRUTTORE x SVUOTARE
    public Paragrafo(String contenuto, int posizione, Azione azione, Pagina pagina)
    {
        if(azione == Azione.Svuotare)
            contenuto = "";

        this.contenuto = contenuto;
        this.posizione = posizione;

        paginaDiRiferimento = pagina;

        long current_date=System.currentTimeMillis();
        LocalTime current_Time = LocalTime.now();

        this.orario_creazione = Time.valueOf(current_Time);

        this.data_creazione = new java.sql.Date(current_date);

        operazioneDaEffettuare  = azione;

    }

    //COSTRUTTORE x PARAGRAFO NUOVO
    public Paragrafo(String contenuto, int posizione, Pagina pagina)
    {

        this.contenuto = contenuto;
        this.posizione = posizione;

        paginaDiRiferimento = pagina;

        long current_date=System.currentTimeMillis();
        LocalTime current_Time = LocalTime.now();

        this.orario_creazione = Time.valueOf(current_Time);

        this.data_creazione = new java.sql.Date(current_date);


    }

    //COSTRUTTORE x PARAGRAFO DA CARICARE PER CREAZIONE DELLE PAGINE
    public Paragrafo(String contenuto, int posizione, Pagina pagina,java.util.Date data_creazione, Time orario_creazione)
    {

        this.contenuto = contenuto;
        this.posizione = posizione;

        paginaDiRiferimento = pagina;

        long current_date=System.currentTimeMillis();
        LocalTime current_Time = LocalTime.now();

        this.orario_creazione = Time.valueOf(current_Time);

        this.data_creazione = new java.sql.Date(current_date);


    }




    public Stato ottieniStato(){
        return stato;
    }

    public void impostaStato(Stato stato){
        this.stato = stato;
    }

    public Collegamento ottienicollegamento(){
        return collegamento;
    }

    public  void impostaCollegamento(Collegamento collegamento){
        this.collegamento = collegamento;
    }

    public String ottieniContenuto(){
        return  contenuto;
    }

    public Pagina ottieniPaginaDiRiferimento(){
        return  paginaDiRiferimento;
    }

    public int ottieniPosizione(){
        return posizione;
    }

    public Azione ottieniAzione(){
        return this.operazioneDaEffettuare;
    }

    public Autore ottieniProprietario(){
        return proprietario;
    }
}
