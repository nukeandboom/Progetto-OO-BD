package Model;

public abstract class GestioneAnomalia
{
    private final static String[] listaAnomalie = {
            "> [ERRORE 0 ]: Le credenziali non possono essere vuote!",
            "> [ERRORE 1 ]: Credenziali errate!",
            "> [ERRORE 2 ]: Creazione collegamento fallita -> Il titolo della pagina non può essere vuoto!",
            "> [ERRORE 3 ]: Creazione collegamento fallita -> Il titolo della pagina non può essere nullo!",
            "> [ERRORE 4 ]: Invio proposta fallito -> le informazioni inserite sono inesistenti!",
            "> [ERRORE 5 ]: Invio proposta fallito -> Indice paragrafo non può essere minore di 0!",
            "> [ERRORE 6 ]: Invio proposta fallito -> Indice paragrafo inesistente!",
            "> [ERRORE 7 ]: Invio proposta fallito -> paragrafo da eliminare inesistente!",
            "> [ERRORE 8 ]: Invio proposta fallito -> paragrafo da aggiornare inesistente!",
            "> [ERRORE 9 ]: Invio proposta fallito -> soltanto il proprietario della pagina può aggiungere paragrafi!",
            "> [ERRORE 10]: Raccolta info fallita -> il titolo inserito non può essere nullo!",
         //   "> [ERRORE 11]: Elaborazione proposta fallita -> il paragrafo selezionato non risulta nelle notifiche!",
            "> [ERRORE 12]: Raccolta info fallita -> la pagina selezionata non risulta nelle notifiche!",
            "> [ERRORE 13]: Raccolta info fallita -> Indice paragrafo inesistente!",
            "> [ERRORE 14]: Valore non accettabile; si prega di scegliere un valore compreso tra 1 e 5!",
            "> [ERRORE 15]: Selezionare un valore compreso tra 1 e 5!",
            "> [ERRORE 16]: Non è possibile recensire una pagina, a meno chè non ci si trovi sulla pagina in questione!",
            "> [ERRORE 17]: Raccolta info fallita -> La posizione del paragrafo non può essere negativa!",
            "> [ERRORE 18]: Recensione pagina fallita -> la pagnina inserita non può essere nulla!",
            "> [ERRORE 19]: Raccolta info fallita -> il titolo inserito non risulta presente nelle notifiche!",
            "> [ERRORE 20]: Creazione collegamento fallita -> la pagina d'arrivo e di provenienza non possono essere uguali!",
         //   "> [ERRORE 21]: Elaborazione proposta fallita -> la pagina selezionata risulta inesistente!",
            "> [ERRORE 22]: Raccolta info fallita -> lo storico selezionato non risulta presente tra quelli accessibili!",
            "> [ERRORE 23]: Non risulta alcun autore con l'username selezionato!"
            };

    public void inviaAnomalia(int codice)
    {
        System.out.println(listaAnomalie[codice]);
    }
    public boolean determinaAnomalie(int[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 6, 16 -> {
                    if(dati[0] < dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                case 7, 17 -> {
                    if(dati[0] > dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                case 8, 9 ->{
                    if(dati[0] >= dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }
        }catch (IndexOutOfBoundsException exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean determinaAnomalie(Object[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 0, 4, 5, 11, 20, 22 -> {
                    if(dati[0] == dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
                case 1, 10, 18 ->{
                    if(dati[0] != dati[1])
                        throw new Exception (listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }
        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean determinaAnomalie(String[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 0, 3 -> {
                    if(dati[0].contentEquals(""))
                        throw new  Exception(listaAnomalie[codice]);
                }
                case 2 ->{
                    if(!dati[0].contentEquals(dati[1]))
                        throw new  Exception (listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }

        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public  boolean determinaAnomalie(boolean err, boolean statoPrevisto, int codice)
    {
        try {
            if(err != statoPrevisto)
                throw new IllegalStateException(listaAnomalie[codice]);

        } catch (IllegalStateException exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }
}
