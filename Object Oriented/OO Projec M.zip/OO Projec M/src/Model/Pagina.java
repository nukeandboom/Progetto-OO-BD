package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Pagina
{
    public String titolo;
    public Date   dataCreazione;
    public Autore proprietario;
    public int valutazione;
    public ArrayList<Utente> visitatori = new ArrayList<>();
    public ArrayList<Paragrafo> testo = new ArrayList<>();
    public HashMap<Integer,ArrayList<Paragrafo>> storicoPagina = new HashMap<>();

    public Pagina(String titolo, Autore proprietario)
    {
        this.titolo = titolo;
        this.proprietario = proprietario;
        dataCreazione = new Date();
    }

    public Pagina(String titolo, Autore proprietario, Date dataCreazione)
    {
        this.titolo = titolo;
        this.proprietario = proprietario;
        this.dataCreazione = dataCreazione;
    }


    // costruttore usato per pagine solo visitate dall'utente, non carica l'autore.
    public Pagina(String titolo, Date dataCreazione)
    {
        this.titolo = titolo;
        this.dataCreazione = dataCreazione;
    }


    public  void applicaParagrafo(Paragrafo daApplicare)
    {
        switch (daApplicare.ottieniAzione())
        {
            case Aggiungere ->
            {
                ArrayList<Paragrafo> listaTemporanea = new ArrayList<>();
                listaTemporanea.add(daApplicare);
                storicoPagina.put(testo.size(), listaTemporanea);
                testo.add(daApplicare);
            }

            // nel caso di Remove, il contenuto della variabile
            // "daApplicare" è stato preventivamente impostato come "", al fine
            // di imitare la presenza di un paragrafo cancellato sulla pagina.
            case Aggiornare, Svuotare ->
            {
                storicoPagina.get(daApplicare.ottieniPosizione()).getLast().impostaStato(Stato.Expired);
                storicoPagina.get(daApplicare.ottieniPosizione()).add(daApplicare);
                testo.set(daApplicare.ottieniPosizione(),daApplicare);
            }
        }
    }

    public int ottieniValutazionePagina()
    {
        return valutazione/visitatori.size();
    }
}
