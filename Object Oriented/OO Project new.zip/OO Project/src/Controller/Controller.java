package Controller;

import Model.*;

import java.util.ArrayList;
import java.util.HashMap;

public class Controller extends GestioneAnomalia
{
        private Utente utente;
        private Autore autore;
        public Autore autoreDiScorta = new Autore("2", "2");// da elimiare
        public Pagina paginaDiScorta = new Pagina("ciao", autoreDiScorta); // da eliminare
        private  Autore destinatarioProposta;
        private Pagina paginaDaCreare;
        private Pagina paginaDiDestinazione;
        public Collegamento collegamentoDaImplementare;

        public void creaUtente()
        {
                int id = 0; // richiedi al database un id (da fare nel model)
                utente = new Utente(id);

                paginaDiScorta.applicaParagrafo(new Paragrafo("lo", paginaDiScorta, autoreDiScorta)); // da eliminare
                paginaDiScorta.applicaParagrafo(new Paragrafo("il", paginaDiScorta, autoreDiScorta)); // da eliminare
                paginaDiScorta.applicaParagrafo(new Paragrafo("le", paginaDiScorta, autoreDiScorta)); // da eliminare
                autoreDiScorta.pagScritte.add(paginaDiScorta); // da eliminare
        }

        public void eliminaUtente()
        {
                utente = null;
        }
        public boolean controllaCredenzialiAccesso(String username, String password)
        {
                boolean check = true;

                // ricerca esistenza username (da fare nel model)

                // se non è presente nessun username uguale a quello indicato
                if(!check)
                        inviaAnomalia(26);

                if(!determinaAnomalie(new String[]{password, autore.ottieniPassword()}, 3))
                        return false;

                return true;
        }

        public boolean creaAutore(String username, String password)
        {
                autore = utente.signUpComeAutore(username, password);

                return autore == null ? false : true;
        }

        public Autore ottieniAutore()
        {
                return  autore;
        }
        public boolean creaPagina(String titolo)
        {
               if(controllaEsistenzaPagina(titolo) == null)
                        paginaDaCreare = new Pagina(titolo, autore);

               return true; // da modificare
        }

        public Pagina controllaEsistenzaPagina(String titolo)
        {
                // controlla su db se esiste una pagina con lo stesso nome (da fare nel model)
                return null;
        }

        public Pagina memorizzaPaginaTemporanea(String titolo)
        {
                // cerca su db la pagina in questione (da fare nel model)

                paginaDiDestinazione = paginaDiScorta; //  da eliminare
                destinatarioProposta = paginaDiDestinazione.proprietario;
                return paginaDiDestinazione;
        }

        public int ottieniNumeroParagrafiScritti()
        {
                return paginaDaCreare.testo.size();
        }

        public void memorizzaPagina()
        {
                // memorizza la pagina sul database (da fare nel model)
                autore.creaPagina(paginaDaCreare);
        }

        public  HashMap<Pagina, HashMap<Integer, ArrayList<Paragrafo>>>  ottieniInfoNotifiche()
        {
              return autore.ottieniProposte();
        }

        public void implementaParagrafoInUnaNuovaPagina(String contenuto)
        {
                Paragrafo daImplementare = new Paragrafo(contenuto, paginaDaCreare, autore);
                daImplementare.collegamento = collegamentoDaImplementare;
                collegamentoDaImplementare = null;
                daImplementare.stato = Stato.Approvato;
                paginaDaCreare.applicaParagrafo(daImplementare);
        }

        public void inviaProposta(String contenutoParagrafo, int posizione, Pagina destinazione,  int codOperazione)
        {
                Paragrafo daInviare = autore.creaParagrafo(contenutoParagrafo, posizione , destinazione, codOperazione);
                autore.inviaProposta(daInviare, destinatarioProposta);
        }

        public  void implementaParagrafoInPaginaEsistente(Paragrafo daImplementare)
        {
                autore.elaborazioneProposta(daImplementare);
        }

        public void scartaOgniProposta(Pagina paginaDiRiferimento, int indiceDaScartare)
        {
                autore.rifiutaTutteLeProposte(indiceDaScartare, paginaDiRiferimento);
        }

        public  ArrayList<Pagina> ottieniListaStorici()
        {
                return  autore.storiciAccessibili;
        }

        public  HashMap<Integer, ArrayList<Paragrafo>> ottieniStorico( Pagina paginaDiRiferimento)
        {
                // richiedi al database (da fare nel model)
                HashMap<Integer, ArrayList<Paragrafo>> storico  = paginaDiRiferimento.storicoPagina;
                return storico ;
        }

        public Pagina ottieniPagina(String titoloPagina)
        {
                //ricerca sul db la pagina (ovviamente esiste, perchè un collegamneto approvato si riferisce ad una pagina esistente)(da fare nel model)

                Pagina paginaDaVisitare = null;

                return paginaDaVisitare;
        }

        public void creaCollegamento(Pagina paginaDiPartenza, String titoloPaginaDestinazione)
        {
                Pagina risultato = controllaEsistenzaPagina(titoloPaginaDestinazione);

                if(risultato != null)
                        collegamentoDaImplementare = new Collegamento(paginaDiPartenza, risultato);
                else
                        collegamentoDaImplementare = null;
        }
}
