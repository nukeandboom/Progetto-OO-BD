package GUI;

import Controller.Controller;
import Model.Pagina;
import Model.Paragrafo;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

public class SchermataCreazionePagina {
    private JPanel panel;
    private JButton aggiungiParagrafo;
    private JButton creaPagina;
    private JButton indietro;
    private JTextField titoloTextField;
    private JTextArea textArea;
    private JButton impostaCollegamento;
    private Controller controller;
    private JFrame chiamante;
    private JFrame currentFrame;

    public SchermataCreazionePagina(JFrame chiamante, Controller controller, Pagina paginaDiRiferimento) {
        this.controller = controller;
        this.chiamante = chiamante;
        currentFrame = new JFrame("SchermataCreazionePagina");
        currentFrame.setContentPane(panel);
        currentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        currentFrame.pack();
        currentFrame.setLocationRelativeTo(null);
        currentFrame.setVisible(true);
        titoloTextField.setText(titoloTextField.getText() + paginaDiRiferimento.titolo);

        JLabel messaggio = new JLabel();
        JTextField campoCollegamento = new JTextField();
        messaggio.setHorizontalAlignment(SwingConstants.CENTER);


        indietro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                messaggio.setText("Vuoi eliminare la pagina?");

                if (creaPopUp(messaggio, "Eliminazione pagina", new String[]{"Indietro", "Elimina"}) == 1) {
                    chiudiForm();
                }
            }
        });
        aggiungiParagrafo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!textArea.getText().isBlank()) {

                    if (textArea.getText().length() >= 255) {
                        JOptionPane.showMessageDialog(null, "Attenzione, una paragrafo non può eguagliare o superare i 255 caratteri! ");
                        return;
                    }

                    controller.implementaParagrafoInUnaNuovaPagina(textArea.getText());
                    textArea.setForeground(Color.white);
                    textArea.setText(null);
                }
            }
        });
        creaPagina.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (controller.ottieniNumeroParagrafiScritti() == 0) {
                    JOptionPane.showMessageDialog(null, " Attenzione, una pagina non può essere vuota! ");
                    return;
                }

                if (!textArea.getText().isBlank()) {
                    messaggio.setText(" Attenzione, la stesura del paragrafo non è stata ultimata! Se si conferma la creazione del documento, il paragrafo verrà scartato. ");

                    if (creaPopUp(messaggio, "Salvataggio pagina", new String[]{"Indietro", "Salva comunque"}) == 1) {
                        controller.memorizzaPagina();
                        chiudiForm();
                    }
                } else {
                    messaggio.setText("Vuoi salvare la pagina?");

                    if (creaPopUp(messaggio, "Salvataggio pagina", new String[]{"Indietro", "Salva"}) == 1) {
                        controller.memorizzaPagina();
                        chiudiForm();

                    }
                }
            }
        });
        impostaCollegamento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (controller.collegamentoDaImplementare != null) {
                    controller.collegamentoDaImplementare = null;
                    textArea.setForeground(Color.white);
                } else {
                    messaggio.setText("Specica la pagina di destinazione");

                    JComponent[] components = new JComponent[]{messaggio, campoCollegamento};

                    int risultatoPopUp = JOptionPane.showOptionDialog(null, components, "Creazione collegamento", JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.PLAIN_MESSAGE, null, new String[]{"Indietro", "Crea"}, null);

                    if (risultatoPopUp == 1 && !campoCollegamento.getText().isBlank()) {
                        controller.creaCollegamento(paginaDiRiferimento, campoCollegamento.getText());

                        if (controller.collegamentoDaImplementare == null) {
                            messaggio.setText("Attenzione: la pagina selezionata non esiste!");

                            creaPopUp(messaggio, "Errore collegamento", new String[]{"Indietro"});
                        } else textArea.setForeground(Color.blue);
                    }
                }
            }
        });
    }

    public void chiudiForm() {
        chiamante.setVisible(true);
        currentFrame.setVisible(false);
        currentFrame.dispose();
    }

    public int creaPopUp(Object messaggio, String titolo, String[] opzioni) {
        return JOptionPane.showOptionDialog(null, messaggio, titolo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, opzioni, null);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(-14342875));
        panel.setPreferredSize(new Dimension(1200, 720));
        creaPagina = new JButton();
        creaPagina.setBorderPainted(true);
        creaPagina.setContentAreaFilled(false);
        creaPagina.setFocusPainted(false);
        Font creaPaginaFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, creaPagina.getFont());
        if (creaPaginaFont != null) creaPagina.setFont(creaPaginaFont);
        creaPagina.setForeground(new Color(-331531));
        creaPagina.setPreferredSize(new Dimension(250, 50));
        creaPagina.setText("crea pagina");
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(20, 0, 30, 50);
        panel.add(creaPagina, gbc);
        indietro = new JButton();
        indietro.setAlignmentX(0.5f);
        indietro.setAutoscrolls(false);
        indietro.setBorderPainted(true);
        indietro.setContentAreaFilled(false);
        indietro.setFocusPainted(false);
        Font indietroFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietro.getFont());
        if (indietroFont != null) indietro.setFont(indietroFont);
        indietro.setForeground(new Color(-331531));
        indietro.setMaximumSize(new Dimension(250, 50));
        indietro.setPreferredSize(new Dimension(250, 50));
        indietro.setText("indietro");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(20, 0, 30, 50);
        panel.add(indietro, gbc);
        textArea = new JTextArea();
        textArea.setBackground(new Color(-13158601));
        Font textAreaFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, textArea.getFont());
        if (textAreaFont != null) textArea.setFont(textAreaFont);
        textArea.setForeground(new Color(-331531));
        textArea.setLineWrap(true);
        textArea.setOpaque(true);
        textArea.setPreferredSize(new Dimension(200, 300));
        textArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.gridheight = 3;
        gbc.ipadx = 450;
        gbc.insets = new Insets(0, 0, 50, 50);
        panel.add(textArea, gbc);
        titoloTextField = new JTextField();
        titoloTextField.setBackground(new Color(-14342875));
        titoloTextField.setEditable(false);
        Font titoloTextFieldFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, titoloTextField.getFont());
        if (titoloTextFieldFont != null) titoloTextField.setFont(titoloTextFieldFont);
        titoloTextField.setForeground(new Color(-331531));
        titoloTextField.setHorizontalAlignment(0);
        titoloTextField.setOpaque(false);
        titoloTextField.setPreferredSize(new Dimension(250, 50));
        titoloTextField.setText("Titolo:");
        titoloTextField.setVerifyInputWhenFocusTarget(false);
        titoloTextField.setVisible(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(70, 0, 30, 100);
        panel.add(titoloTextField, gbc);
        impostaCollegamento = new JButton();
        impostaCollegamento.setBorderPainted(true);
        impostaCollegamento.setContentAreaFilled(false);
        impostaCollegamento.setFocusPainted(false);
        Font impostaCollegamentoFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, impostaCollegamento.getFont());
        if (impostaCollegamentoFont != null) impostaCollegamento.setFont(impostaCollegamentoFont);
        impostaCollegamento.setForeground(new Color(-331531));
        impostaCollegamento.setPreferredSize(new Dimension(250, 50));
        impostaCollegamento.setText("imposta collegamento");
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 5;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(50, 50, 0, 50);
        panel.add(impostaCollegamento, gbc);
        aggiungiParagrafo = new JButton();
        aggiungiParagrafo.setBorderPainted(true);
        aggiungiParagrafo.setContentAreaFilled(false);
        aggiungiParagrafo.setFocusPainted(false);
        Font aggiungiParagrafoFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, aggiungiParagrafo.getFont());
        if (aggiungiParagrafoFont != null) aggiungiParagrafo.setFont(aggiungiParagrafoFont);
        aggiungiParagrafo.setForeground(new Color(-331531));
        aggiungiParagrafo.setPreferredSize(new Dimension(250, 50));
        aggiungiParagrafo.setText("aggiungi paragrafo");
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 50, 0, 50);
        panel.add(aggiungiParagrafo, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panel;
    }

}
