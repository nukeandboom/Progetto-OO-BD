package GUI;

import javax.swing.*;

public abstract class FunzioniDiSupportoGUI {

    public JFrame inizializzaNuovaFinestra(String titoloFinestra, JPanel pannelloPrincipale)
    {
        JFrame frame = new JFrame(titoloFinestra);
        frame.setContentPane(pannelloPrincipale);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        return frame;
    }

    public void chiudiFinestra(JFrame chiamante, JFrame corrente)
    {
        chiamante.setVisible(true);
        corrente.setVisible(false);
        corrente.dispose();
    }
}
