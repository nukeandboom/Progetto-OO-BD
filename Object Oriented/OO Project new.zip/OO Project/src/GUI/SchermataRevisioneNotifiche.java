package GUI;

import Controller.Controller;
import Model.Pagina;
import Model.Paragrafo;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class SchermataRevisioneNotifiche {

    private JPanel panel;
    private JComboBox paginaComboBox;
    private JComboBox indiceParagrafoComboBox;
    private JComboBox indicePropostaComboBox;
    private JTextArea propostaTextArea;
    private JLabel paginaLabel;
    private JLabel paragrafoLabel;
    private JLabel propostaLabel;
    private JButton conferma;
    private JButton indietro;
    private JButton rifiuta;
    private Controller controller;
    private JFrame frameDiRitorno;
    private JFrame currentFrame;


    public SchermataRevisioneNotifiche(Controller controller, JFrame chiamante) {
        this.controller = controller;
        this.frameDiRitorno = chiamante;
        currentFrame = new JFrame("SchermataAutore");
        currentFrame.setContentPane(panel);
        currentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        currentFrame.pack();
        currentFrame.setLocationRelativeTo(null);
        currentFrame.setVisible(true);

        HashMap<Pagina, HashMap<Integer, ArrayList<Paragrafo>>> listaParagrafi = controller.ottieniInfoNotifiche();
        ArrayList<Pagina> listaPagine = new ArrayList<>();

        paginaComboBox.addItem("---");
        indiceParagrafoComboBox.addItem("---");
        indicePropostaComboBox.addItem("---");

        for (Pagina pag : listaParagrafi.keySet()) {
            paginaComboBox.addItem(pag.titolo);
            listaPagine.add(pag);
        }

        paginaComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                indiceParagrafoComboBox.removeAllItems();
                indiceParagrafoComboBox.addItem("---");

                if (paginaComboBox.getSelectedItem() != paginaComboBox.getItemAt(0)) {
                    Pagina chiave = listaPagine.get(paginaComboBox.getSelectedIndex() - 1);

                    for (int index : listaParagrafi.get(chiave).keySet()) {
                        indiceParagrafoComboBox.addItem(String.valueOf(index));
                    }
                }
            }
        });
        indiceParagrafoComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                indicePropostaComboBox.removeAllItems();
                indicePropostaComboBox.addItem("---");

                if (indiceParagrafoComboBox.getSelectedItem() != indiceParagrafoComboBox.getItemAt(0)) {
                    Pagina chiave = listaPagine.get(paginaComboBox.getSelectedIndex() - 1);
                    int chiaveParagrafo = indiceParagrafoComboBox.getSelectedIndex() - 1;
                    int numParagrafi = listaParagrafi.get(chiave).get(chiaveParagrafo).size();

                    for (int index = 0; index < numParagrafi; index++) {
                        indicePropostaComboBox.addItem(String.valueOf(index));
                    }
                }
            }
        });

        indicePropostaComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                if (indicePropostaComboBox.getSelectedItem() != indicePropostaComboBox.getItemAt(0)) {
                    Pagina chiavePagina = listaPagine.get(paginaComboBox.getSelectedIndex() - 1);
                    int chiaveParagrafo = indiceParagrafoComboBox.getSelectedIndex() - 1;
                    int indiceParagrafo = indicePropostaComboBox.getSelectedIndex() - 1;
                    Paragrafo paragrafo = listaParagrafi.get(chiavePagina).get(chiaveParagrafo).get(indiceParagrafo);

                    propostaTextArea.setText("[ " + paragrafo.operazioneDaEffettuare + "] " + paragrafo.contenuto);
                } else {
                    propostaTextArea.setText(null);
                }
            }
        });
        indietro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chiudiForm();
            }
        });
        conferma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (propostaTextArea.getText().isBlank()) {
                    JOptionPane.showMessageDialog(null, "Nessuna proposta selezionata!");
                    return;
                }

                Pagina chiavePagina = listaPagine.get(paginaComboBox.getSelectedIndex() - 1);
                int chiaveParagrafo = indiceParagrafoComboBox.getSelectedIndex() - 1;
                int indiceParagrafo = indicePropostaComboBox.getSelectedIndex() - 1;
                Paragrafo paragrafo = listaParagrafi.get(chiavePagina).get(chiaveParagrafo).get(indiceParagrafo);

                controller.implementaProposta(paragrafo);
                chiudiForm();
            }
        });
        rifiuta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (indiceParagrafoComboBox.getSelectedIndex() == 0) {
                    JOptionPane.showMessageDialog(null, "E' necessario specificare l'indice di un paragrafo, per rifiutare tutte le proposte!");
                    return;
                }

                Pagina chiavePagina = listaPagine.get(paginaComboBox.getSelectedIndex() - 1);
                int chiaveParagrafo = indiceParagrafoComboBox.getSelectedIndex() - 1;

                controller.scartaOgniProposta(chiavePagina, chiaveParagrafo);
                chiudiForm();
            }
        });
    }

    public void chiudiForm() {
        frameDiRitorno.setVisible(true);
        currentFrame.setVisible(false);
        currentFrame.dispose();
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(-14145496));
        panel.setOpaque(true);
        panel.setPreferredSize(new Dimension(1200, 720));
        paginaComboBox = new JComboBox();
        paginaComboBox.setBackground(new Color(-14342875));
        Font paginaComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, paginaComboBox.getFont());
        if (paginaComboBoxFont != null) paginaComboBox.setFont(paginaComboBoxFont);
        paginaComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        paginaComboBox.setModel(defaultComboBoxModel1);
        paginaComboBox.setOpaque(true);
        paginaComboBox.setPreferredSize(new Dimension(200, 50));
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.1;
        gbc.insets = new Insets(0, 0, 100, 0);
        panel.add(paginaComboBox, gbc);
        indiceParagrafoComboBox = new JComboBox();
        indiceParagrafoComboBox.setBackground(new Color(-14342875));
        Font indiceParagrafoComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceParagrafoComboBox.getFont());
        if (indiceParagrafoComboBoxFont != null) indiceParagrafoComboBox.setFont(indiceParagrafoComboBoxFont);
        indiceParagrafoComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel2 = new DefaultComboBoxModel();
        indiceParagrafoComboBox.setModel(defaultComboBoxModel2);
        indiceParagrafoComboBox.setOpaque(true);
        indiceParagrafoComboBox.setPreferredSize(new Dimension(200, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridheight = 2;
        gbc.weightx = 0.1;
        gbc.insets = new Insets(0, 0, 100, 0);
        panel.add(indiceParagrafoComboBox, gbc);
        indicePropostaComboBox = new JComboBox();
        indicePropostaComboBox.setBackground(new Color(-14342875));
        Font indicePropostaComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indicePropostaComboBox.getFont());
        if (indicePropostaComboBoxFont != null) indicePropostaComboBox.setFont(indicePropostaComboBoxFont);
        indicePropostaComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel3 = new DefaultComboBoxModel();
        indicePropostaComboBox.setModel(defaultComboBoxModel3);
        indicePropostaComboBox.setOpaque(true);
        indicePropostaComboBox.setPreferredSize(new Dimension(200, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridheight = 3;
        gbc.weightx = 0.1;
        gbc.insets = new Insets(0, 0, 100, 0);
        panel.add(indicePropostaComboBox, gbc);
        propostaTextArea = new JTextArea();
        propostaTextArea.setBackground(new Color(-14342875));
        propostaTextArea.setEditable(false);
        Font propostaTextAreaFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, propostaTextArea.getFont());
        if (propostaTextAreaFont != null) propostaTextArea.setFont(propostaTextAreaFont);
        propostaTextArea.setForeground(new Color(-331531));
        propostaTextArea.setPreferredSize(new Dimension(300, 200));
        propostaTextArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.gridheight = 4;
        gbc.weightx = 0.1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(50, 0, 0, 50);
        panel.add(propostaTextArea, gbc);
        paginaLabel = new JLabel();
        Font paginaLabelFont = this.$$$getFont$$$("Monospaced", Font.BOLD, 20, paginaLabel.getFont());
        if (paginaLabelFont != null) paginaLabel.setFont(paginaLabelFont);
        paginaLabel.setForeground(new Color(-331531));
        paginaLabel.setHorizontalAlignment(0);
        paginaLabel.setHorizontalTextPosition(0);
        paginaLabel.setText("Seleziona pagina");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.anchor = GridBagConstraints.SOUTH;
        gbc.insets = new Insets(50, 0, 0, 0);
        panel.add(paginaLabel, gbc);
        paragrafoLabel = new JLabel();
        Font paragrafoLabelFont = this.$$$getFont$$$("Monospaced", Font.BOLD, 20, paragrafoLabel.getFont());
        if (paragrafoLabelFont != null) paragrafoLabel.setFont(paragrafoLabelFont);
        paragrafoLabel.setForeground(new Color(-331531));
        paragrafoLabel.setHorizontalAlignment(0);
        paragrafoLabel.setHorizontalTextPosition(0);
        paragrafoLabel.setText("indice paragrafo");
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.SOUTH;
        gbc.insets = new Insets(50, 0, 0, 0);
        panel.add(paragrafoLabel, gbc);
        propostaLabel = new JLabel();
        Font propostaLabelFont = this.$$$getFont$$$("Monospaced", Font.BOLD, 20, propostaLabel.getFont());
        if (propostaLabelFont != null) propostaLabel.setFont(propostaLabelFont);
        propostaLabel.setForeground(new Color(-331531));
        propostaLabel.setHorizontalAlignment(0);
        propostaLabel.setHorizontalTextPosition(0);
        propostaLabel.setText("proposta");
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.SOUTH;
        gbc.insets = new Insets(50, 0, 0, 100);
        panel.add(propostaLabel, gbc);
        conferma = new JButton();
        conferma.setBorderPainted(true);
        conferma.setContentAreaFilled(false);
        conferma.setFocusPainted(false);
        Font confermaFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, conferma.getFont());
        if (confermaFont != null) conferma.setFont(confermaFont);
        conferma.setForeground(new Color(-331531));
        conferma.setPreferredSize(new Dimension(150, 50));
        conferma.setText("avanti");
        gbc = new GridBagConstraints();
        gbc.gridx = 5;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 20);
        panel.add(conferma, gbc);
        indietro = new JButton();
        indietro.setAlignmentX(0.5f);
        indietro.setAutoscrolls(false);
        indietro.setBorderPainted(true);
        indietro.setContentAreaFilled(false);
        indietro.setFocusPainted(false);
        Font indietroFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietro.getFont());
        if (indietroFont != null) indietro.setFont(indietroFont);
        indietro.setForeground(new Color(-331531));
        indietro.setMaximumSize(new Dimension(250, 50));
        indietro.setPreferredSize(new Dimension(150, 50));
        indietro.setText("indietro");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 0);
        panel.add(indietro, gbc);
        rifiuta = new JButton();
        rifiuta.setBorderPainted(true);
        rifiuta.setContentAreaFilled(false);
        rifiuta.setFocusPainted(false);
        Font rifiutaFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, rifiuta.getFont());
        if (rifiutaFont != null) rifiuta.setFont(rifiutaFont);
        rifiuta.setForeground(new Color(-331531));
        rifiuta.setPreferredSize(new Dimension(150, 50));
        rifiuta.setText("rifiuta tutto");
        gbc = new GridBagConstraints();
        gbc.gridx = 4;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 20);
        panel.add(rifiuta, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panel;
    }

}
