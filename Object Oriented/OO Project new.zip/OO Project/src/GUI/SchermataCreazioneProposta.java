package GUI;

import Controller.Controller;
import Model.Collegamento;
import Model.Pagina;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.ResourceBundle;

public class SchermataCreazioneProposta {
    private JTextArea propostaTextArea;
    private JButton inviaProposta;
    private JButton indietro;
    private JTextField paginaTextField;
    private JComboBox operazioneComboBox;
    private JPanel panel;
    private JComboBox indiceParagrafoComboBox;
    private JTextArea visualizzaTesto;
    private JLabel paragrafoAttualeLabel;
    private JLabel PropostaLabel;
    private JButton collegamentoButton;
    private JFrame currentFrame;
    private Controller controller;
    private JFrame frameDiRitorno;
    private boolean statoCollegamentoButton = false;


    public SchermataCreazioneProposta(Controller controller, JFrame chiamante, Pagina paginaDiRiferimento) {
        this.controller = controller;
        this.frameDiRitorno = chiamante;
        currentFrame = new JFrame("SchermataAutore");
        currentFrame.setContentPane(panel);
        currentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        currentFrame.pack();
        currentFrame.setLocationRelativeTo(null);
        currentFrame.setVisible(true);

        paginaTextField.setText(paginaTextField.getText() + paginaDiRiferimento.titolo);

        JLabel messaggio = new JLabel();
        messaggio.setHorizontalAlignment(SwingConstants.CENTER);

        operazioneComboBox.addItem("---");
        indiceParagrafoComboBox.addItem("---");
        operazioneComboBox.addItem("Aggiornare");
        operazioneComboBox.addItem("Aggiungere");
        operazioneComboBox.addItem("Eliminare");

        indietro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!propostaTextArea.getText().isBlank()) {
                    messaggio.setText("Attenzione, se si esce dalla pagina il lavoro non salvato verrà eliminato!");

                    if (creaPopUp(messaggio, "Uscita pagina", new String[]{"Indietro", "Elimina"}) == 0)
                        return;
                }

                chiudiForm();
            }
        });
        inviaProposta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Collegamento collegamentoDaProporre = null;

                if (operazioneComboBox.getSelectedIndex() == 0) {
                    messaggio.setText("Nessuna operazione selezionata!");
                    creaPopUp(messaggio, "Errore invio Proposta", new String[]{"Indietro"});
                    return;
                }

                if (indiceParagrafoComboBox.getSelectedIndex() == 0 && operazioneComboBox.getSelectedIndex() != 2) {
                    messaggio.setText("E' necessario selezionare un paragrafo su cui applicare una modifica!");
                    creaPopUp(messaggio, "Errore invio Proposta", new String[]{"Indietro"});
                    return;
                }

                if (statoCollegamentoButton) {
                    if (propostaTextArea.getText().isBlank() && operazioneComboBox.getSelectedIndex() == 1) {
                        messaggio.setText("L'operazione di aggiunta di un collegamento richiede una proposta che non sia vuota!");
                        creaPopUp(messaggio, "Errore collegamento", new String[]{"Indietro"});
                        return;
                    }

                    if (!propostaTextArea.getText().isBlank() && operazioneComboBox.getSelectedIndex() == 1) {
                        Pagina paginaDiDestinazione = controller.controllaEsistenzaPagina(propostaTextArea.getText());

                        if (paginaDiDestinazione == null) {
                            messaggio.setText("Attenzione: la pagina selezionata nel collegamento è inesistente!");
                            creaPopUp(messaggio, "Errore invio Proposta", new String[]{"Indietro"});
                            return;
                        }

                        collegamentoDaProporre = new Collegamento(paginaDiRiferimento, paginaDiDestinazione);
                    }

                } else {
                    if (propostaTextArea.getText().isBlank() && operazioneComboBox.getSelectedIndex() != 3) {
                        messaggio.setText("L' operazione di aggiunta, o modifica, di un paragrafo richiede una proposta che non sia vuota!");
                        creaPopUp(messaggio, "Errore invio Proposta", new String[]{"Indietro"});
                        return;
                    }

                    if (operazioneComboBox.getSelectedIndex() == 2 && controller.ottieniAutore() != paginaDiRiferimento.proprietario) {
                        messaggio.setText("L' operazione di aggiunta di un paragrafo può essere effettuata solo dal proprietario della pagina!");
                        creaPopUp(messaggio, "Errore collegamento", new String[]{"Indietro"});
                        return;
                    }
                }

                messaggio.setText("Si desidera inviare la proposta?");

                if (creaPopUp(messaggio, "Invio proposta", new String[]{"Indietro", "Invia"}) == 1) {

                    controller.inviaProposta(propostaTextArea.getText(), indiceParagrafoComboBox.getSelectedIndex() - 1,
                            paginaDiRiferimento, operazioneComboBox.getSelectedIndex() - 1,
                            collegamentoDaProporre);
                    chiudiForm();
                }
            }
        });
        operazioneComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {

                if (evento.getStateChange() == ItemEvent.DESELECTED) {
                    indiceParagrafoComboBox.removeAllItems();
                    indiceParagrafoComboBox.addItem("---");
                    return;
                }

                if (evento.getStateChange() == ItemEvent.SELECTED) {
                    if (operazioneComboBox.getSelectedIndex() != 0 && operazioneComboBox.getSelectedIndex() != 2) {
                        for (int indice = 0; indice < paginaDiRiferimento.testo.size(); indice++) {
                            indiceParagrafoComboBox.addItem(String.valueOf(indice));
                        }
                    }
                }
            }
        });
        indiceParagrafoComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {

                if (evento.getStateChange() == ItemEvent.SELECTED) {
                    int indiceParagrafo = indiceParagrafoComboBox.getSelectedIndex();
                    int operazione = operazioneComboBox.getSelectedIndex();

                    if (indiceParagrafo != 0 && operazione != 0 && operazione != 2)
                        visualizzaTesto.setText(paginaDiRiferimento.testo.get(indiceParagrafo - 1).contenuto);
                }
            }
        });
        collegamentoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (operazioneComboBox.getSelectedIndex() == 0 || indiceParagrafoComboBox.getSelectedIndex() == 0)
                    return;

                if (controller.ottieniAutore() != paginaDiRiferimento.proprietario) {
                    messaggio.setText("L' operazione inerenti ai collegamneti possono essere effettuate solo dal proprietario della pagina!");
                    creaPopUp(messaggio, "Errore collegamento", new String[]{"Indietro"});
                    return;
                }

                if (statoCollegamentoButton) {
                    propostaTextArea.setText(controller.messaggioDaProporre);
                    propostaTextArea.setForeground(Color.white);
                    return;
                }

                int indiceParagrafo = indiceParagrafoComboBox.getSelectedIndex() - 1;
                Collegamento collegamentoParagrafo = paginaDiRiferimento.testo.get(indiceParagrafo).collegamento;

                controller.messaggioDaProporre = propostaTextArea.getText();
                propostaTextArea.setText(collegamentoParagrafo.toString());
                propostaTextArea.setForeground(Color.blue);
            }
        });
    }

    public int creaPopUp(Object messaggio, String titolo, String[] opzioni) {
        return JOptionPane.showOptionDialog(null, messaggio, titolo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, opzioni, null);
    }

    public void chiudiForm() {
        frameDiRitorno.setVisible(true);
        currentFrame.setVisible(false);
        currentFrame.dispose();
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(-14342875));
        panel.setPreferredSize(new Dimension(1200, 720));
        inviaProposta = new JButton();
        inviaProposta.setBorderPainted(true);
        inviaProposta.setContentAreaFilled(false);
        inviaProposta.setFocusPainted(false);
        Font inviaPropostaFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, inviaProposta.getFont());
        if (inviaPropostaFont != null) inviaProposta.setFont(inviaPropostaFont);
        inviaProposta.setForeground(new Color(-331531));
        inviaProposta.setPreferredSize(new Dimension(250, 50));
        inviaProposta.setText("invia proposta");
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 30, 0, 0);
        panel.add(inviaProposta, gbc);
        indietro = new JButton();
        indietro.setAlignmentX(0.5f);
        indietro.setAutoscrolls(false);
        indietro.setBorderPainted(true);
        indietro.setContentAreaFilled(false);
        indietro.setFocusPainted(false);
        Font indietroFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietro.getFont());
        if (indietroFont != null) indietro.setFont(indietroFont);
        indietro.setForeground(new Color(-331531));
        indietro.setMaximumSize(new Dimension(250, 50));
        indietro.setPreferredSize(new Dimension(250, 50));
        indietro.setText("indietro");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 50);
        panel.add(indietro, gbc);
        paginaTextField = new JTextField();
        paginaTextField.setBackground(new Color(-14342875));
        paginaTextField.setEditable(false);
        Font paginaTextFieldFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, paginaTextField.getFont());
        if (paginaTextFieldFont != null) paginaTextField.setFont(paginaTextFieldFont);
        paginaTextField.setForeground(new Color(-331531));
        paginaTextField.setHorizontalAlignment(0);
        paginaTextField.setOpaque(false);
        paginaTextField.setPreferredSize(new Dimension(250, 50));
        paginaTextField.setText("pagina : ");
        paginaTextField.setVerifyInputWhenFocusTarget(false);
        paginaTextField.setVisible(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(100, 0, 50, 70);
        panel.add(paginaTextField, gbc);
        operazioneComboBox = new JComboBox();
        operazioneComboBox.setBackground(new Color(-14342875));
        Font operazioneComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, operazioneComboBox.getFont());
        if (operazioneComboBoxFont != null) operazioneComboBox.setFont(operazioneComboBoxFont);
        operazioneComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        operazioneComboBox.setModel(defaultComboBoxModel1);
        operazioneComboBox.setOpaque(true);
        operazioneComboBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridheight = 2;
        gbc.insets = new Insets(50, 0, 0, 50);
        panel.add(operazioneComboBox, gbc);
        indiceParagrafoComboBox = new JComboBox();
        indiceParagrafoComboBox.setBackground(new Color(-14342875));
        Font indiceParagrafoComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceParagrafoComboBox.getFont());
        if (indiceParagrafoComboBoxFont != null) indiceParagrafoComboBox.setFont(indiceParagrafoComboBoxFont);
        indiceParagrafoComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel2 = new DefaultComboBoxModel();
        indiceParagrafoComboBox.setModel(defaultComboBoxModel2);
        indiceParagrafoComboBox.setOpaque(true);
        indiceParagrafoComboBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.insets = new Insets(25, 0, 0, 0);
        panel.add(indiceParagrafoComboBox, gbc);
        visualizzaTesto = new JTextArea();
        visualizzaTesto.setBackground(new Color(-13158601));
        Font visualizzaTestoFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, visualizzaTesto.getFont());
        if (visualizzaTestoFont != null) visualizzaTesto.setFont(visualizzaTestoFont);
        visualizzaTesto.setForeground(new Color(-331531));
        visualizzaTesto.setLineWrap(true);
        visualizzaTesto.setOpaque(true);
        visualizzaTesto.setPreferredSize(new Dimension(100, 300));
        visualizzaTesto.setText("");
        visualizzaTesto.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 0, 0, 0);
        panel.add(visualizzaTesto, gbc);
        propostaTextArea = new JTextArea();
        propostaTextArea.setBackground(new Color(-13158601));
        Font propostaTextAreaFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, propostaTextArea.getFont());
        if (propostaTextAreaFont != null) propostaTextArea.setFont(propostaTextAreaFont);
        propostaTextArea.setForeground(new Color(-331531));
        propostaTextArea.setLineWrap(true);
        propostaTextArea.setName("");
        propostaTextArea.setOpaque(true);
        propostaTextArea.setPreferredSize(new Dimension(150, 300));
        propostaTextArea.setToolTipText("");
        propostaTextArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 50, 0, 0);
        panel.add(propostaTextArea, gbc);
        paragrafoAttualeLabel = new JLabel();
        Font paragrafoAttualeLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, paragrafoAttualeLabel.getFont());
        if (paragrafoAttualeLabelFont != null) paragrafoAttualeLabel.setFont(paragrafoAttualeLabelFont);
        paragrafoAttualeLabel.setForeground(new Color(-331531));
        paragrafoAttualeLabel.setPreferredSize(new Dimension(250, 27));
        paragrafoAttualeLabel.setText("Paragrafo attuale");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(paragrafoAttualeLabel, gbc);
        PropostaLabel = new JLabel();
        Font PropostaLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, PropostaLabel.getFont());
        if (PropostaLabelFont != null) PropostaLabel.setFont(PropostaLabelFont);
        PropostaLabel.setForeground(new Color(-331531));
        PropostaLabel.setHorizontalAlignment(0);
        PropostaLabel.setHorizontalTextPosition(11);
        PropostaLabel.setPreferredSize(new Dimension(300, 27));
        PropostaLabel.setText("Proposta elaborata");
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(PropostaLabel, gbc);
        collegamentoButton = new JButton();
        collegamentoButton.setBorderPainted(true);
        collegamentoButton.setContentAreaFilled(false);
        collegamentoButton.setFocusPainted(false);
        Font collegamentoButtonFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, collegamentoButton.getFont());
        if (collegamentoButtonFont != null) collegamentoButton.setFont(collegamentoButtonFont);
        collegamentoButton.setForeground(new Color(-14342875));
        collegamentoButton.setHorizontalTextPosition(0);
        collegamentoButton.setIcon(new ImageIcon(getClass().getResource("/GUI/img/link icon.png")));
        collegamentoButton.setPreferredSize(new Dimension(50, 50));
        this.$$$loadButtonText$$$(collegamentoButton, this.$$$getMessageFromBundle$$$("GUI/it_IT", "accedi"));
        collegamentoButton.setVerifyInputWhenFocusTarget(false);
        gbc = new GridBagConstraints();
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.insets = new Insets(60, 30, 0, 0);
        panel.add(collegamentoButton, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    private static Method $$$cachedGetBundleMethod$$$ = null;

    private String $$$getMessageFromBundle$$$(String path, String key) {
        ResourceBundle bundle;
        try {
            Class<?> thisClass = this.getClass();
            if ($$$cachedGetBundleMethod$$$ == null) {
                Class<?> dynamicBundleClass = thisClass.getClassLoader().loadClass("com.intellij.DynamicBundle");
                $$$cachedGetBundleMethod$$$ = dynamicBundleClass.getMethod("getBundle", String.class, Class.class);
            }
            bundle = (ResourceBundle) $$$cachedGetBundleMethod$$$.invoke(null, path, thisClass);
        } catch (Exception e) {
            bundle = ResourceBundle.getBundle(path);
        }
        return bundle.getString(key);
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadButtonText$$$(AbstractButton component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panel;
    }

}
