package Model;

import com.sun.source.tree.Tree;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.logging.Logger;

public class Autore extends GestioneAnomalia
{
    public final String username;
    public final Date dataIscrizione;
    private final String password;
    public ArrayList<Pagina> pagScritte = new ArrayList<>();
    public ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
    public ArrayList<Pagina> storiciAccessibili = new ArrayList<>();
    private HashMap<Pagina,HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password)
    {
        this.username = username;
        this.password = password;
        dataIscrizione = new Date();
    }

    public void logIn(String username, String password)
    {
        if(!determinaAnomalie(new String[]{this.password,password},3))
            return;

        if(!determinaAnomalie(new String[]{this.username,username},3))
            return;

        System.out.println("> Accesso effettuato : <Model.Autore>");
    }

    public void logOut()
    {
        System.out.println("> Model.Autore disconnesso!");
    }

    public String ottieniPassword()
    {
        return password;
    }

    public Pagina creaPagina(String titolo)
    {
        if(!determinaAnomalie(new String[]{titolo},4))
            return null;

        if(!determinaAnomalie(new Object[]{titolo,null},5))
            return null;

        Pagina temp = new Pagina(titolo,this);

        pagScritte.add(temp);
        storiciAccessibili.add(temp);

        return  temp;
    }

    public void inviaProposta(Paragrafo daRevisionare, Autore destinatario)
    {
        if(!determinaAnomalie(new Object[]{daRevisionare, null},6))
            return;

        if(!determinaAnomalie(new Object[]{destinatario, null},6))
            return;

        if(!determinaAnomalie(new int[]{daRevisionare.posizione, 0}, 7))
            return;

        int[] temp = {daRevisionare.posizione, daRevisionare.paginaDiRiferimento.testo.size()};

        switch (daRevisionare.operazioneDaEffettuare)
        {
            case Aggiungere -> {
                if(!determinaAnomalie(temp,8))
                    return;

                if(!determinaAnomalie(new Object[]{destinatario,this},11))
                    return;
            }
            case Rimuovere-> {
                if(!determinaAnomalie(temp,9))
                    return;
            }
            case Aggiornare -> {
                if(!determinaAnomalie(temp,10))
                    return;
            }
        }

        // nel caso in cui il mittente fosse proprio il proprietario della pagina,
        // allora la modifica verrà apportata senza alcuna valutazione.
        if(destinatario != this)
            destinatario.riceviNotifica(daRevisionare);
        else
            daRevisionare.paginaDiRiferimento.applicaParagrafo(daRevisionare);
    }

    public  void riceviNotifica(Paragrafo daNotificare)
    {
        ArrayList<Paragrafo> listaTemporanea = new ArrayList<>();
        HashMap<Integer,ArrayList<Paragrafo>> hashMapTemporanea = new HashMap<>();
        var nomeTemporaneo = proposteInAttesa.get(daNotificare.paginaDiRiferimento);

        if(proposteInAttesa.containsKey(daNotificare.paginaDiRiferimento))
            if(nomeTemporaneo.containsKey(daNotificare.posizione))
            {
                nomeTemporaneo.get(daNotificare.posizione).add(daNotificare);
            }
            else
            {
                listaTemporanea.add(daNotificare);
                nomeTemporaneo.put(daNotificare.posizione,listaTemporanea);
            }
        else
        {
            listaTemporanea.add(daNotificare);
            hashMapTemporanea.put(daNotificare.posizione, listaTemporanea);

            proposteInAttesa.put(daNotificare.paginaDiRiferimento, hashMapTemporanea);
        }
    }

    /** Visualizza le pagine interessate dalle proposte ricevute. */
    public void mostraPagineSoggetteAProposta()
    {
        System.out.println("> Sono disponibili modifiche alle seguenti pagine: ");

        for( var pag: proposteInAttesa.keySet())
        {
            System.out.println(pag.titolo);
        }

    }

    public HashMap<Pagina,HashMap<Integer,ArrayList<Paragrafo>>>  ottieniProposte()
    {
        // ottiene dal database la lista delle proposte inerenti a questo autore

        ArrayList<Paragrafo> listaProposte = new ArrayList<>();


        listaProposte.add(new Paragrafo("ciao", 0, pagScritte.get(0), this));
        listaProposte.add(new Paragrafo(0, pagScritte.get(1), this));
        listaProposte.add(new Paragrafo("cola", 0, pagScritte.get(1), this));
        listaProposte.add(new Paragrafo("birra", 0,pagScritte.get(0), this));
        listaProposte.add(new Paragrafo("alcol", 1,pagScritte.get(0), this));

        for(Paragrafo par : listaProposte)
        {
            if(!proposteInAttesa.containsKey(par.paginaDiRiferimento))
                proposteInAttesa.put(par.paginaDiRiferimento, new HashMap<>());
        }

        for(Paragrafo par : listaProposte)
        {
            if(!proposteInAttesa.get(par.paginaDiRiferimento).containsKey(par.posizione))
                proposteInAttesa.get(par.paginaDiRiferimento).put(par.posizione, new ArrayList<>());
        }

        for(Pagina pag : proposteInAttesa.keySet())
        {
            for(int pos : proposteInAttesa.get(pag).keySet())
            {
                for(Paragrafo par : listaProposte)
                {
                    if(par.paginaDiRiferimento == pag && par.posizione == pos)
                        proposteInAttesa.get(pag).get(pos).add(par);
                }
            }
        }

        return proposteInAttesa;
    }

    public Pagina ottieniPagina(String titolo)
    {
        if(!determinaAnomalie(new Object[]{titolo, null},12))
            return null;

        for (var pag : proposteInAttesa.keySet())
        {
            if(pag.titolo.contentEquals(titolo))
                return pag;
        }

        inviaAnomalia(22);
        return  null;
    }

    /** Visualizza i paragrafi, della pagina in esame, che sono indicati nelle notifiche. */
    public void mostraIndiciParagrafiSoggettiAProposte(Pagina paginaSelezionata)
    {
        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            inviaAnomalia(14);
            return;
        }

        System.out.println("> Indici paragrafi soggetti a proposte: ");

        for ( var key : proposteInAttesa.get(paginaSelezionata).keySet())
        {
            System.out.println("Indice [" + key.intValue() + "]");

            for(int i = 0; i < proposteInAttesa.get(paginaSelezionata).get(key).size(); i++)
            {
                System.out.print("  " + i + ")  [");
                System.out.print((proposteInAttesa.get(paginaSelezionata).get(key).get(i).operazioneDaEffettuare));
                System.out.print("] ");
                System.out.println(proposteInAttesa.get(paginaSelezionata).get(key).get(i).contenuto);
            }
        }
    }

    public Paragrafo ottieniParagrafo(int indiceProposta, int indiceParagrafo, Pagina paginaSelezionata)
    {
        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            inviaAnomalia(14);
            return null;
        }

        if(!proposteInAttesa.get(paginaSelezionata).containsKey(indiceParagrafo))
        {
            inviaAnomalia(15);
            return null;
        }

        if(!determinaAnomalie(new int[]{indiceProposta,0},20))
            return null;

        if(!determinaAnomalie(new int[]{indiceProposta, proposteInAttesa.get(paginaSelezionata).size()},15))
            return null;

        return  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo).get(indiceProposta);
    }

    public void elaborazioneProposta(Paragrafo propostaSelezionata)
    {
        // dire al database che il paragrado è stato accettato
        propostaSelezionata.stato = Stato.Approvato;
        propostaSelezionata.paginaDiRiferimento.applicaParagrafo(propostaSelezionata);

        var storicivistiDalMittente  = propostaSelezionata.proprietario.storiciAccessibili;

        if(!storicivistiDalMittente.contains(propostaSelezionata.paginaDiRiferimento))
            storicivistiDalMittente.add(propostaSelezionata.paginaDiRiferimento);

        var indiceParagrafo = proposteInAttesa.get(propostaSelezionata.paginaDiRiferimento).get(propostaSelezionata.posizione);

        indiceParagrafo.remove(propostaSelezionata);

        while (!indiceParagrafo.isEmpty())
        {
            // dire al database che sono stati rifiutati
            indiceParagrafo.getFirst().stato = Stato.Rifiutato;
            indiceParagrafo.remove(indiceParagrafo.getFirst());
        }

        proposteInAttesa.get(propostaSelezionata.paginaDiRiferimento).remove(propostaSelezionata.posizione);
    }

    public void rifiutaTutteLeProposte(int indiceParagrafo, Pagina paginaSelezionata)
    {
        var listaProposte =  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo);

        do
        {
            // informare il db
            listaProposte.get(0).stato = Stato.Rifiutato;
            listaProposte.remove(0);
        }while (listaProposte.isEmpty());

        proposteInAttesa.get(paginaSelezionata).remove(indiceParagrafo);
    }

    public void mostraStoriciAccessibili()
    {
        System.out.println("> lista storici accessibili: ");

        for( int i = 0; i < storiciAccessibili.size(); i++)
        {
            System.out.print(i);
            System.out.print(") ");
            System.out.print(storiciAccessibili.get(i).titolo);

            if(storiciAccessibili.get(i).proprietario == this)
                System.out.println(" [Proprietario]");

            System.out.println();
        }
    }

    public Pagina ottienePaginaDaListaStorici(String titoloPagina)
    {
        for(var pag : storiciAccessibili)
        {
            if(pag.titolo.contentEquals(titoloPagina))
                return pag;
        }

        inviaAnomalia(15);
        return null;
    }

    public void mostraStorico(Pagina paginaDiRiferimento, int indiceParagrafo)
    {
        if(!storiciAccessibili.contains(paginaDiRiferimento))
        {
            inviaAnomalia(25);
            return;
        }

        var storicoInEsame = paginaDiRiferimento.storicoPagina;

        if(!storicoInEsame.containsKey(indiceParagrafo))
        {
            inviaAnomalia(15);
            return;
        }

        System.out.println("> info storico -> paragrafo " + indiceParagrafo + ":");

        for( Paragrafo par :  storicoInEsame.get(indiceParagrafo))
        {
            System.out.println(par.contenuto);
        }
    }
}