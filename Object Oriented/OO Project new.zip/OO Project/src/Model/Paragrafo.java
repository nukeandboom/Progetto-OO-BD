package Model;

import java.util.Date;

public class Paragrafo
{
    public String contenuto;
    public Stato stato;
    public Azione operazioneDaEffettuare;
    public Date data_creazione;
    public int posizione;
    public Autore proprietario;
    public Pagina paginaDiRiferimento;
    public Collegamento collegamento;

    /** Questo costruttore viene utilizzato per modificare un paragrafo dalla pagina di destinazione. */
    public  Paragrafo(String contenuto, int posizione, Pagina pagina, Autore proprietario)
    {
        this.contenuto = contenuto;
        this.posizione = posizione;
        this.proprietario = proprietario;
        stato = Stato.InAttesa;
        operazioneDaEffettuare = Azione.Aggiornare;
        paginaDiRiferimento = pagina;
        data_creazione = new Date();
        proprietario.paragrafiScritti.add(this);
    }

    /** Questo costruttore viene utilizzato per aggiungere un paragrafo alla pagina di destinazione. */
    public  Paragrafo(String contenuto, Pagina pagina, Autore proprietario)
    {
        this.contenuto = contenuto;
        this.posizione = pagina.testo.size();
        this.proprietario = proprietario;
        stato = Stato.InAttesa;
        operazioneDaEffettuare = Azione.Aggiungere;
        paginaDiRiferimento = pagina;
        data_creazione = new Date();
        proprietario.paragrafiScritti.add(this);
    }

    /** Questo costruttore viene utilizzato per eliminare un paragrafo dalla pagina di destinazione. */
    public  Paragrafo(int posizione, Pagina pagina, Autore proprietario)
    {
        this.contenuto = "";
        this.posizione = posizione;
        this.proprietario = proprietario;
        stato = Stato.InAttesa;
        operazioneDaEffettuare = Azione.Rimuovere;
        paginaDiRiferimento = pagina;
        data_creazione = new Date();
        proprietario.paragrafiScritti.add(this);
    }
}
