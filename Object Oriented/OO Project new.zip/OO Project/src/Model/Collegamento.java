package Model;

public class Collegamento extends GestioneAnomalia
{
    public Pagina paginaDiProvenienza;
    public Pagina paginaDaRaggiungere;

    public Collegamento(Pagina paginaDiProvenienza, Pagina paginaDaRaggiungere)
    {
        if(determinaAnomalie(new Object[]{paginaDiProvenienza,paginaDaRaggiungere},23))
            return;

        this.paginaDaRaggiungere = paginaDaRaggiungere;
        this.paginaDiProvenienza = paginaDiProvenienza;
    }
}
