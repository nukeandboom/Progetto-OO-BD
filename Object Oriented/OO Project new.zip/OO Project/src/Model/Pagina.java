package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Pagina
{
    public String titolo;
    public Date   dataCreazione;
    public Autore proprietario;
    public int valutazione;
    public ArrayList<Utente> visitatori = new ArrayList<>();
    public ArrayList<Paragrafo> testo = new ArrayList<>();
    public HashMap<Integer,ArrayList<Paragrafo>> storicoPagina = new HashMap<>();

    public Pagina(String titolo, Autore proprietario)
    {
        this.titolo = titolo;
        this.proprietario = proprietario;
        dataCreazione = new Date();
    }

    public  void applicaParagrafo(Paragrafo daApplicare)
    {
        switch (daApplicare.operazioneDaEffettuare)
        {
            case Aggiungere ->
            {
                ArrayList<Paragrafo> listaTemporanea = new ArrayList<>();
                listaTemporanea.add(daApplicare);
                storicoPagina.put(testo.size(), listaTemporanea);
                daApplicare.posizione = testo.size();
                testo.add(daApplicare);
            }

            // nel caso di Remove, il contenuto della variabile
            // "daApplicare" è stato preventivamente impostato come "", al fine
            // di imitare la presenza di un paragrafo cancellato sulla pagina.
            case Aggiornare, Rimuovere ->
            {
                storicoPagina.get(daApplicare.posizione).getLast().stato = Stato.Scartato;
                storicoPagina.get(daApplicare.posizione).add(daApplicare);
                testo.set(daApplicare.posizione,daApplicare);
            }
        }
    }

    public int ottieniValutazionePagina()
    {
        return valutazione/visitatori.size();
    }
}
