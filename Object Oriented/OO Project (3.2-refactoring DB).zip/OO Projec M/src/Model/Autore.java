package Model;

import ImplementazioneDAO.ImplementazionePostgresDAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Autore extends GestioneAnomalia
{
    public final String username;
    private final Date dataIscrizione;
    private final String password;
    public int punteggio = 0;
    public ArrayList<String> pagScritte = new ArrayList<>();
    public ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
    private ArrayList<Pagina> storiciAccessibili = new ArrayList<>();
    private HashMap<String, HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password, Date dataIscrizione, int punteggio)
    {
        this.username = username;
        this.password = password;
        this.dataIscrizione = dataIscrizione;
        this.punteggio = punteggio;
    }

    public void creaPagina(String titoloPaginaDiRiferimento)
    {
        pagScritte.add(titoloPaginaDiRiferimento);
       // storiciAccessibili.add(paginaDiRiferimento);
    }

    public Paragrafo creaParagrafo(String contenutoParagrafo, int posizione, Pagina paginaDiDestinazione)
    {
        return  new Paragrafo(contenutoParagrafo,
                posizione,
                paginaDiDestinazione,
                this);
    }

    public void inviaProposta(Paragrafo daRevisionare, Autore destinatario, String pagina)
    {
        if(destinatario == this)
        {
            daRevisionare.impostaStato(Stato.Approvato);
            ImplementazionePostgresDAO.implementaPropostaNelDB(daRevisionare, this, pagina);
        }
        else
            ImplementazionePostgresDAO.caricaPropostaNelDB(daRevisionare, destinatario, this);
    }

    public HashMap<String,HashMap<Integer,ArrayList<Paragrafo>>> ottieniNotifiche()
    {
        ArrayList<String> titoliPagine =  ImplementazionePostgresDAO.ottieniListaNomiPagineSoggetteAProposte();

        HashMap<String,HashMap<Integer,ArrayList<Paragrafo>>> hashMapNotifiche = new HashMap<>();
        HashMap<Integer,ArrayList<Paragrafo>> hashMapIndiciParagrafi;

        for(String str : titoliPagine)
        {
            hashMapIndiciParagrafi = ImplementazionePostgresDAO.ottieniHashMapIndiceParagrafiInAttesa(str);
            hashMapNotifiche.put(str, hashMapIndiciParagrafi);
        }

        return hashMapNotifiche;
    }

    public void elaborazioneProposta(Paragrafo propostaSelezionata, int indiceParagrafo, String pagina)
    {

        propostaSelezionata.impostaStato(Stato.Approvato);
        ImplementazionePostgresDAO.aumentaPunteggioAutore(propostaSelezionata.ottieniNomeAutore());
        ImplementazionePostgresDAO.implementaPropostaNelDB(propostaSelezionata, this, pagina);

        rifiutaTutteLeProposteDiUnIndice(indiceParagrafo,pagina);
    }

    public void rifiutaTutteLeProposteDiUnIndice(int indiceParagrafo, String paginaSelezionata)
    {
        ImplementazionePostgresDAO.eliminaProposteInerentiAdUnParagrafo(paginaSelezionata, indiceParagrafo);
    }

    public ArrayList<Pagina> ottieniListaStorici()
    {
        return ImplementazionePostgresDAO.ottieniStoricoAutore(this);
    }

    /*
    public void mostraStoriciAccessibili()
    {
        System.out.println("> lista storici accessibili: ");

        for( int i = 0; i < storiciAccessibili.size(); i++)
        {
            System.out.print(i);
            System.out.print(") ");
            System.out.print(storiciAccessibili.get(i).titolo);

            if(storiciAccessibili.get(i).ottieniAutore() == this)
                System.out.println(" [Proprietario]");

            System.out.println();
        }
    }

    public Pagina ottienePaginaDaListaStorici(String titoloPagina)
    {
        for(var pag : storiciAccessibili)
        {
            if(pag.titolo.contentEquals(titoloPagina))
                return pag;
        }

        inviaAnomalia(15);
        return null;
    }

    public void mostraStorico(Pagina paginaDiRiferimento, int indiceParagrafo)
    {
        if(!storiciAccessibili.contains(paginaDiRiferimento))
        {
            inviaAnomalia(25);
            return;
        }

        var storicoInEsame = paginaDiRiferimento.storicoPagina;

        if(!storicoInEsame.containsKey(indiceParagrafo))
        {
            inviaAnomalia(15);
            return;
        }

        System.out.println("> info storico -> paragrafo " + indiceParagrafo + ":");

        for( Paragrafo par :  storicoInEsame.get(indiceParagrafo))
        {
            System.out.println(par.ottieniContenuto());
        }
    }


     */
}