public enum Azione
{
    Aggiungere,
    Rimuovere,
    Aggiornare
}
