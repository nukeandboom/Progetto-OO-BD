import java.util.ArrayList;

public class Utente extends GestioneAnomalia{
    protected int id;
    private boolean ConnectedAsUser;
    public ArrayList<Visita> cronologia = new ArrayList<>();
    public Pagina paginaAttualmenteVisitata;
    public Autore child;
    public Utente(int id)
    {
        this.id = id;
        ConnectedAsUser = false;
    }
    public Autore SignInComeAutore(String username, String password)
    {
       if(!DeterminaAnomalie(ConnectedAsUser,true,0))
           return null;

       if(!DeterminaAnomalie(new String[]{username},1) || !DeterminaAnomalie(new String[]{password},1))
           return null;

        System.out.println("> Registrazione ultimata con successo");
        return  new Autore(username,password,id);
    }

    public void VisitaPaginaTramiteCollegamento(Collegamento collegamento)
    {
        if(!DeterminaAnomalie(ConnectedAsUser,true,0))
            return;

        cronologia.add(new Visita(this,collegamento.paginaDaRaggiungere));
        paginaAttualmenteVisitata = collegamento.paginaDaRaggiungere;
        collegamento.paginaDaRaggiungere.MostraTesto();
    }

    public void RecensisciPagina(int recensione, Pagina daRecensire)
    {
        if(!DeterminaAnomalie(ConnectedAsUser,true,0))
            return;

        if(!DeterminaAnomalie(new Object[]{daRecensire},23))
            return;

        if(!DeterminaAnomalie(new Object[]{paginaAttualmenteVisitata, daRecensire},21))
            return;

        if(!DeterminaAnomalie(new int[]{recensione,1},19))
            return;

        if(!DeterminaAnomalie(new int[]{recensione,5},20))
            return;

        cronologia.getLast().recensione += recensione;
    }

    public void LogIn()
    {
        ConnectedAsUser = true;
        System.out.println("> Accesso effettuato : <Utente>");
    }
    public void LogOff()
    {
        ConnectedAsUser = false;

        if(child.ConnessoComeAutore)
            child.LogOff();

        System.out.println("> Utente disconnesso!");
    }
}
