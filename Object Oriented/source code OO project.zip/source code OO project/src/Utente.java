public class Utente extends GestioneAnomalia{
    protected int id;
    private boolean ConnectedAsUser;
    private Pagina paginaAttuale;
    public Autore child;
    public Utente(int id)
    {
        this.id = id;
        ConnectedAsUser = false;
    }
    public Autore SignInComeAutore(String username, String password)
    {
       if(!DeterminaAnomalie(ConnectedAsUser,true,0))
           return null;

       if(!DeterminaAnomalie(new String[]{username},1) || !DeterminaAnomalie(new String[]{password},1))
           return null;

        System.out.println("> Registrazione ultimata con successo");
        return  new Autore(username,password,id);
    }

    public void VisitaPagina(Collegamento collegamento)
    {
        if(!DeterminaAnomalie(ConnectedAsUser,true,0))
            return;

        paginaAttuale = collegamento.paginaDaRaggiungere;
        collegamento.paginaDaRaggiungere.MostraTesto();
    }

    public void LogIn()
    {
        ConnectedAsUser = true;
        System.out.println("> Accesso effettuato : <Utente>");
    }
    public void LogOff()
    {
        ConnectedAsUser = false;

        if(child.ConnectedAsAuthor)
            child.LogOff();

        System.out.println("> Utente disconnesso!");
    }
}
