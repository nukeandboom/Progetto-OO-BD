public class Collegamento extends GestioneAnomalia
{
    public Pagina paginaDiProvenienza;
    public Pagina paginaDaRaggiungere;

    public Collegamento(Pagina paginaDiProvenienza, Pagina paginaDaRaggiungere)
    {
        if(DeterminaAnomalie(new Object[]{paginaDiProvenienza,paginaDaRaggiungere},25))
            return;

        this.paginaDaRaggiungere = paginaDaRaggiungere;
        this.paginaDiProvenienza = paginaDiProvenienza;
    }
}
