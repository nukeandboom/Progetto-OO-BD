public class Collegamento
{
    public Pagina paginaDiProvenienza;
    public Pagina paginaDaRaggiungere;

    public Collegamento(Pagina paginaDiProvenienza, Pagina paginaDaRaggiungere)
    {
        this.paginaDaRaggiungere = paginaDaRaggiungere;
        this.paginaDiProvenienza = paginaDiProvenienza;
    }
}
