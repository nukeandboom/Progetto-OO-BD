
public class Main {
    public static void main(String[] args)
    {
        Utente user1 = new Utente(0);
        Utente user2 = new Utente(1);

        user1.LogIn();
        user2.LogIn();

        Autore author1 = user1.SignInComeAutore("lello","1234");
        Autore author2 = user2.SignInComeAutore("le","1234");
        author1.Login("lello","1234");
        author2.Login("le","1234");

        // fai in modo che non possano esistere due Autori con lo stesso username
        // fai in modo che non ci possando essere due pagine con lo stesso titolo

        Pagina pag1 = author1.CreaPagina("Wiki");
        Pagina pag2 = author1.CreaPagina("Ubuntu");

        Paragrafo par1 = new Paragrafo("Ciao",0,pag1);
        Paragrafo par2 = new Paragrafo("hey",0,pag2);

        Paragrafo par3 = new Paragrafo("hey",pag1);
        Paragrafo par4 = new Paragrafo("ciao",pag2);


        author1.InviaProposta(par3,author1);
        author1.InviaProposta(par4,author1);

        Collegamento col1 = new Collegamento(null, pag2);
        author1.VisitaPagina(col1);



 /*

        Paragrafo par5 = new Paragrafo(0,pag1);

        author2.InviaProposta(par5,author1);

        author1.MostraPagineSoggetteAProposta();
        pag2 = author1.OttieniPagina("Wiki");
        author1.MostraProposteInerentiAdUnaPagina(pag2);
        par3 = author1.OttieniParagrafo(0,pag2);
        author1.ElaborazioneProposta(par3,pag2);
        */

        /*
        Paragrafo par6 = new Paragrafo("lol",0,pag1);

        author2.InviaProposta(par6,author1);
        author1.MostraPagineSoggetteAProposta();
        pag2 = author1.OttieniPagina("Wiki");
        author1.MostraProposteInerentiAdUnaPagina(pag2);
        par3 = author1.OttieniParagrafo(0,pag2);
        author1.ElaborazioneProposta(par3,pag2);
        */


       //pag2.MostraTesto();

    }
}