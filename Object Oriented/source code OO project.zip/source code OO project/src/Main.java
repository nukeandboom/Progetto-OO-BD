import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args)
    {
        Utente user1 = new Utente(0);
        Utente user2 = new Utente(1);

        user1.logIn();
        user2.logIn();

        Autore author1 = user1.signInComeAutore("lello","1234");
        Autore author2 = user2.signInComeAutore("le","1234");
        author1.logIn("lello","1234");
        author2.logIn("le","1234");

        // (SQL) fai in modo che non possano esistere due Autori con lo stesso username
        // (SQL) fai in modo che non ci possando essere due pagine con lo stesso titolo

        Pagina pag1 = author1.creaPagina("Wiki");

        Paragrafo par1 = new Paragrafo("hey", 0,pag1,author2);
        Paragrafo par2 = new Paragrafo("ciao",0,pag1,author2);
        Paragrafo par3 = new Paragrafo("cwd",1,pag1,author2);

        author1.inviaProposta(new Paragrafo("prop1",pag1,author1),author1);
        author1.inviaProposta(new Paragrafo("prop2",pag1,author1),author1);

        author2.inviaProposta(par1,author1);
        author2.inviaProposta(par2,author1);
        author2.inviaProposta(par3,author1);

        author1.mostraPagineSoggetteAProposta();
        Pagina pagTemp = author1.ottieniPagina("Wiki");
        author1.mostraIndiciParagrafiSoggettiAProposte(pagTemp);
        Paragrafo parTemp = author1.ottieniParagrafo(0,0,pagTemp);
        author1.elaborazioneProposta(parTemp);

        pagTemp.MostraTesto();

        author1.mostraPagineSoggetteAProposta();
        pagTemp = author1.ottieniPagina("Wiki");
        author1.mostraIndiciParagrafiSoggettiAProposte(pagTemp);

        author1.mostraStoriciAccessibili();
        pagTemp = author1.ottienePaginaDaListaStorici("Wiki");
        author1.mostraStorico(pagTemp,0);



/*
        Paragrafo par5 = new Paragrafo(0,pag1);

        author2.InviaProposta(par5,author1);

        author1.MostraPagineSoggetteAProposta();
        pag2 = author1.OttieniPagina("Wiki");
        author1.MostraProposteInerentiAdUnaPagina(pag2);
        par3 = author1.OttieniParagrafo(0,pag2);
        author1.ElaborazioneProposta(par3,pag2);
        */

        /*
        Paragrafo par6 = new Paragrafo("lol",0,pag1);

        author2.InviaProposta(par6,author1);
        author1.MostraPagineSoggetteAProposta();
        pag2 = author1.OttieniPagina("Wiki");
        author1.MostraProposteInerentiAdUnaPagina(pag2);
        par3 = author1.OttieniParagrafo(0,pag2);
        author1.ElaborazioneProposta(par3,pag2);
        */


       //pag2.MostraTesto();

    }
}