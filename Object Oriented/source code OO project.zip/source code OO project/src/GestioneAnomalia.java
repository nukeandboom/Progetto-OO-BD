
public abstract class GestioneAnomalia
{
    static final String[] listaAnomalie = {
            "> [ERRORE 0 ]: E' necessario connettersi come utente!",
            "> [ERRORE 1 ]: Le credenziali non possono essere vuote!",
            "> [ERRORE 2 ]: L'autore è già connesso!",
            "> [ERRORE 3 ]: Credenziali errate!",
            "> [ERRORE 4 ]: Creazione collegamento fallita -> Il titolo della pagina non può essere vuoto!",
            "> [ERRORE 5 ]: Creazione collegamento fallita -> Il titolo della pagina non può essere nullo!",
            "> [ERRORE 6 ]: Invio proposta fallito -> le informazioni inserite sono inesistenti!",
            "> [ERRORE 7 ]: Invio proposta fallito -> Indice paragrafo non può essere minore di 0!",
            "> [ERRORE 8 ]: Invio proposta fallito -> Indice paragrafo inesistente!",
            "> [ERRORE 9 ]: Invio proposta fallito -> paragrafo da eliminare inesistente!",
            "> [ERRORE 10]: Invio proposta fallito -> paragrafo da aggiornare inesistente!",
            "> [ERRORE 11]: Invio proposta fallito -> soltanto il proprietario della pagina può aggiungere paragrafi!",
            "> [ERRORE 12]: Raccolta info fallita -> il titolo inserito non può essere nullo!",
            "> [ERRORE 13]: Elaborazione proposta fallita -> il paragrafo selezionato non risulta nelle notifiche!",
            "> [ERRORE 14]: Raccolta info fallita -> la pagina selezionata non risulta nelle notifiche!",
            "> [ERRORE 15]: Raccolta info fallita -> Indice paragrafo inesistente!",
            "> [ERRORE 16]: Non è possibile utilizzare le proprietà da autore senza aver effettuato il login!",
            "> [ERRORE 17]: Valore non accettabile; si prega di scegliere un valore compreso tra 1 e 5!",
            "> [ERRORE 18]: Selezionare un valore compreso tra 1 e 5!",
            "> [ERRORE 19]: Non è possibile recensire una pagina, a meno chè non ci si trovi sulla pagina in questione!",
            "> [ERRORE 20]: Raccolta info fallita -> La posizione del paragrafo non può essere negativa!",
            "> [ERRORE 21]: Recensione pagina fallita -> la pagnina inserita non può essere nulla!",
            "> [ERRORE 22]: Raccolta info fallita -> il titolo inserito non risulta presente nelle notifiche!",
            "> [ERRORE 23]: Creazione collegamento fallita -> la pagina d'arrivo e di provenienza non possono essere uguali!",
            "> [ERRORE 24]: Elaborazione proposta fallita -> la pagina selezionata risulta inesistente!",
            "> [ERRORE 25]: Raccolta info fallita -> lo storico selezionato non risulta presente tra quelli accessibili!"
            };

    public void inviaAnomalia(int codice)
    {
        System.out.println(listaAnomalie[codice]);
    }
    public boolean determinaAnomalie(int[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 7, 17 -> {
                    if(dati[0] < dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                case 8, 18 -> {
                    if(dati[0] > dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                case 9, 10 ->{
                    if(dati[0] >= dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }
        }catch (IndexOutOfBoundsException exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean determinaAnomalie(Object[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 1, 5, 6, 12, 21, 23 -> {
                    if(dati[0] == dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
                case 2, 11, 19 ->{
                    if(dati[0] != dati[1])
                        throw new Exception (listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }
        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean determinaAnomalie(String[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 1,4 -> {
                    if(dati[0].contentEquals(""))
                        throw new  Exception(listaAnomalie[codice]);
                }
                case 3 ->{
                    if(!dati[0].contentEquals(dati[1]))
                        throw new  Exception (listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }

        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public  boolean determinaAnomalie(boolean err, boolean statoPrevisto, int codice)
    {
        try {
            if(err != statoPrevisto)
                throw new IllegalStateException(listaAnomalie[codice]);

        } catch (IllegalStateException exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }
}
