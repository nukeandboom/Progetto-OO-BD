public abstract class GestioneAnomalia
{
    String[] listaAnomalie = {
            "> [ERRORE]: E' necessario connettersi come utente!",
            "> [ERRORE]: Le credenziali non possono essere vuote!",
            "> [ERRORE]: L'autore è già connesso!",
            "> [ERRORE]: credenziali errate!",
            "> [ERRORE]: Il titolo della pagina non può essere vuoto!",
            "> [ERRORE]: Il titolo della pagina non può essere nullo!",
            "> [ERRORE]: Invio proposta fallito -> le informazioni inserite sono inesistenti!",
            "> [ERRORE]: Invio proposta fallito -> Indice paragrafo non può essere minore di 0!",
            "> [ERRORE]: Invio proposta fallito -> Indice paragrafo inesistente!",
            "> [ERRORE]: Invio proposta fallito -> paragrafo da eliminare inesistente!",
            "> [ERRORE]: Invio proposta fallito -> non è possibile eliminare paragrafi da una pagina vuota!",
            "> [ERRORE]: Invio proposta fallito -> paragrafo da aggiornare inesistente!",
            "> [ERRORE]: Invio proposta fallito -> non è possibile aggiornare paragrafi da una pagina vuota!",
            "> [ERRORE]: Invio proposta fallito -> soltanto il proprietario della pagina può aggiungere paragrafi!",
            "> [ERRORE]: raccolta info fallita -> il titolo inserito non può essere nullo!",
            "> [ERRORE]: Elaborazione proposta fallita -> la pagina selezionata non può essere nulla!",
            "> [ERRORE]: Elaborazione proposta fallita -> la pagina selezionata non risulta nelle notifiche!",
            "> [ERRORE]: Elaborazione proposta fallita -> il paragrafo selezionato non può essere nullo!",
            "> [ERRORE]: Elaborazione proposta fallita -> il paragrafo selezionato non risulta nelle notifiche!",
            "> [ERRORE]: raccolta info fallita -> la pagina inserita non può essere nullo!",
            "> [ERRORE]: raccolta info fallita -> la pagina selezionata non risulta nelle notifiche!",
            "> [ERRORE]: raccolta info fallita -> Indice paragrafo inesistente!",
            "> [ERRORE]: Non è possibile utilizzare le proprietà da autore senza aver effettuato il login!",
            "> [ERRORE]: Valore non accettabile; si prega di scegliere un valore compreso tra 1 e 5!",
            "> [ERRORE]: Selezionare un valore compreso tra 1 e 5!",
            "> [ERRORE]: Non è possibile recensire una pagina, a meno chè non ci si trovi sulla pagina in questione!",
            "> [ERRORE]: raccolta info fallita -> La posizione del paragrafo non può essere negativa!",
            "> [ERRORE]: recensione pagina fallita -> la pagnina inserita non può essere nulla!"
            };

    public void InviaErrore(int codice)
    {
        System.out.println(listaAnomalie[codice]);
    }
    public boolean DeterminaAnomalie(int[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 7, 23 -> {
                    if(dati[0] < dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
                case 8,9,11,21,24 -> {
                    if(dati[0] > dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
                case 10,12 -> {
                    if(dati[0] == dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
            }
        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean DeterminaAnomalie(Object[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 0, 1, 5, 6, 14, 15, 17, 19, 27 -> {
                    if(dati[0] == null)
                        throw new Exception(listaAnomalie[codice]);
                }
                case 2, 25 ->{
                    if(dati[0] != dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
            }
        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean DeterminaAnomalie(String[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 1,4 -> {
                    if(dati[0].contentEquals(""))
                        throw new Exception(listaAnomalie[codice]);
                }
                case 3 ->{
                    if(!dati[0].contentEquals(dati[1]))
                        throw new Exception(listaAnomalie[codice]);
                }
            }

        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public  boolean DeterminaAnomalie(boolean err, boolean statoPrevisto, int codice)
    {
        try {
            switch (codice)
            {
                case 0,1,22 -> {
                    if(err != statoPrevisto)
                        throw new Exception(listaAnomalie[codice]);
                }
            }
        } catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }
}
