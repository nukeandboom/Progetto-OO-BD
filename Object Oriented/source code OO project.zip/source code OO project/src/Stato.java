public enum Stato
{
    Approved,
    Refused,
    Pending
}
