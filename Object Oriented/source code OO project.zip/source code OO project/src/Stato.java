public enum Stato
{
    Approvato,
    Rifiutato,
    InAttesa,
    Scartato
}
