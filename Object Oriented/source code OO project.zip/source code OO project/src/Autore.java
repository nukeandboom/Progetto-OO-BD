import java.util.*;

public class Autore  extends  Utente
{
    protected boolean ConnessoComeAutore = false;
    public final String username;
    public final Date dataIscrizione;
    private final String password;
    public int punteggio = 0;
    public ArrayList<Pagina> pagScritte = new ArrayList<>();
    public ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
    public ArrayList<Pagina> storiciAccessibili = new ArrayList();
    private HashMap<Pagina,HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password,int id)
    {
        super(id);
        this.username = username;
        this.password = password;
        dataIscrizione = new Date();
    }

    public  void Login(String username, String password)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,false,2))
            return;

        if(!DeterminaAnomalie(new String[]{this.password,password},3))
            return;

        if(!DeterminaAnomalie(new String[]{this.username,username},3))
            return;

        ConnessoComeAutore = true;
        System.out.println("> Accesso effettuato : <Autore>");
    }

    public void LogOff()
    {
        ConnessoComeAutore = false;
        System.out.println("> Autore disconnesso!");
    }

    public Pagina CreaPagina(String titolo)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return null;

        if(!DeterminaAnomalie(new String[]{titolo},4))
            return null;

        if(!DeterminaAnomalie(new Object[]{titolo},5))
            return null;

        Pagina temp = new Pagina(titolo,this);
        pagScritte.add(temp);

        return  temp;
    }

    public void InviaProposta(Paragrafo daRevisionare, Autore destinatario)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return;

        if(!DeterminaAnomalie(new Object[]{daRevisionare},6))
            return;

        if(!DeterminaAnomalie(new Object[]{destinatario},6))
            return;

        if(!DeterminaAnomalie(new int[]{daRevisionare.posizione,0}, 7))
            return;

        int[] temp = {daRevisionare.posizione, daRevisionare.paginaDiRiferimento.testo.size()};

        switch (daRevisionare.operazioneDaEffettuare) {
            case Aggiungere -> {
                if(!DeterminaAnomalie(temp,8))
                    return;

                if(!DeterminaAnomalie(new Object[]{destinatario,this},13))
                    return;
            }
            case Rimuovere-> {
                if(!DeterminaAnomalie(temp,9) || !DeterminaAnomalie(temp,10))
                    return;
            }
            case Aggiornare -> {
                if(!DeterminaAnomalie(temp,11) || !DeterminaAnomalie(temp,12))
                    return;
            }
        }

        // nel caso in cui il mittente fosse proprio il proprietario della pagina,
        // allora la modifica verrà apportata senza alcuna valutazione.
        if(destinatario != this)
            destinatario.RiceviNotifica(daRevisionare);
        else
            daRevisionare.paginaDiRiferimento.ApplicaParagrafo(daRevisionare);
    }

    public  void RiceviNotifica(Paragrafo daNotificare)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return ;

        ArrayList<Paragrafo> listaTemporanea = new ArrayList<>();
        HashMap<Integer,ArrayList<Paragrafo>> hashMapTemporanea = new HashMap<>();
        var nomeTemporaneo = proposteInAttesa.get(daNotificare.paginaDiRiferimento);

        if(proposteInAttesa.containsKey(daNotificare.paginaDiRiferimento))
            if(nomeTemporaneo.containsKey(daNotificare.posizione))
                nomeTemporaneo.get(daNotificare.posizione).add(daNotificare);
            else
            {
                listaTemporanea.add(daNotificare);
                nomeTemporaneo.put(daNotificare.posizione,listaTemporanea);
            }
        else
        {
            listaTemporanea.add(daNotificare);
            hashMapTemporanea.put(daNotificare.posizione, listaTemporanea);

            proposteInAttesa.put(daNotificare.paginaDiRiferimento, hashMapTemporanea);
        }
    }

    /** Visualizza le pagine interessate dalle proposte ricevute. */
    public void MostraPagineSoggetteAProposta()
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return;

        System.out.println("> Sono disponibili modifiche alle seguenti pagine: ");

        for( var pag: proposteInAttesa.keySet())
        {
            System.out.println(pag.titolo);
        }
    }

    public Pagina OttieniPagina(String titolo)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return null;

        if(!DeterminaAnomalie(new Object[]{titolo},14))
            return null;

        for (var pag : proposteInAttesa.keySet())
        {
            if(pag.titolo.contentEquals(titolo))
                return pag;
        }

        InviaErrore(24);
        return  null;
    }

    /** Visualizza i paragrafi, della pagina in esame, che sono indicati nelle notifiche. */
    public void MostraIndiciParagrafiSoggettiAProposte(Pagina paginaSelezionata)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return;

        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            InviaErrore(16);
            return;
        }

        System.out.println("> Indici paragrafi soggetti a proposte: ");

        for ( var key : proposteInAttesa.get(paginaSelezionata).keySet())
        {
            System.out.print("Indice [");
            System.out.print(key.intValue());
            System.out.println("]");

            for(int i = 0; i < proposteInAttesa.get(paginaSelezionata).get(key).size(); i++)
            {
                System.out.print("  ");
                System.out.print(i);
                System.out.print(") ");
                System.out.print(" [");
                System.out.print((proposteInAttesa.get(paginaSelezionata).get(key).get(i).operazioneDaEffettuare));
                System.out.print("]");
                System.out.println(proposteInAttesa.get(paginaSelezionata).get(key).get(i).contenuto);
            }
        }
    }

    public Paragrafo OttieniParagrafo(int indiceProposta, int indiceParagrafo, Pagina paginaSelezionata)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return null;
        
        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            InviaErrore(16);
            return null;
        }

        if(!proposteInAttesa.get(paginaSelezionata).containsKey(indiceParagrafo))
        {
            InviaErrore(17);
            return null;
        }

        if(!DeterminaAnomalie(new int[]{indiceProposta,0},22))
            return null;

        if(!DeterminaAnomalie(new int[]{indiceProposta, proposteInAttesa.get(paginaSelezionata).size()},17))
            return null;

        return  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo).get(indiceProposta);
    }

    public void ElaborazioneProposta(Paragrafo propostaSelezionata)
    {
        var listaProposte = proposteInAttesa.get(propostaSelezionata.paginaDiRiferimento).get(propostaSelezionata.posizione);
        var listaParagrafi = proposteInAttesa.get(propostaSelezionata.paginaDiRiferimento);
        int indiceProposta = listaProposte.indexOf(propostaSelezionata);

        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return;

        if(!listaParagrafi.get(propostaSelezionata.posizione).contains(propostaSelezionata))
        {
            InviaErrore(15);
            return;
        }

        listaProposte.get(indiceProposta).stato = Stato.Approvato;
        propostaSelezionata.proprietario.punteggio += 1;
        propostaSelezionata.paginaDiRiferimento.ApplicaParagrafo(propostaSelezionata);
        listaProposte.remove(indiceProposta);

        while (listaProposte.size() > 0)
        {
            listaProposte.getFirst().stato = Stato.Rifiutato;
            listaProposte.remove(listaProposte.getFirst());
        }

        listaParagrafi.remove(propostaSelezionata.posizione);
    }

    public void RifiutaTutteLeProposte(int indiceParagrafo, Pagina paginaSelezionata)
    {
        if(!DeterminaAnomalie(ConnessoComeAutore,true,18))
            return ;

        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            InviaErrore(26);
            return;
        }

        if(!proposteInAttesa.get(paginaSelezionata).containsKey(indiceParagrafo))
        {
            InviaErrore(15);
            return;
        }

        int dimensioneListaProposte  = proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo).size();
        var listaProposte =  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo);

        do
        {
            listaProposte.get(0).stato = Stato.Rifiutato;
            listaProposte.remove(0);
        }while (listaProposte.isEmpty());

        proposteInAttesa.remove(paginaSelezionata);
    }
}