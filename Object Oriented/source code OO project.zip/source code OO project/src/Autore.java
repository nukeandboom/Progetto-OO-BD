import java.util.*;

public class Autore  extends  Utente
{
    protected boolean ConnectedAsAuthor;
    public final String username;
    public final Date dataIscrizione;
    private final String password;
    public ArrayList<Pagina> pagScritte = new ArrayList<Pagina>();
    private Map<Pagina,ArrayList<Paragrafo>> proposteInAttesa = new HashMap<Pagina,ArrayList<Paragrafo>>();

    public Autore(String username, String password,int id)
    {
        super(id);
        this.username = username;
        this.password = password;
        dataIscrizione = new Date();
        ConnectedAsAuthor = false;
    }

    public  void Login(String username, String password)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,false,2))
            return;

        if(!DeterminaAnomalie(new String[]{this.password,password},3))
            return;

        if(!DeterminaAnomalie(new String[]{this.username,username},3))
            return;

        ConnectedAsAuthor = true;
        System.out.println("> Accesso effettuato : <Autore>");
    }

    public void LogOff()
    {
        ConnectedAsAuthor = false;
        System.out.println("> Autore disconnesso!");
    }

    public Pagina CreaPagina(String titolo)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return null;

        if(!DeterminaAnomalie(new String[]{titolo},4))
            return null;

        if(!DeterminaAnomalie(new Object[]{titolo},5))
            return null;

        Pagina temp = new Pagina(titolo,this);
        pagScritte.add(temp);

        return  temp;
    }

    public void RifiutaTutteLeProposte(Pagina pagina)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return ;

        proposteInAttesa.remove(pagina);
    }

    public void InviaProposta(Paragrafo daRevisionare, Autore destinatario)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return ;

        if(!DeterminaAnomalie(new Object[]{daRevisionare},6))
            return;

        if(!DeterminaAnomalie(new Object[]{destinatario},6))
            return;

        if(!DeterminaAnomalie(new int[]{daRevisionare.posizione,0}, 7))
            return;

        int[] temp = {daRevisionare.posizione, daRevisionare.paginaDiRiferimento.testo.size()};

        switch (daRevisionare.operazioneDaEffettuare) {
            case Add -> {
                if(!DeterminaAnomalie(temp,8))
                    return;
            }
            case Remove-> {
                if(!DeterminaAnomalie(temp,9))
                    return;

                if(!DeterminaAnomalie(temp,10))
                    return;
            }
            case Update -> {
                if(!DeterminaAnomalie(temp,11))
                    return;

                if(!DeterminaAnomalie(temp,12))
                    return;
            }
        }

        if(daRevisionare.operazioneDaEffettuare == Azione.Add)
        {
            InviaErrore(13);
            return;
        }

        // nel caso in cui il mittente fosse proprio il proprietario della pagina,
        // allora la modifica verrà apportata senza alcuna valutazione.
        if(destinatario != this)
            destinatario.RiceviNotifica(daRevisionare);
        else
            daRevisionare.paginaDiRiferimento.ApplicaParagrafo(daRevisionare);
    }

    public Pagina OttieniPagina(String titolo)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return null;

        if(!DeterminaAnomalie(new Object[]{titolo},14))
            return null;

        for (var pag : proposteInAttesa.entrySet())
        {
            if(pag.getKey().titolo.contentEquals(titolo))
                return pag.getKey();
        }

      //  System.out.println("> [ATTENZIONE]: raccolta info fallita -> il titolo inserito non risulta presente nelle notifiche!");
        return  null;
    }

    /** Questa funzione consente di visualizzare le pagine a cui sono riferite le proposte di modifica */
    public void MostraPagineSoggetteAProposta()
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return;

        System.out.println("> Sono disponibili modifiche alle seguenti pagine: ");

        for( var pag: proposteInAttesa.entrySet())
        {
            System.out.println(pag.getKey().titolo);
        }
    }

    /** A seguito della revisione delle pagine interessate dalle proposte di modifica,è possibile visualizzare tutte le notifiche della singola pagina di interesse.*/
    public void MostraProposteInerentiAdUnaPagina(Pagina selezionata)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return;

        if(!DeterminaAnomalie(new Object[]{selezionata},19))
            return;

        if(!proposteInAttesa.containsKey(selezionata))
        {
            InviaErrore(20);
            return;
        }

        System.out.print("> Proposte inerenti alla pagina ");
        System.out.print(selezionata.titolo);
        System.out.println(" : ");

        for(int i = 0; i < proposteInAttesa.get(selezionata).size(); i++)
        {
            System.out.print(i);
            System.out.print(") ");

            if(proposteInAttesa.get(selezionata).get(i).operazioneDaEffettuare == Azione.Update)
            {
                System.out.print("<");
                System.out.print(proposteInAttesa.get(selezionata).get(i).posizione);
                System.out.print("> ");
            }
            System.out.print(proposteInAttesa.get(selezionata).get(i).contenuto);
            System.out.print(" [");
            System.out.print((proposteInAttesa.get(selezionata).get(i).operazioneDaEffettuare));
            System.out.println("]");
        }
    }

    public void ElaborazioneProposta(Paragrafo selezionato, Pagina destinazione)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return ;

        if(!DeterminaAnomalie(new Object[]{destinazione},17))
            return;

        if(!DeterminaAnomalie(new Object[]{destinazione},15))
            return;

        if(!proposteInAttesa.containsKey(destinazione))
        {
            InviaErrore(16);
            return;
        }

        if(!proposteInAttesa.get(destinazione).contains(selezionato))
        {
            InviaErrore(18);
            return;
        }

        var listaParagrafi = proposteInAttesa.get(selezionato.paginaDiRiferimento);
        int index = listaParagrafi.indexOf(selezionato);

        listaParagrafi.get(index).stato= Stato.Approved;
        selezionato.paginaDiRiferimento.ApplicaParagrafo(selezionato);

        for (Paragrafo par : listaParagrafi)
        {
            par.stato = Stato.Refused;
        }

        proposteInAttesa.remove(selezionato.paginaDiRiferimento);
    }

    public  void RiceviNotifica(Paragrafo daNotificare)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return ;

        if(proposteInAttesa.containsKey(daNotificare.paginaDiRiferimento))
            proposteInAttesa.get(daNotificare.paginaDiRiferimento).add(daNotificare);
        else
        {
            ArrayList<Paragrafo> temp = new ArrayList<>();
            temp.add(daNotificare);
            proposteInAttesa. put(daNotificare.paginaDiRiferimento, temp);
        }
    }

    public Paragrafo OttieniParagrafo(int index, Pagina pagina)
    {
        if(!DeterminaAnomalie(ConnectedAsAuthor,true,22))
            return null;

        if(!DeterminaAnomalie(new Object[]{pagina},19))
            return null;

        if(!proposteInAttesa.containsKey(pagina))
        {
            InviaErrore(20);
            return null;
        }

        if(!DeterminaAnomalie(new int[]{index},26))
            return null;

        if(!DeterminaAnomalie(new int[]{index, proposteInAttesa.get(pagina).size()},21))
            return null;

        return  proposteInAttesa.get(pagina).get(index);
    }
}
