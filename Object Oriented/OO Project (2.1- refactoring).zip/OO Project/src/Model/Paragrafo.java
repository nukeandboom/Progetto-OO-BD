package Model;

import javax.swing.*;
import java.util.Date;

public class Paragrafo
{
    private String contenuto;
    private Stato stato = Stato.InAttesa;
    private Azione operazioneDaEffettuare;
    private Date data_creazione;
    private int posizione;
    private Autore proprietario;
    private Pagina paginaDiRiferimento;
    private Collegamento collegamento = null;


    public Paragrafo(String contenuto, int posizione, Azione azione, Pagina pagina, Autore proprietario)
    {
        if(azione == Azione.Svuotare)
            contenuto = "";

        this.contenuto = contenuto;
        this.proprietario = proprietario;
        this.posizione = posizione;

        paginaDiRiferimento = pagina;
        data_creazione = new Date();
        operazioneDaEffettuare  = azione;

        proprietario.paragrafiScritti.add(this);
    }

    public Stato ottieniStato(){
        return stato;
    }

    public void impostaStato(Stato stato){
        this.stato = stato;
    }

    public Collegamento ottienicollegamento(){
        return collegamento;
    }

    public  void impostaCollegamento(Collegamento collegamento){
        this.collegamento = collegamento;
    }

    public String ottieniContenuto(){
        return  contenuto;
    }

    public Pagina ottieniPaginaDiRiferimento(){
        return  paginaDiRiferimento;
    }

    public int ottieniPosizione(){
        return posizione;
    }

    public Azione ottieniAzione(){
        return this.operazioneDaEffettuare;
    }

    public Autore ottieniProprietario(){
        return proprietario;
    }
}
