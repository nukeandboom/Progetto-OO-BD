package DAO;


/// questa è l'interface per ogni metodo in ImplementazioneDAO poi la riempio
public class dao {
}
