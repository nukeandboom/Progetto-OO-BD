package GUI;

import Controller.Controller;
import Model.Azione;
import Model.Collegamento;
import Model.Pagina;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.ResourceBundle;

public class SchermataCreazioneProposta extends FunzioniDiSupportoGUI {
    private JTextArea propostaTxArea;
    private JButton invioPropostaBtn;
    private JButton indietroBtn;
    private JTextField titoloPaginaTxField;
    private JComboBox operazioneCbBox;
    private JPanel pannelloPrincipale;
    private JComboBox indiceParagrafoCbBox;
    private JTextArea mostraParagrafoTxArea;
    private JLabel mostraParagrafoLabel;
    private JLabel propostaLabel;
    private JButton impostaCollegamentoBtn;
    private static JFrame frameCorrente;
    private boolean statoCollegamentoButton = false;


    public SchermataCreazioneProposta(Controller controller, JFrame chiamante, Pagina paginaDiRiferimento) {

        frameCorrente = inizializzaNuovaFinestra("SchermataCreazioneProposta", pannelloPrincipale);

        titoloPaginaTxField.setText(titoloPaginaTxField.getText() + paginaDiRiferimento.titolo);

        // Gli elementi sottostanti sono tutte le opzioni applicabili su un paragrafo.
        // I trattini simboleggiano lo stato di default della comboBox, dove nessuna opzione è stata selezionata.
        operazioneCbBox.addItem("---");
        indiceParagrafoCbBox.addItem("---");
        operazioneCbBox.addItem("Aggiornare");
        operazioneCbBox.addItem("Aggiungere");
        operazioneCbBox.addItem("Eliminare");

        indietroBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!propostaTxArea.getText().isBlank()) {

                    int input = JOptionPane.showConfirmDialog(null, "Attenzione, se si esce dalla pagina il lavoro non salvato verrà eliminato!",
                            "Creazione proposta -> Uscita pagina", JOptionPane.YES_NO_OPTION);


                    if (input == JOptionPane.NO_OPTION)
                        return;
                }

                chiudiFinestra(chiamante, frameCorrente);
            }
        });

        invioPropostaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Collegamento collegamentoDaProporre = null;

                if (operazioneCbBox.getSelectedIndex() == 0) {

                    JOptionPane.showMessageDialog(null, "Nessuna operazione selezionata!",
                            "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                    return;
                }

                if (indiceParagrafoCbBox.getSelectedIndex() == 0 && operazioneCbBox.getSelectedIndex() != 2) {

                    JOptionPane.showMessageDialog(null, "E' necessario selezionare un paragrafo su cui applicare una modifica!",
                            "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                    return;
                }

                if (statoCollegamentoButton) {

                    if (propostaTxArea.getText().isBlank() && operazioneCbBox.getSelectedIndex() != 3) {

                        JOptionPane.showMessageDialog(null, "L'operazione di aggiornamento, o aggiunta,  di un collegamento richiede una proposta che non sia vuota!",
                                "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                        return;
                    }

                    if (!propostaTxArea.getText().isBlank() && operazioneCbBox.getSelectedIndex() == 3) {

                        JOptionPane.showMessageDialog(null, "L'operazione di svuotamento di un collegamento richiede una proposta che sia vuota!",
                                "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                        return;
                    }

                    if (!propostaTxArea.getText().isBlank() && operazioneCbBox.getSelectedIndex() == 1) {

                        Pagina paginaDiDestinazione = controller.controllaEsistenzaPagina(propostaTxArea.getText());

                        if (paginaDiDestinazione == null) {

                            JOptionPane.showMessageDialog(null, "Attenzione: la pagina selezionata nel collegamento è inesistente!",
                                    "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                            return;
                        }


                        //collegamentoDaProporre = new Collegamento(paginaDiRiferimento, paginaDiDestinazione);
                    }

                } else {

                    if (propostaTxArea.getText().isBlank() && operazioneCbBox.getSelectedIndex() != 3) {

                        JOptionPane.showMessageDialog(null, "L' operazione di aggiunta, o modifica, di un paragrafo richiede una proposta che non sia vuota!",
                                "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                        return;
                    }

                    if (!propostaTxArea.getText().isBlank() && operazioneCbBox.getSelectedIndex() == 3) {

                        JOptionPane.showMessageDialog(null, "L'operazione di svuotamento di un paragrafo richiede una proposta che sia vuota!",
                                "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                        return;
                    }

                    if (operazioneCbBox.getSelectedIndex() == 2 && controller.ottieniAutore() != paginaDiRiferimento.proprietario) {

                        JOptionPane.showMessageDialog(null, "L' operazione di aggiunta di un paragrafo può essere effettuata solo dal proprietario della pagina!",
                                "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                        return;
                    }
                }

                int input = JOptionPane.showConfirmDialog(null, "Si desidera inviare la proposta?",
                        "Creazione proposta -> Invia proposta", JOptionPane.YES_NO_OPTION);

                if (input == JOptionPane.YES_OPTION) {

                    Azione azione = null;

                    switch (operazioneCbBox.getSelectedIndex() - 1) {
                        case 0:
                            azione = Azione.Aggiornare;
                            break;
                        case 1:
                            azione = Azione.Aggiungere;
                            break;
                        case 2:
                            azione = Azione.Svuotare;
                            break;
                    }

                    controller.inviaProposta(propostaTxArea.getText(),
                            indiceParagrafoCbBox.getSelectedIndex() - 1,
                            paginaDiRiferimento,
                            azione,
                            collegamentoDaProporre);

                    chiudiFinestra(chiamante, frameCorrente);
                }
            }
        });

        operazioneCbBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {

                // per prevenire un selezinamento non previsto alla chiusura della ComboBox, si eliminano tutte le operazioni
                if (evento.getStateChange() == ItemEvent.DESELECTED) {

                    indiceParagrafoCbBox.removeAllItems();
                    indiceParagrafoCbBox.addItem("---");

                    return;
                }

                if (evento.getStateChange() == ItemEvent.SELECTED) {

                    // Quando una operazione viene selezionata, in indiceParagrafoCbBox vengono
                    // caricati preventivamente tutti i paragrafi del testo.
                    // Ciò non accade per l'operazione di aggiunta, in quanto questa operazione non influenza
                    // i paragrafi esistenti

                    if (operazioneCbBox.getSelectedIndex() != 0 && operazioneCbBox.getSelectedIndex() != 2) {

                        for (int indice = 0; indice < paginaDiRiferimento.testo.size(); indice++) {
                            indiceParagrafoCbBox.addItem(String.valueOf(indice));
                        }
                    }
                }
            }
        });

        indiceParagrafoCbBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {

                if (evento.getStateChange() == ItemEvent.SELECTED) {

                    int indiceParagrafo = indiceParagrafoCbBox.getSelectedIndex();
                    int operazione = operazioneCbBox.getSelectedIndex();

                    if (indiceParagrafo != 0 && operazione != 0 && operazione != 2)
                        mostraParagrafoTxArea.setText(paginaDiRiferimento.testo.get(indiceParagrafo - 1).ottieniContenuto());
                }
            }
        });

        impostaCollegamentoBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (operazioneCbBox.getSelectedIndex() == 0)
                    return;

                if (indiceParagrafoCbBox.getSelectedIndex() == 0)
                    return;

                if (controller.ottieniAutore() != paginaDiRiferimento.proprietario) {

                    JOptionPane.showMessageDialog(null, "L' operazione inerenti ai collegamneti possono essere effettuate solo dal proprietario della pagina!",
                            "Creazione proposta -> Attenzione", JOptionPane.WARNING_MESSAGE);

                    return;
                }

                // Quando impostaCollegamentoBtn viene selezionato, la textArea dedicata alla scrittura
                // della proposta viene temporaneamente utilizzata per scrivere la pagina
                // a cui il collegamento si riferisce.

                if (statoCollegamentoButton) {

                    propostaTxArea.setText(controller.messaggioDaProporre);
                    propostaTxArea.setForeground(Color.white);

                    return;
                }

                int indiceParagrafo = indiceParagrafoCbBox.getSelectedIndex() - 1;
                Collegamento collegamentoParagrafo = paginaDiRiferimento.testo.get(indiceParagrafo).ottienicollegamento();

                controller.messaggioDaProporre = propostaTxArea.getText();
                propostaTxArea.setText(collegamentoParagrafo.toString());
                propostaTxArea.setForeground(Color.blue);
            }
        });
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        pannelloPrincipale = new JPanel();
        pannelloPrincipale.setLayout(new GridBagLayout());
        pannelloPrincipale.setBackground(new Color(-14342875));
        pannelloPrincipale.setPreferredSize(new Dimension(1200, 720));
        invioPropostaBtn = new JButton();
        invioPropostaBtn.setBorderPainted(true);
        invioPropostaBtn.setContentAreaFilled(false);
        invioPropostaBtn.setFocusPainted(false);
        Font invioPropostaBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, invioPropostaBtn.getFont());
        if (invioPropostaBtnFont != null) invioPropostaBtn.setFont(invioPropostaBtnFont);
        invioPropostaBtn.setForeground(new Color(-331531));
        invioPropostaBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(invioPropostaBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "invia.proposta"));
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 30, 0, 0);
        pannelloPrincipale.add(invioPropostaBtn, gbc);
        indietroBtn = new JButton();
        indietroBtn.setAlignmentX(0.5f);
        indietroBtn.setAutoscrolls(false);
        indietroBtn.setBorderPainted(true);
        indietroBtn.setContentAreaFilled(false);
        indietroBtn.setFocusPainted(false);
        Font indietroBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietroBtn.getFont());
        if (indietroBtnFont != null) indietroBtn.setFont(indietroBtnFont);
        indietroBtn.setForeground(new Color(-331531));
        indietroBtn.setMaximumSize(new Dimension(250, 50));
        indietroBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(indietroBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "indietro"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 50);
        pannelloPrincipale.add(indietroBtn, gbc);
        titoloPaginaTxField = new JTextField();
        titoloPaginaTxField.setBackground(new Color(-14342875));
        titoloPaginaTxField.setEditable(false);
        Font titoloPaginaTxFieldFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, titoloPaginaTxField.getFont());
        if (titoloPaginaTxFieldFont != null) titoloPaginaTxField.setFont(titoloPaginaTxFieldFont);
        titoloPaginaTxField.setForeground(new Color(-331531));
        titoloPaginaTxField.setHorizontalAlignment(0);
        titoloPaginaTxField.setOpaque(false);
        titoloPaginaTxField.setPreferredSize(new Dimension(250, 50));
        titoloPaginaTxField.setText("pagina : ");
        titoloPaginaTxField.setVerifyInputWhenFocusTarget(false);
        titoloPaginaTxField.setVisible(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(100, 0, 50, 70);
        pannelloPrincipale.add(titoloPaginaTxField, gbc);
        operazioneCbBox = new JComboBox();
        operazioneCbBox.setBackground(new Color(-14342875));
        Font operazioneCbBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, operazioneCbBox.getFont());
        if (operazioneCbBoxFont != null) operazioneCbBox.setFont(operazioneCbBoxFont);
        operazioneCbBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        operazioneCbBox.setModel(defaultComboBoxModel1);
        operazioneCbBox.setOpaque(true);
        operazioneCbBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridheight = 2;
        gbc.insets = new Insets(50, 0, 0, 50);
        pannelloPrincipale.add(operazioneCbBox, gbc);
        indiceParagrafoCbBox = new JComboBox();
        indiceParagrafoCbBox.setBackground(new Color(-14342875));
        Font indiceParagrafoCbBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceParagrafoCbBox.getFont());
        if (indiceParagrafoCbBoxFont != null) indiceParagrafoCbBox.setFont(indiceParagrafoCbBoxFont);
        indiceParagrafoCbBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel2 = new DefaultComboBoxModel();
        indiceParagrafoCbBox.setModel(defaultComboBoxModel2);
        indiceParagrafoCbBox.setOpaque(true);
        indiceParagrafoCbBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.insets = new Insets(25, 0, 0, 0);
        pannelloPrincipale.add(indiceParagrafoCbBox, gbc);
        mostraParagrafoTxArea = new JTextArea();
        mostraParagrafoTxArea.setBackground(new Color(-13158601));
        Font mostraParagrafoTxAreaFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, mostraParagrafoTxArea.getFont());
        if (mostraParagrafoTxAreaFont != null) mostraParagrafoTxArea.setFont(mostraParagrafoTxAreaFont);
        mostraParagrafoTxArea.setForeground(new Color(-331531));
        mostraParagrafoTxArea.setLineWrap(true);
        mostraParagrafoTxArea.setOpaque(true);
        mostraParagrafoTxArea.setPreferredSize(new Dimension(100, 300));
        mostraParagrafoTxArea.setText("");
        mostraParagrafoTxArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 0, 0, 0);
        pannelloPrincipale.add(mostraParagrafoTxArea, gbc);
        propostaTxArea = new JTextArea();
        propostaTxArea.setBackground(new Color(-13158601));
        Font propostaTxAreaFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, propostaTxArea.getFont());
        if (propostaTxAreaFont != null) propostaTxArea.setFont(propostaTxAreaFont);
        propostaTxArea.setForeground(new Color(-331531));
        propostaTxArea.setLineWrap(true);
        propostaTxArea.setName("");
        propostaTxArea.setOpaque(true);
        propostaTxArea.setPreferredSize(new Dimension(150, 300));
        propostaTxArea.setToolTipText("");
        propostaTxArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 50, 0, 0);
        pannelloPrincipale.add(propostaTxArea, gbc);
        mostraParagrafoLabel = new JLabel();
        Font mostraParagrafoLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, mostraParagrafoLabel.getFont());
        if (mostraParagrafoLabelFont != null) mostraParagrafoLabel.setFont(mostraParagrafoLabelFont);
        mostraParagrafoLabel.setForeground(new Color(-331531));
        mostraParagrafoLabel.setPreferredSize(new Dimension(250, 27));
        this.$$$loadLabelText$$$(mostraParagrafoLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "paragrafo.attuale"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.WEST;
        pannelloPrincipale.add(mostraParagrafoLabel, gbc);
        propostaLabel = new JLabel();
        Font propostaLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, propostaLabel.getFont());
        if (propostaLabelFont != null) propostaLabel.setFont(propostaLabelFont);
        propostaLabel.setForeground(new Color(-331531));
        propostaLabel.setHorizontalAlignment(0);
        propostaLabel.setHorizontalTextPosition(11);
        propostaLabel.setPreferredSize(new Dimension(300, 27));
        this.$$$loadLabelText$$$(propostaLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "proposta.elaborata"));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 2;
        pannelloPrincipale.add(propostaLabel, gbc);
        impostaCollegamentoBtn = new JButton();
        impostaCollegamentoBtn.setBorderPainted(true);
        impostaCollegamentoBtn.setContentAreaFilled(false);
        impostaCollegamentoBtn.setFocusPainted(false);
        Font impostaCollegamentoBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, impostaCollegamentoBtn.getFont());
        if (impostaCollegamentoBtnFont != null) impostaCollegamentoBtn.setFont(impostaCollegamentoBtnFont);
        impostaCollegamentoBtn.setForeground(new Color(-14342875));
        impostaCollegamentoBtn.setHorizontalTextPosition(0);
        impostaCollegamentoBtn.setIcon(new ImageIcon(getClass().getResource("/GUI/img/link icon.png")));
        impostaCollegamentoBtn.setPreferredSize(new Dimension(50, 50));
        this.$$$loadButtonText$$$(impostaCollegamentoBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "accedi"));
        impostaCollegamentoBtn.setVerifyInputWhenFocusTarget(false);
        gbc = new GridBagConstraints();
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.insets = new Insets(60, 30, 0, 0);
        pannelloPrincipale.add(impostaCollegamentoBtn, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    private static Method $$$cachedGetBundleMethod$$$ = null;

    private String $$$getMessageFromBundle$$$(String path, String key) {
        ResourceBundle bundle;
        try {
            Class<?> thisClass = this.getClass();
            if ($$$cachedGetBundleMethod$$$ == null) {
                Class<?> dynamicBundleClass = thisClass.getClassLoader().loadClass("com.intellij.DynamicBundle");
                $$$cachedGetBundleMethod$$$ = dynamicBundleClass.getMethod("getBundle", String.class, Class.class);
            }
            bundle = (ResourceBundle) $$$cachedGetBundleMethod$$$.invoke(null, path, thisClass);
        } catch (Exception e) {
            bundle = ResourceBundle.getBundle(path);
        }
        return bundle.getString(key);
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadLabelText$$$(JLabel component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setDisplayedMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadButtonText$$$(AbstractButton component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return pannelloPrincipale;
    }

}
