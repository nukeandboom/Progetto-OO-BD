package Model;

public class Collegamento extends GestioneAnomalia
{
    public String titolo_diArrivo;
    public String titolo_diDestinazione;

    public Collegamento( String titolo_diPartenza,String titolo_diDestinazione)
    {
        this.titolo_diArrivo = titolo_diPartenza;
        this.titolo_diDestinazione = titolo_diDestinazione;
    }
}
