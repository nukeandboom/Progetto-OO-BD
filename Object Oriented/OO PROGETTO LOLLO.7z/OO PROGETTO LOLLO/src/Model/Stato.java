package Model;

public enum Stato
{
    Approvato,
    Rifiutato,
    InAttesa,
    Expired
}
