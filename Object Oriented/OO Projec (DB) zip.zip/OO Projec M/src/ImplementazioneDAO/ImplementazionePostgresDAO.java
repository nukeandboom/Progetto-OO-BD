package ImplementazioneDAO;

import Controller.Controller;
import Database.ConnessioneDatabase;
import Model.Autore;
import Model.Collegamento;
import Model.Pagina;
import Model.Paragrafo;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class ImplementazionePostgresDAO {

    private static Connection connection;

    private static final String INSERT_USERS_SQL = "INSERT INTO utente" + "(idutente) VALUES " + " (?);";

    private static final String GET_PAGINA_SQL = "SELECT * FROM pagina  WHERE titolo = ? ";

    private static final String POPULATE_TEXT_PAGINA_VISITATA = "SELECT * FROM paragrafo WHERE titolopag = ? AND stato = 'accettato' ";

    private static final String INSERT_NEW_AUTHOR_SQL = "INSERT INTO autore " + "(username,password,data_iscrizione,punteggio) VALUES" + "(?,?,?,?)";

    private static final String INSERT_NEW_VISITandVALUTATION_SQL = "INSERT INTO visita " + "(idutente_in_visita,data_visita,valutazione,titolo_pagina_visitata) VALUES" + "(?,?,?,?)";


    //private static final String GET_AUTORE_PROPRIETARIO = "SELECT username, password, data_iscrizione, punteggio FROM pagina JOIN paragrafo WHERE titolo = ? ORDER BY posizione ASC ";

    //private static final String GET_PAGINE_FROMDB = "SELECT * FROM \"pagina\"";

    //private static final String LOAD_AUTORI_FROM_DB = "SELECT * FROM \"autore\"";

    public static void connectDAO() {
        try {
            connection = ConnessioneDatabase.getInstance().connection;
            System.out.println("Istanza avviata");
        } catch (SQLException e) {
            System.out.println("Errore connessione al database " + e.getMessage());
        }

    }

    public static int nuovoutentedaDB() {

        int last_user_value = 0;

        try {

            Statement leggiutentiPS = connection.createStatement
                    (ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);


            ResultSet rs = leggiutentiPS.executeQuery("SELECT * FROM \"utente\"");


            while (rs.next()) {

                last_user_value = rs.getInt("idutente");

            }

            System.out.println("ultimo utente = " + (last_user_value + 1));

            rs.close();
            leggiutentiPS.close();
            connection.close();
        } catch (Exception e) {
            System.out.println("Errore lettura utenti " + e.getMessage());
        }

        return last_user_value + 1;
    }

    public static void confirmednuovoutenteDB(int id){

        try (

             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setInt(1,id);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            e.getMessage();
        }

    }



    public static boolean confermacredenzialiDB(String username_to_search,String password_to_search){

        boolean check = false;

        try {PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM autore WHERE username =?  AND password = ?");

                preparedStatement.setString(1,username_to_search);

                preparedStatement.setString(2, password_to_search);

                ResultSet resultSet = preparedStatement.executeQuery();

                if(resultSet.next()){
                    System.out.println("Trovata corrispondenza nel database");
                    check = true;
                }else{
                    System.out.println("Nessun account corrispondente");

                }


                resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            e.getMessage();
        }



        return check;
    }


    public static void LogAsSignedAuthor(String username, String password){



        try {PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM autore WHERE username = ? AND password = ?");

            String username_to_load;
            String password_to_load;
            Date date_to_load;
            java.util.Date utilDate;
            int punteggio_to_load;


            preparedStatement.setString(1,username);

            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

                username_to_load = resultSet.getString("username");
                password_to_load = resultSet.getString("password");
                date_to_load = resultSet.getDate("data_iscrizione");
                // conversione sql.data   ---- >>  lang.data

                utilDate = new java.util.Date(date_to_load.getTime());
                punteggio_to_load = resultSet.getInt("punteggio");
                Controller.creaAutore(username_to_load,password_to_load,utilDate,punteggio_to_load,false);

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            e.getMessage();
        }


    }


    public static Pagina ottieniPagina(String titoloPagina) {

        Pagina pagina_to_return = null;
        String titolo_to_load;
        java.util.Date data_to_load;

        // X FEDE da implementare in GUI un modo per mostrare il nome del proprietario agli utenti , sempre se lo vogliamo fare. Per ora metto un messaggio in console. Se non va bene levalo pure.
        ///  -->
        String Username_proprietario_to_load= " NESSUN PROPRIETARIO "; //caso base

       try {
           PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINA_SQL);

           preparedStatement.setString(1, titoloPagina);

           ResultSet resultSet = preparedStatement.executeQuery();

           resultSet.next();
           titolo_to_load = resultSet.getString(1);

           java.sql.Date data_di_appoggio = resultSet.getDate(2);
           data_to_load = new java.util.Date(data_di_appoggio.getTime());

           Username_proprietario_to_load = resultSet.getString(3);

           pagina_to_return = new Pagina(titolo_to_load,data_to_load);

           resultSet.close();
           preparedStatement.close();
           connection.close();
       }catch (SQLException e){

          e.getMessage();
       }

        System.out.println(Username_proprietario_to_load);
        return pagina_to_return;
    }


    public static ArrayList<Paragrafo> raccogliTesto(String titolo,Pagina pagina_x_costruttoreDiParagrafo) {

        ArrayList<Paragrafo> testo_to_return = new ArrayList<>();
        String contenuto_to_load;
        java.util.Date data_to_load;
        Time orario_to_load;
        int posizione_to_load;

        //Collegamento Collegamento_to_load;  // se non ho completato , qui voglio mettere il collegamento ottenuto tramite tabella COLLEGAMENTO

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(POPULATE_TEXT_PAGINA_VISITATA);

            preparedStatement.setString(1, titolo);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                contenuto_to_load = resultSet.getString("contenuto");
                posizione_to_load = resultSet.getInt("posizione");
                Date data_to_convert = resultSet.getDate("data");
                orario_to_load = resultSet.getTime("orario");
                data_to_load = new java.util.Date(data_to_convert.getTime());

                System.out.println(contenuto_to_load);
                System.out.println(posizione_to_load);
                System.out.println(orario_to_load);
                System.out.println(data_to_convert);

                Paragrafo p = new Paragrafo(contenuto_to_load,posizione_to_load,pagina_x_costruttoreDiParagrafo,data_to_convert,orario_to_load);

                testo_to_return.add(p);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch(SQLException e){

                System.out.println("Errore nella raccolta del testo" + e.getMessage());
        }

         return testo_to_return;
    }


    public static void AggiunginuovoAutore(Autore autoreLoggato) {

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_AUTHOR_SQL)) {
            preparedStatement.setString(1, autoreLoggato.username);
            preparedStatement.setString(2, Controller.getPassword(autoreLoggato));
            // preparedStatement.setDate(3,Controller.autore_loggato.dataIscrizione);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            e.getMessage();
        }



    }



     public static void MandaValutazioneAndVisita(int valutazione,String TitolopaginaVisitata, int idutente){


      try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_VISITandVALUTATION_SQL)){

          preparedStatement.setInt(1, idutente);

          LocalDate currentDate = LocalDate.now();
          Date sqlDate = Date.valueOf(currentDate);
          preparedStatement.setDate(2, sqlDate);

          preparedStatement.setInt(3, valutazione);

          preparedStatement.setString(4,TitolopaginaVisitata);


          preparedStatement.executeUpdate();

          preparedStatement.close();
          connection.close();
      }catch (SQLException e){

          e.getMessage();
      }



    }














    /*public static void getpaginedaDB(){

        try (

                PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINE_FROMDB)) {
           // preparedStatement.setInt(1,test);

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            e.getMessage();
        }

    }*/

   /* public static void loadAutorifromDB(){

        String username_to_load;
        String password_to_load;
        Date date_to_load;
        int punteggio_to_load;

        try (

                PreparedStatement preparedStatement = connection.prepareStatement(LOAD_AUTORI_FROM_DB)) {

                ResultSet rs = preparedStatement.executeQuery();


                while(rs.next()){

                    username_to_load = rs.getString("username");
                    password_to_load = rs.getString("password");
                    date_to_load = rs.getDate("data_iscrizione");
                    // conversione sql.data   ---- >>  lang.data
                    java.util.Date utilDate = new java.util.Date(date_to_load.getTime());
                }


               preparedStatement.close();
               connection.close();

        } catch (SQLException e) {

            e.getMessage();
        }




    }*/


}
