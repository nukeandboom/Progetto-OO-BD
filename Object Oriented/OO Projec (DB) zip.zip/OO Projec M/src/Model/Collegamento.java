package Model;

public class Collegamento extends GestioneAnomalia
{
    public boolean is_collegamento;
    public String titolo_diArrivo;
    public String titolo_diDestinazione;

    public Collegamento(boolean is_collegamento, String titolo_diArrivo,String titolo_diDestinazione)
    {
        this.is_collegamento = is_collegamento;
        this.titolo_diArrivo = titolo_diArrivo;
        this.titolo_diDestinazione = titolo_diDestinazione;
    }
}
