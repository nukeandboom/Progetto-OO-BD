package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

    public class ConnessioneDatabase {
        private static ConnessioneDatabase instance;
        public Connection connection = null;
        private String nome = "postgres";
        private String password = "1234";
        private String url = "jdbc:postgresql://localhost:5432/DATABASE_WIKI";
        private String driver = "org.postgresql.Driver";

        private ConnessioneDatabase() throws SQLException {
            try {
                Class.forName(this.driver);
                this.connection = DriverManager.getConnection(this.url, this.nome, this.password);
            } catch (ClassNotFoundException e) {
                System.out.println("Connessione al Database Fallita. " + e.getMessage());
            }

        }

        public static ConnessioneDatabase getInstance() throws SQLException {
            if (instance == null) {
                instance = new ConnessioneDatabase();
            } else if (instance.connection.isClosed()) {
                instance = new ConnessioneDatabase();
            }

            return instance;
        }
    }





