package GUI;

import Controller.Controller;
import Model.Pagina;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.ResourceBundle;

public class SchermataCreazionePagina extends FunzioniDiSupportoGUI {
    private JPanel pannelloPrincipale;
    private JButton aggiungiParagrafoBtn;
    private JButton creaPaginaBtn;
    private JButton indietroBtn;
    private JTextField titoloPaginaTxField;
    private JTextArea paragrafoTxArea;
    private JButton impostaCollegamentoBtn;
    private JFrame frameCorrente;

    public SchermataCreazionePagina(JFrame chiamante, Controller controller) {

        frameCorrente = inizializzaNuovaFinestra("SchermataCreazionePagina", pannelloPrincipale);

        titoloPaginaTxField.setText(titoloPaginaTxField.getText() + controller.ottieniPaginaTemporanea().titolo);

        JTextField testoCollegamentoTxField = new JTextField();

        indietroBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int input = JOptionPane.showConfirmDialog(null, "Vuoi eliminare la pagina?",
                        "Creazione pagina -> cancellazione", JOptionPane.YES_NO_OPTION);

                if (input == JOptionPane.YES_OPTION) {
                    chiudiFinestra(chiamante, frameCorrente);
                }
            }
        });

        aggiungiParagrafoBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!paragrafoTxArea.getText().isBlank()) {

                    if (paragrafoTxArea.getText().length() >= 255) {
                        JOptionPane.showMessageDialog(null, "Attenzione, una paragrafo non può eguagliare o superare i 255 caratteri! ");
                        return;
                    }

                    controller.implementaParagrafoInUnaNuovaPagina(paragrafoTxArea.getText());
                    paragrafoTxArea.setForeground(Color.white);
                    paragrafoTxArea.setText(null);
                }
            }
        });

        creaPaginaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (controller.ottieniNumeroParagrafiScritti() == 0) {
                    JOptionPane.showMessageDialog(null, " Attenzione, una pagina non può essere vuota! ");
                    return;
                }

                String messaggioPopUp;

                if (!paragrafoTxArea.getText().isBlank())
                    messaggioPopUp = "Attenzione, la stesura del paragrafo non è stata ultimata! " +
                            "Se si conferma la creazione del documento, il paragrafo verrà scartato.";
                else
                    messaggioPopUp = "Salvare la pagina?";


                int input = JOptionPane.showConfirmDialog(null, messaggioPopUp,
                        "Creazione pagina -> Salvataggio pagina", JOptionPane.OK_CANCEL_OPTION);


                if (input == JOptionPane.OK_OPTION) {

                    controller.memorizzaPagina();
                    controller.svuotaDatiPaginaTemporanea();

                    chiudiFinestra(chiamante, frameCorrente);
                }
            }
        });

        impostaCollegamentoBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // Per eliminare il collegamento associato al paragrafo in scrittura,
                // è sufficiente cliccare su impostaCollegamentoBtn.
                if (controller.ottieniCollegamentoTemporaneo() != null) {

                    controller.svuotaCollegamentoTemporaneo();
                    paragrafoTxArea.setForeground(Color.white);
                    return;

                }

                String input = JOptionPane.showInputDialog(null, "Specifica la pagina di destinazione",
                        "Creazione pagina -> Creazione collegamento", JOptionPane.QUESTION_MESSAGE);


                if (input != null) {

                    Pagina paginaDaTrovare = controller.controllaEsistenzaPagina(testoCollegamentoTxField.getText());


                    if (paginaDaTrovare == null) {

                        JOptionPane.showMessageDialog(null, "Attenzione: la pagina selezionata non esiste!",
                                "Creazione pagina -> Errore", JOptionPane.ERROR_MESSAGE);

                    } else
                    {
                        controller.impostaCollegamentoTemporaneo(testoCollegamentoTxField.getText());
                        paragrafoTxArea.setForeground(Color.blue);
                    }
                }
            }
        });
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        pannelloPrincipale = new JPanel();
        pannelloPrincipale.setLayout(new GridBagLayout());
        pannelloPrincipale.setBackground(new Color(-14342875));
        pannelloPrincipale.setPreferredSize(new Dimension(1200, 720));
        creaPaginaBtn = new JButton();
        creaPaginaBtn.setBorderPainted(true);
        creaPaginaBtn.setContentAreaFilled(false);
        creaPaginaBtn.setFocusPainted(false);
        Font creaPaginaBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, creaPaginaBtn.getFont());
        if (creaPaginaBtnFont != null) creaPaginaBtn.setFont(creaPaginaBtnFont);
        creaPaginaBtn.setForeground(new Color(-331531));
        creaPaginaBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(creaPaginaBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "crea.pagina"));
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(20, 0, 30, 50);
        pannelloPrincipale.add(creaPaginaBtn, gbc);
        indietroBtn = new JButton();
        indietroBtn.setAlignmentX(0.5f);
        indietroBtn.setAutoscrolls(false);
        indietroBtn.setBorderPainted(true);
        indietroBtn.setContentAreaFilled(false);
        indietroBtn.setFocusPainted(false);
        Font indietroBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietroBtn.getFont());
        if (indietroBtnFont != null) indietroBtn.setFont(indietroBtnFont);
        indietroBtn.setForeground(new Color(-331531));
        indietroBtn.setMaximumSize(new Dimension(250, 50));
        indietroBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(indietroBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "indietro"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(20, 0, 30, 50);
        pannelloPrincipale.add(indietroBtn, gbc);
        paragrafoTxArea = new JTextArea();
        paragrafoTxArea.setBackground(new Color(-13158601));
        Font paragrafoTxAreaFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, paragrafoTxArea.getFont());
        if (paragrafoTxAreaFont != null) paragrafoTxArea.setFont(paragrafoTxAreaFont);
        paragrafoTxArea.setForeground(new Color(-331531));
        paragrafoTxArea.setLineWrap(true);
        paragrafoTxArea.setOpaque(true);
        paragrafoTxArea.setPreferredSize(new Dimension(200, 300));
        paragrafoTxArea.setWrapStyleWord(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.gridheight = 3;
        gbc.ipadx = 450;
        gbc.insets = new Insets(0, 0, 50, 50);
        pannelloPrincipale.add(paragrafoTxArea, gbc);
        titoloPaginaTxField = new JTextField();
        titoloPaginaTxField.setBackground(new Color(-14342875));
        titoloPaginaTxField.setEditable(false);
        Font titoloPaginaTxFieldFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, titoloPaginaTxField.getFont());
        if (titoloPaginaTxFieldFont != null) titoloPaginaTxField.setFont(titoloPaginaTxFieldFont);
        titoloPaginaTxField.setForeground(new Color(-331531));
        titoloPaginaTxField.setHorizontalAlignment(0);
        titoloPaginaTxField.setOpaque(false);
        titoloPaginaTxField.setPreferredSize(new Dimension(250, 50));
        titoloPaginaTxField.setText("Titolo:");
        titoloPaginaTxField.setVerifyInputWhenFocusTarget(false);
        titoloPaginaTxField.setVisible(true);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(70, 0, 30, 100);
        pannelloPrincipale.add(titoloPaginaTxField, gbc);
        impostaCollegamentoBtn = new JButton();
        impostaCollegamentoBtn.setBorderPainted(true);
        impostaCollegamentoBtn.setContentAreaFilled(false);
        impostaCollegamentoBtn.setFocusPainted(false);
        Font impostaCollegamentoBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, impostaCollegamentoBtn.getFont());
        if (impostaCollegamentoBtnFont != null) impostaCollegamentoBtn.setFont(impostaCollegamentoBtnFont);
        impostaCollegamentoBtn.setForeground(new Color(-331531));
        impostaCollegamentoBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(impostaCollegamentoBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "imposta.collegamento"));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 5;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(50, 50, 0, 50);
        pannelloPrincipale.add(impostaCollegamentoBtn, gbc);
        aggiungiParagrafoBtn = new JButton();
        aggiungiParagrafoBtn.setBorderPainted(true);
        aggiungiParagrafoBtn.setContentAreaFilled(false);
        aggiungiParagrafoBtn.setFocusPainted(false);
        Font aggiungiParagrafoBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, aggiungiParagrafoBtn.getFont());
        if (aggiungiParagrafoBtnFont != null) aggiungiParagrafoBtn.setFont(aggiungiParagrafoBtnFont);
        aggiungiParagrafoBtn.setForeground(new Color(-331531));
        aggiungiParagrafoBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(aggiungiParagrafoBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "aggiungi.paragrafo"));
        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 50, 0, 50);
        pannelloPrincipale.add(aggiungiParagrafoBtn, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    private static Method $$$cachedGetBundleMethod$$$ = null;

    private String $$$getMessageFromBundle$$$(String path, String key) {
        ResourceBundle bundle;
        try {
            Class<?> thisClass = this.getClass();
            if ($$$cachedGetBundleMethod$$$ == null) {
                Class<?> dynamicBundleClass = thisClass.getClassLoader().loadClass("com.intellij.DynamicBundle");
                $$$cachedGetBundleMethod$$$ = dynamicBundleClass.getMethod("getBundle", String.class, Class.class);
            }
            bundle = (ResourceBundle) $$$cachedGetBundleMethod$$$.invoke(null, path, thisClass);
        } catch (Exception e) {
            bundle = ResourceBundle.getBundle(path);
        }
        return bundle.getString(key);
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadButtonText$$$(AbstractButton component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return pannelloPrincipale;
    }

}
