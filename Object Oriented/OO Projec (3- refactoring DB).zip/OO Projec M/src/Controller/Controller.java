package Controller;

import Model.*;
import ImplementazioneDAO.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Controller extends GestioneAnomalia
{
        private static Utente utente;
        private Autore autoreLoggato;
        private Autore destinatarioTemporaneo;
        private Pagina paginaTemporanea;
        private Pagina paginaDaVisitare;
        private Collegamento collegamentoDaImplementare;
        public String messaggioDaProporre;
        public Visita visitaPaginaInCorso;
        private ImplementazionePostgresDAO impPostegresDAO ;
        
        public void creaUtente() {

                ImplementazionePostgresDAO.connectDAO();
               
               int id = impPostegresDAO.nuovoutentedaDB();
               
               ImplementazionePostgresDAO.connectDAO();

               impPostegresDAO.confermaNuovoIdUtenteDB(id);

               utente = new Utente(id);

        }

       /* public void caricaPagine()
        {
                impPostegresDAO.connectDAO();
                impPostegresDAO.getpaginedaDB();

        }*/

       /* public void caricaAutori()
        {
                impPostegresDAO.connectDAO();
                impPostegresDAO.loadAutorifromDB();

        }*/

        public  void scartaUtenteInUso()
        {
                utente = null;
        }

        public  boolean accessoAutore(String username, String password)
        {
                if(!Autore.controllaCredenzialiAccesso(username, password))
                        return false;

                ImplementazionePostgresDAO.connectDAO();
                autoreLoggato = impPostegresDAO.LogAsSignedAuthor(username,password);
                
                return true;
        }
        

        public  boolean creaAutore(String username, String password, Date dataIscrizione)
        {
                if(Autore.controllaCredenzialiAccesso(username, password))
                        return false;

                
                // 1. si deve aggiustare la funzione che inserisce l'utente al database
                
                //autoreLoggato = impPostegresDAO.AggiunginuovoAutore(autoreLoggato);
                
                return true;
        }
        
        public Autore ottieniAutore()
        {
                return  autoreLoggato;
        }
        public boolean creaPagina(String titolo)
        {
               if(controllaEsistenzaPagina(titolo) == null)
                       paginaTemporanea = new Pagina(titolo, autoreLoggato);

               return true; // da modificare
        }

        public Pagina controllaEsistenzaPagina(String titolo)
        {
                if(titolo.isBlank())
                        return null;

                return impPostegresDAO.ottieniPagina(titolo);
        }

        public void memorizzaPaginaTemporanea(Pagina paginaDiRiferimento)
        {
                paginaTemporanea = paginaDiRiferimento;
                destinatarioTemporaneo= paginaTemporanea.ottieniAutore();
        }

        public Pagina ottieniPaginaTemporanea(){
                return paginaTemporanea;
        }

        public void svuotaDatiPaginaTemporanea(){

                paginaTemporanea = null;
                destinatarioTemporaneo = null;
        }

        public int ottieniNumeroParagrafiScritti()
        {
                return paginaTemporanea.testo.size();
        }

        public void memorizzaPagina()
        {
                impPostegresDAO.memorizzaPaginaSulDB(paginaTemporanea);
                autoreLoggato.creaPagina(paginaTemporanea);
        }

        public  HashMap<Pagina, HashMap<Integer, ArrayList<Paragrafo>>>  ottieniInfoNotifiche()
        {
              return autoreLoggato.ottieniProposte();
        }

        public void implementaParagrafoInUnaNuovaPagina(String contenuto)
        {
                Paragrafo daImplementare = autoreLoggato.creaParagrafo(contenuto ,
                                                                paginaTemporanea.testo.size(),
                                                                Azione.Aggiungere,
                                                                paginaTemporanea);

                daImplementare.impostaCollegamento(collegamentoDaImplementare);
                svuotaCollegamentoTemporaneo();

                daImplementare.impostaStato(Stato.Approvato);

                paginaTemporanea.applicaParagrafo(daImplementare);
        }

        public void inviaProposta(String contenutoParagrafo, int posizione,  Azione azione, Collegamento collegamentoParagrafo)
        {

                Paragrafo daInviare = new Paragrafo(contenutoParagrafo, posizione ,azione,  paginaTemporanea, autoreLoggato);
                daInviare.impostaCollegamento(collegamentoParagrafo);

                autoreLoggato.inviaProposta(daInviare,destinatarioTemporaneo);
        }

        public  void implementaParagrafoInPaginaEsistente(Paragrafo daImplementare)
        {
                autoreLoggato.elaborazioneProposta(daImplementare);
        }

        public void scartaOgniProposta(Pagina paginaDiRiferimento, int indiceDaScartare)
        {
                autoreLoggato.rifiutaTutteLeProposte(indiceDaScartare, paginaDiRiferimento);
        }

        public  ArrayList<Pagina> ottieniListaStorici()
        {

                return  autoreLoggato.ottieniListaStorici();
        }

        public  HashMap<Integer, ArrayList<Paragrafo>> ottieniStorico( Pagina paginaDiRiferimento)
        {
                // richiedi al database (da fare nel model)
                HashMap<Integer, ArrayList<Paragrafo>> storico  = paginaDiRiferimento.storicoPagina;
                return storico ;
        }

        public  Pagina cercaPaginasulDB(String titoloPagina)
        {
                ImplementazionePostgresDAO.connectDAO();
                Pagina paginaDaVisitare = impPostegresDAO.ottieniPagina(titoloPagina);

                ImplementazionePostgresDAO.connectDAO();
                paginaDaVisitare.testo = impPostegresDAO.raccogliTesto(titoloPagina,paginaDaVisitare);

                utente.visitaPagina(paginaDaVisitare);

                return paginaDaVisitare;
        }

        public  void salvaValutazioneEVisita(int Valutazione){

                utente.recensisciPagina(Valutazione);
        }

        public void impostaCollegamentoTemporaneo(String titoloPaginaDiDestinazione){

                collegamentoDaImplementare = new Collegamento(paginaTemporanea.titolo, titoloPaginaDiDestinazione);
        }

        public Collegamento ottieniCollegamentoTemporaneo(){
                return  collegamentoDaImplementare;
        }

        public void svuotaCollegamentoTemporaneo(){
                collegamentoDaImplementare = null;
        }
}
