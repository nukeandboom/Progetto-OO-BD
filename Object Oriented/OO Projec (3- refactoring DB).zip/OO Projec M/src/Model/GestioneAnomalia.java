package Model;

public abstract class GestioneAnomalia
{
    private static final String[] listaAnomalie = {
            "> [ERRORE 0 ]: Le credenziali non possono essere vuote!",
            "> [ERRORE 1 ]: Credenziali errate!",
            "> [ERRORE 2 ]: Creazione pagina -> Il titolo selezionato è già esistente!",
            "> [ERRORE 3 ]: Creazione collegamento  -> Il titolo della pagina non può essere vuoto!",
            "> [ERRORE 4 ]: Invio proposta  -> soltanto il proprietario della pagina può aggiungere paragrafi!",
            "> [ERRORE 5 ]: Raccolta info  -> il titolo inserito non può essere nullo!",
            "> [ERRORE 6 ]: Creazione collegamento  -> la pagina d'arrivo e di provenienza non possono essere uguali!",
            "> [ERRORE 7 ]: Invio proposta -> la pagina selezionata risulta inesistente!",
            "> [ERRORE 8 ]: Non risulta alcun autore con l'username selezionato!",
            "> [ERRORE 9 ]: Attenzione, una paragrafo non può eguagliare o superare i 255 caratteri!",
            "> [ERRORE 9 ]: Attenzione, una pagina non può essere vuota!"
    };

    public void inviaAnomalia(int codice)
    {
        System.out.println(listaAnomalie[codice]);
    }
    public boolean determinaAnomalie(int[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 6, 16 -> {
                    if(dati[0] < dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                case 7, 17 -> {
                    if(dati[0] > dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                case 8, 9 ->{
                    if(dati[0] >= dati[1])
                        throw new IndexOutOfBoundsException(listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }
        }catch (IndexOutOfBoundsException exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public boolean determinaAnomalie(Object[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 0, 4, 5, 11, 20, 22 -> {
                    if(dati[0] == dati[1])
                        throw new Exception(listaAnomalie[codice]);
                }
                case 1, 10, 18 ->{
                    if(dati[0] != dati[1])
                        throw new Exception (listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }
        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public static boolean determinaAnomalie(String[] dati, int codice)
    {
        try {
            switch (codice)
            {
                case 0, 3 -> {
                    if(dati[0].contentEquals(""))
                        throw new  Exception(listaAnomalie[codice]);
                }
                case 2 ->{
                    if(!dati[0].contentEquals(dati[1]))
                        throw new  Exception (listaAnomalie[codice]);
                }
                default -> {/* nessuna azione effettuata */}
            }

        }catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }

    public  boolean determinaAnomalie(boolean err, boolean statoPrevisto, int codice)
    {
        try {
            if(err != statoPrevisto)
                throw new IllegalStateException(listaAnomalie[codice]);

        } catch (IllegalStateException exception)
        {
            System.out.println(exception.getMessage());
            return  false;
        }
        return true;
    }
}
