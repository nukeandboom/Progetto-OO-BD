package Model;

import ImplementazioneDAO.ImplementazionePostgresDAO;
import com.sun.source.tree.Tree;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.logging.Logger;

public class Autore extends GestioneAnomalia
{
    public final String username;
    private final Date dataIscrizione;
    private final String password;
    public int punteggio = 0;
    public ArrayList<Pagina> pagScritte = new ArrayList<>();
    public ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
   // private ArrayList<Pagina> storiciAccessibili = new ArrayList<>();
  //  private HashMap<Pagina,HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password, Date dataIscrizione, int punteggio)
    {
        this.username = username;
        this.password = password;
        this.dataIscrizione = dataIscrizione;
        this.punteggio = punteggio;
    }

    public static boolean controllaCredenzialiAccesso(String username, String password)
    {
        if(!determinaAnomalie(new String[]{username,null},0))
            return false;

        if(!determinaAnomalie(new String[]{password,null},0))
            return false;

        if(username.isBlank())
            return false;

        if(password.isBlank())
            return false;

        ImplementazionePostgresDAO.connectDAO();

        return ImplementazionePostgresDAO.confermacredenzialiDB(username,password);
    }

    public void creaPagina(Pagina paginaDiRiferimento)
    {
        pagScritte.add(paginaDiRiferimento);
       // storiciAccessibili.add(paginaDiRiferimento);
    }

    public Paragrafo creaParagrafo(String contenutoParagrafo, int posizione, Azione azione, Pagina paginaDiDestinazione)
    {
        return  new Paragrafo(contenutoParagrafo,
                posizione,
                azione,
                paginaDiDestinazione,
                this);
    }

    public void inviaProposta(Paragrafo daRevisionare, Autore destinatario)
    {
        if(destinatario == this)
        {
            daRevisionare.impostaStato(Stato.Approvato);
            ImplementazionePostgresDAO.implementaPropostaNelDB(daRevisionare, this);
        }
        else
            ImplementazionePostgresDAO.caricaPropostaNelDB(daRevisionare, destinatario, this);
    }

    public HashMap<String,HashMap<Integer,ArrayList<Paragrafo>>> ottieniNotifiche()
    {
        ArrayList<String> titoliPagine =  ImplementazionePostgresDAO.ottieniListaNomiPagineSoggetteAProposte();

        HashMap<String,HashMap<Integer,ArrayList<Paragrafo>>> hashMapNotifiche = new HashMap<>();
        HashMap<Integer,ArrayList<Paragrafo>> hashMapIndiciParagrafi;

        for(String str : titoliPagine)
        {
            hashMapIndiciParagrafi = ImplementazionePostgresDAO.ottieniHashMapIndiceParagrafiInAttesa(str);
            hashMapNotifiche.put(str, hashMapIndiciParagrafi);
        }

        return hashMapNotifiche;
    }

    public void elaborazioneProposta(Paragrafo propostaSelezionata)
    {
        propostaSelezionata.impostaStato(Stato.Approvato);
        ImplementazionePostgresDAO.aumentaPunteggioAutore(propostaSelezionata.);
        ImplementazionePostgresDAO.implementaPropostaNelDB();

        var indiceParagrafo = proposteInAttesa.get(propostaSelezionata.ottieniPaginaDiRiferimento()).get(propostaSelezionata.ottieniPosizione());

        indiceParagrafo.remove(propostaSelezionata);

        while (!indiceParagrafo.isEmpty())
        {
            // dire al database che sono stati rifiutati
            indiceParagrafo.getFirst().impostaStato(Stato.Rifiutato);
            indiceParagrafo.remove(indiceParagrafo.getFirst());
        }

        proposteInAttesa.get(propostaSelezionata.ottieniPaginaDiRiferimento()).remove(propostaSelezionata.ottieniPosizione());
    }

    public void rifiutaTutteLeProposte(int indiceParagrafo, Pagina paginaSelezionata)
    {
        var listaProposte =  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo);

        do
        {   // informare il db
            listaProposte.get(0).impostaStato(Stato.Rifiutato);
            listaProposte.remove(0);
        }while (listaProposte.isEmpty());

        proposteInAttesa.get(paginaSelezionata).remove(indiceParagrafo);
    }

    public ArrayList<Pagina> ottieniListaStorici()
    {
        return ImplementazionePostgresDAO.ottieniStoricoAutore(this);
    }

    /*
    public void mostraStoriciAccessibili()
    {
        System.out.println("> lista storici accessibili: ");

        for( int i = 0; i < storiciAccessibili.size(); i++)
        {
            System.out.print(i);
            System.out.print(") ");
            System.out.print(storiciAccessibili.get(i).titolo);

            if(storiciAccessibili.get(i).ottieniAutore() == this)
                System.out.println(" [Proprietario]");

            System.out.println();
        }
    }

    public Pagina ottienePaginaDaListaStorici(String titoloPagina)
    {
        for(var pag : storiciAccessibili)
        {
            if(pag.titolo.contentEquals(titoloPagina))
                return pag;
        }

        inviaAnomalia(15);
        return null;
    }

    public void mostraStorico(Pagina paginaDiRiferimento, int indiceParagrafo)
    {
        if(!storiciAccessibili.contains(paginaDiRiferimento))
        {
            inviaAnomalia(25);
            return;
        }

        var storicoInEsame = paginaDiRiferimento.storicoPagina;

        if(!storicoInEsame.containsKey(indiceParagrafo))
        {
            inviaAnomalia(15);
            return;
        }

        System.out.println("> info storico -> paragrafo " + indiceParagrafo + ":");

        for( Paragrafo par :  storicoInEsame.get(indiceParagrafo))
        {
            System.out.println(par.ottieniContenuto());
        }
    }


     */
}