package Model;

import ImplementazioneDAO.ImplementazionePostgresDAO;

public class Utente {

    private int id;
    private Pagina paginaVisualizzata;

    public Utente(int id)
    {
        this.id = id;
    }

    public void visitaPagina(Pagina pagina)
    {
        paginaVisualizzata = pagina;
    }

    public void recensisciPagina(int recensione)
    {
        ImplementazionePostgresDAO.connectDAO();
        ImplementazionePostgresDAO.mandaValutazioneEVisita( recensione, paginaVisualizzata.titolo, id);

        paginaVisualizzata = null;
    }
}
