package Model;

public enum Azione
{
    Aggiornare,
    Aggiungere,
    Svuotare

}
