package ImplementazioneDAO;

import Controller.Controller;
import Database.ConnessioneDatabase;
import Model.Collegamento;
import Model.Pagina;
import Model.Paragrafo;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class ImplementazionePostgresDAO {

    private static Connection connection;
    private static final String INSERT_USERS_SQL = "INSERT INTO utente" + "(idutente) VALUES " + " (?);";
    private static final String GET_PAGINA_SQL = "SELECT * FROM pagina  WHERE titolo = ? ";
    private static final String POPULATE_TEXT_PAGINA_VISITATA = "SELECT * FROM paragrafo WHERE titolopag = ? AND stato = 'accettato' ";
    private static final String SEARCH_COLLEGAMENTO = "SELECT titolopag_destinazione FROM collegamento WHERE titolopag_origin = ? AND data_origin = ?  AND posizione_origin = ? AND orario_origin = ?";
    private static final String INSERT_NEW_AUTHOR_SQL = "INSERT INTO autore " + "(username,password,data_iscrizione,punteggio) VALUES" + "(?,?,?,?)";
    private static final String INSERT_NEW_VISITandVALUTATION_SQL = "INSERT INTO visita " + "(idutente_in_visita,data_visita,valutazione,titolo_pagina_visitata) VALUES" + "(?,?,?,?)";
    private static final String INSERT_NEW_PARAGRAFO_SQL = "INSERT INTO paragrafo" + "(contenuto,data,titolopag,posizione,stato,orario) VALUES" + "(?,?,?,?,?,?)";
    private static final String INSERT_NEW_COLLEGAMENTO_SQL = "INSERT INTO COLLEGAMENTO" + "(titolopag_origin,data_origin,posizione_origin,titolopag_destinazione,orario_origin) VALUES" + "(?,?,?,?,?)";

    private static final String INSERT_NEW_PAGINA_SQL = "INSERT INTO pagina" + "(titolo,data_creazione,nome_proprietario) VALUES" + "(?, ?, ?)";

    private static final String REMOVE_PAGINA_SQL = "DELETE FROM pagina WHERE titolo = ?";

    private static final String CONFIRM_PARAGRAFO_SQL = "UPDATE paragrafo SET stato = 'accettato' WHERE stato = 'in attesa' AND data = ? AND posizione = ? AND orario = ? and titolopag = ?";

    private static final String GET_PAGINE_CON_PROPOSTE_SQL = "SELECT * FROM pagina WHERE nome_proprietario = ?";



    public  static void connectDAO() {
        try {
            connection = ConnessioneDatabase.getInstance().connection;
            System.out.println("Istanza avviata");
        } catch (SQLException e) {
            System.out.println("Errore connessione al database " + e.getMessage());
        }

    }

    public static int nuovoutentedaDB()
    {
        int last_user_value = 0;

        try {

            Statement leggiutentiPS = connection.createStatement
                    (ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = leggiutentiPS.executeQuery("SELECT * FROM \"utente\"");

            while (rs.next())
            {
                last_user_value = rs.getInt("idutente");
            }

            System.out.println("ultimo utente = " + (last_user_value + 1));

            rs.close();
            leggiutentiPS.close();
            connection.close();
        } catch (Exception e) {
            System.out.println("Errore lettura utenti " + e.getMessage());
        }

        return last_user_value + 1;
    }

    public static void confermaNuovoIdUtenteDB(int id){

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL))
        {
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

    }

    public  static boolean confermacredenzialiDB(String username,String password){

        boolean check = false;

        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM autore WHERE username =?  AND password = ?")){

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {

                String username_to_load;
                String password_to_load;
                Date date_to_load;
                java.util.Date utilDate;
                int punteggio_to_load;

                System.out.println("Trovata corrispondenza nel database");
                username_to_load = resultSet.getString("username");
                password_to_load = resultSet.getString("password");
                date_to_load = resultSet.getDate("data_iscrizione");
                // conversione sql.data   ---- >>  lang.data

                utilDate = new java.util.Date(date_to_load.getTime());
                punteggio_to_load = resultSet.getInt("punteggio");
                Controller.caricaAutoreLoggato(username_to_load,password_to_load,utilDate,punteggio_to_load);

                check = true;
            }else
                System.out.println("Nessun account corrispondente");

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

        return check;
    }




    public static boolean ottieniInfoGeneraliPagina(String titoloPagina) {

        String titolo_to_load = null;
        String username_proprietario_to_load = null;

        try(PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINA_SQL)){

            preparedStatement.setString(1, titoloPagina);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                titolo_to_load = resultSet.getString(1);
                username_proprietario_to_load = resultSet.getString(3);
            }


            if(titolo_to_load != null) {
                Controller.impostaPaginaTemporanea(titolo_to_load, username_proprietario_to_load);
            }


            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            System.out.println(e.getMessage());
            return false;

        }

        if(titolo_to_load == null){ return false;}

        return true;
    }

    public static int ottieniPunteggioPagina(String titolo) {


        // X Matt, qui serve recuperare il punteggio di una pagina

        int punteggio = 0;

        return punteggio;
    }


    public static void caricaCollegamentoSulDB(String titoloPaginaPartenza,String titoloPaginaDestinazione,int posizione, Date data, Time orario)
    {

        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_COLLEGAMENTO_SQL)) {

            preparedStatement.setString(1,titoloPaginaPartenza);
            preparedStatement.setDate(2,data);
            preparedStatement.setInt(3,posizione);
            preparedStatement.setString(4,titoloPaginaDestinazione);
            preparedStatement.setTime(5,orario);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

    }

     public static void caricaPropostaSulDB(String autoreMittente,int posizione, String pagina,Date data,Time orario)
     {

         try {

             String storedProcedureCall = "CALL create_relation_4new_paragrafo_proposto_procedure(?, ?, ?, ?, ?)";

             CallableStatement callableStatement = connection.prepareCall(storedProcedureCall);
             callableStatement.setString(1,autoreMittente);
             callableStatement.setDate(2,data);
             callableStatement.setTime(3,orario);
             callableStatement.setString(4,pagina);
             callableStatement.setInt(5,posizione);

             callableStatement.execute();

             callableStatement.close();
             connection.close();

         } catch (SQLException e) {

             System.out.println(e.getMessage());
         }

     }

    public static void caricaParagrafoSulDB(String contenuto, int posizione, String titoloPagina,Date dataCreazione, Time orarioCreazione, String stato) {

        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_PARAGRAFO_SQL)) {

            preparedStatement.setString(1, contenuto);
            preparedStatement.setDate(2, dataCreazione);
            preparedStatement.setString(3, titoloPagina);
            preparedStatement.setInt(4, posizione);
            preparedStatement.setString(5,stato);
            preparedStatement.setTime(6,orarioCreazione);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

    }

    public static void confermaParagrafoSulDB(int posizione, java.util.Date data, Time orario, String titoloPagina)
    {
          try(PreparedStatement preparedStatement = connection.prepareStatement(CONFIRM_PARAGRAFO_SQL)) {

              java.sql.Date sqlDate = new java.sql.Date(data.getTime());

              preparedStatement.setDate(1,sqlDate);
              preparedStatement.setInt(2,posizione);
              preparedStatement.setTime(3,orario);
              preparedStatement.setString(4,titoloPagina);

              preparedStatement.executeUpdate();

              preparedStatement.close();
              connection.close();


          }catch (SQLException e){

              System.out.println(e.getMessage());
          }


    }

     public static HashMap<String,HashMap<Integer,ArrayList<String>>> ottieniStoricoAutore(String autore)
     {


         HashMap<String,HashMap<Integer,ArrayList<String>>> hashMapStorici = new HashMap<>();

         return hashMapStorici;
     }

     public static ArrayList<String> ottieniListaNomiPagineSoggetteAProposte(String nomeAutore)
     {
         ArrayList<String> titoliPagine = new ArrayList<>();
         String titolopag;

         try(PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINE_CON_PROPOSTE_SQL)){

             preparedStatement.setString(1,nomeAutore);

             ResultSet rs = preparedStatement.executeQuery();

             while(rs.next()){

                 titolopag = rs.getString(1);
                 titoliPagine.add(titolopag);
             }

             rs.close();
             preparedStatement.close();
             connection.close();

         }catch (SQLException e){

             System.out.println(e.getMessage());

         }

         return  titoliPagine;
     }

     public static  HashMap<Integer,ArrayList<String[]>> ottieniHashMapIndiceParagrafiInAttesa(String titoloPagina)
     {
         // X MATT, qui credo che serva cercare la pagina (magari puoi usare la funzione ottieniInfoGeneraliPagina() )
         // e ritornare tutti i paragrafi in attesa dentro un arraylist
         // E' INDISPENSABILE CHE I PARAGRAFI ABBIANO AL LORO INTERNO INDICATO IL NOME DEL PROPRIETARIO


         HashMap<Integer,ArrayList<String[]>>  hashMapTemporanea = new HashMap<>();

         //esempio popolamento hashmap              |testo| |autore| |pagatt|   |pagDest|
         //hashMapTemporanea.get(0).add(new String[]{"ciao", "bob", "pagAttuale","pagDestinazione"});

         return hashMapTemporanea;
     }


     public static void rimuoviPaginaScartataDalDB(String paginaDaScartare)
     {

         try(PreparedStatement preparedStatement = connection.prepareStatement(REMOVE_PAGINA_SQL)) {

             preparedStatement.setString(1,paginaDaScartare);


             int rowsAffected = preparedStatement.executeUpdate();

             if (rowsAffected > 0) {
                 System.out.println("Successfully removed page: " + paginaDaScartare);
             } else {
                 System.out.println("No page found with title: " + paginaDaScartare);
             }

             preparedStatement.close();
             connection.close();


         }catch (SQLException e){

             System.out.println(e.getMessage());

         }

     }

    public static void raccogliTesto(String titolo, String titolopag) {


        String contenuto_to_load;
        Time orario_to_load;
        int posizione_to_load;
        Date data_to_convert;

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(POPULATE_TEXT_PAGINA_VISITATA);

            preparedStatement.setString(1, titolo);

            ResultSet resultSet = preparedStatement.executeQuery();


            while (resultSet.next()) {

                contenuto_to_load = resultSet.getString("contenuto");
                posizione_to_load = resultSet.getInt("posizione");
                data_to_convert = resultSet.getDate("data");
                orario_to_load = resultSet.getTime("orario");


                Controller.aggiungiParagrafoaPaginaTemporanea(contenuto_to_load,posizione_to_load,data_to_convert,orario_to_load);

            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        }catch(SQLException e){

            System.out.println("Errore nella raccolta del testo" + e.getMessage());
        }

    }

    public static Boolean cercaCollegamentisuDB(int posizione, String titolopaginaDiPartenza, java.util.Date data, Time orario){


        String titoloPaginaDestinazione = null;
        boolean check = false;
        try {

            PreparedStatement preparedStatement = connection.prepareStatement(SEARCH_COLLEGAMENTO);
            java.sql.Date sqlDate = new java.sql.Date(data.getTime());


            preparedStatement.setString(1, titolopaginaDiPartenza);
            preparedStatement.setDate(2,sqlDate);
            preparedStatement.setInt(3, posizione);
            preparedStatement.setTime(4,orario);

            ResultSet resultSet = preparedStatement.executeQuery();

            while ( resultSet.next() ){

                titoloPaginaDestinazione = resultSet.getString("titolopag_destinazione");

                Controller.creaCollegamentoTemporaneo(titolopaginaDiPartenza,titoloPaginaDestinazione);
                check = true;
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

      return check;
    }


    public static void caricaNuovoAutoreSulDB(String username, String password, java.util.Date dataIscrizione) {

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_AUTHOR_SQL)) {

            Date conversioneData = new java.sql.Date(dataIscrizione.getTime());
            int punteggio = 0;

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setDate(3,conversioneData);
            preparedStatement.setInt(4, punteggio);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }
    }


    public static void MandaValutazioneEVisita(int valutazione, String TitolopaginaVisitata, int idutente){


        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_VISITandVALUTATION_SQL)){

            LocalDate currentDate = LocalDate.now();
            Date sqlDate = Date.valueOf(currentDate);

            preparedStatement.setInt(1, idutente);
            preparedStatement.setDate(2, sqlDate);
            preparedStatement.setInt(3, valutazione);
            preparedStatement.setString(4,TitolopaginaVisitata);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        }catch (SQLException e){

            System.out.println(e.getMessage());
        }
    }

    public static void memorizzaPaginaSulDB(String titoloPagina, Date data , String nomeCreatore) {

        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_PAGINA_SQL)) {

            preparedStatement.setString(1,titoloPagina);
            preparedStatement.setDate(2,data);
            preparedStatement.setString(3,nomeCreatore);

            preparedStatement.executeUpdate();


            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

    }
}
