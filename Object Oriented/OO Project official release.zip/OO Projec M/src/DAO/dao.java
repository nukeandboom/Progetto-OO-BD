package DAO;


public interface dao {
}
