package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Autore
{
    private final String username;
    private final Date dataIscrizione;
    private final String password;
    private int punteggio = 0;
    private ArrayList<Pagina> pagScritte = new ArrayList<>();
    private ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
    private ArrayList<String> storiciAccessibili = new ArrayList<>();
    private ArrayList<String> pagineConNotifiche = new ArrayList<>();
    private HashMap<String, HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password, Date dataIscrizione, int punteggio)
    {
        this.username = username;
        this.password = password;
        this.dataIscrizione = dataIscrizione;
        this.punteggio = punteggio;
    }

    public String ottieniUsername()
    {
        return username;
    }

    public ArrayList<String> ottieniStoriciAccessibili(){
        return storiciAccessibili;
    }

    public void impostaStoriciAccessibili(ArrayList<String> listaTitoliPagine)
    {
        this.storiciAccessibili = listaTitoliPagine;
    }

    public void impostaTitoliPagineConNotifiche(ArrayList<String> titoliPagineconNotifiche)
    {
        this.pagineConNotifiche = titoliPagineconNotifiche;
    }
    public ArrayList<String> ottieniTitoliPagineConNotifiche()
    {
        return pagineConNotifiche;
    }

    public HashMap<String, HashMap<Integer, ArrayList<Paragrafo>>> ottieniProposteInAttesa()
    {
        return proposteInAttesa;
    }
}