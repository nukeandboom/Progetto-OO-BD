package Model;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;

public class Paragrafo
{
    private String contenuto;
    private Stato stato = Stato.InAttesa;
    private final java.util.Date dataCreazione;
    private final Time orarioCreazione;
    private int posizione;
    private Autore proprietario;
    private String nomeAutore;
    private Pagina paginaDiRiferimento;
    private String titoloPagina;
    private Collegamento collegamento = null;

    /** utilizzato per la creazione di paragrafi  generici*/
    public Paragrafo(String contenuto, int posizione, Pagina pagina, Autore proprietario)
    {
        this.contenuto = contenuto;
        this.proprietario = proprietario;
        this.posizione = posizione;
        paginaDiRiferimento = pagina;

        long dataAttuale =System.currentTimeMillis();
        LocalTime orarioAttuale = LocalTime.now();

        this.orarioCreazione = Time.valueOf(orarioAttuale);
        this.dataCreazione = new java.sql.Date(dataAttuale);
    }

    /** utilizzato per la creazione di paragrafi con dati caricati dal DB*/
    public Paragrafo(String contenuto, int posizione, Pagina pagina, java.util.Date dataCreazione, Time orarioCreazione)
    {
        this.contenuto = contenuto;
        this.posizione = posizione;
        paginaDiRiferimento = pagina;
        this.orarioCreazione = orarioCreazione;
        this.dataCreazione = dataCreazione;
    }

    /** utilizzato per la creazione di paragrafi con dati caricati dal DB, in assenza di un istanza di Pagina*/
    public Paragrafo(String contenuto, int posizione, String titoloPagina, java.util.Date dataCreazione, Time orarioCreazione)
    {
        this.contenuto = contenuto;
        this.posizione = posizione;
        this.titoloPagina = titoloPagina;
        this.orarioCreazione = orarioCreazione;
        this.dataCreazione = dataCreazione;
    }

    public Collegamento ottienicollegamento(){
        return collegamento;
    }
    public  void impostaCollegamento(Collegamento collegamento){
        this.collegamento = collegamento;
    }
    public String ottieniContenuto(){
        return  contenuto;
    }
    public Pagina ottieniPaginaDiRiferimento(){
        return  paginaDiRiferimento;
    }
    public int ottieniPosizione(){
        return posizione;
    }
    public java.util.Date ottieniData(){return dataCreazione;}
    public Time ottieniOrario(){return orarioCreazione;}

}
