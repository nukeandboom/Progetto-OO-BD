package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Pagina
{
    private String titolo;
    private Date   dataCreazione;
    private Autore proprietario;
    private String nomeAutore;
    private int valutazione;
    private ArrayList<Paragrafo> testo = new ArrayList<>();

    private HashMap<Integer,ArrayList<Paragrafo>> storicoPagina = new HashMap<>();

    public Pagina(String titolo, Autore proprietario)
    {
        this.titolo = titolo;
        this.proprietario = proprietario;
        this.nomeAutore = proprietario.ottieniUsername();
        dataCreazione = new Date();
    }

    public Pagina(String titolo, String nomeAutore)
    {
        this.titolo = titolo;
        this.nomeAutore = nomeAutore;
    }

    public Autore ottieniAutore(){
        return this.proprietario;
    }

    public String ottieniTitolo(){return titolo;}

    public Date ottieniDataCreazione(){return dataCreazione;}

    public String ottieniSoloNomeAutore(){return nomeAutore;}

    public int ottieniValutazione(){return valutazione;}

    public ArrayList<Paragrafo> ottieniTesto() {
        return testo;
    }

    public HashMap<Integer, ArrayList<Paragrafo>> ottieniStoricoPagina() {
        return storicoPagina;
    }
}
