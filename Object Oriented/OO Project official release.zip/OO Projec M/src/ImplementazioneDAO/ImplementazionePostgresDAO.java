package ImplementazioneDAO;

import Controller.Controller;
import DAO.dao;
import Database.ConnessioneDatabase;

import java.text.SimpleDateFormat;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class ImplementazionePostgresDAO implements dao {

    private static Connection connection;

    private static final String INSERT_USERS_SQL = "INSERT INTO utente" + "(idutente) VALUES " + " (?);";

    private static final String GET_PAGINA_SQL = "SELECT * FROM pagina  WHERE titolo = ? ";

    private static final String POPULATE_TEXT_PAGINA_VISITATA = "SELECT * FROM paragrafo WHERE titolopag = ? AND stato = 'accettato' ORDER BY posizione ASC";

    private static final String SEARCH_COLLEGAMENTO = "SELECT titolopag_destinazione FROM collegamento WHERE titolopag_origin = ? AND data_origin = ?  AND posizione_origin = ? AND orario_origin = ?";

    private static final String INSERT_NEW_AUTHOR_SQL = "INSERT INTO autore " + "(username,password,data_iscrizione,punteggio) VALUES" + "(?,?,?,?)";

    private static final String INSERT_NEW_VISITandVALUTATION_SQL = "INSERT INTO visita " + "(idutente_in_visita,data_visita,valutazione,titolo_pagina_visitata) VALUES" + "(?,?,?,?)";

    private static final String INSERT_NEW_PARAGRAFO_SQL = "INSERT INTO paragrafo" + "(contenuto,data,titolopag,posizione,stato,orario) VALUES" + "(?,?,?,?,?,?)";

    private static final String INSERT_NEW_COLLEGAMENTO_SQL = "INSERT INTO COLLEGAMENTO" + "(titolopag_origin,data_origin,posizione_origin,titolopag_destinazione,orario_origin) VALUES" + "(?,?,?,?,?)";

    private static final String INSERT_NEW_PAGINA_SQL = "INSERT INTO pagina" + "(titolo,data_creazione,nome_proprietario) VALUES" + "(?, ?, ?)";

    private static final String REMOVE_PAGINA_SQL = "DELETE FROM pagina WHERE titolo = ?";

    private static final String CONFIRM_PARAGRAFO_SQL = "UPDATE paragrafo SET stato = 'accettato' WHERE stato = 'in attesa' AND data = ? AND posizione = ? AND orario = ? and titolopag = ?";

    private static final String GET_PAGINE_CON_PROPOSTE_SQL = "SELECT titolo FROM pagina JOIN paragrafo on paragrafo.titolopag = pagina.titolo WHERE nome_proprietario = ? AND stato = 'in attesa'";

    private static final String GET_PUNTEGGIO_PAGINA_SQL = "SELECT valutazione FROM visita WHERE titolo_pagina_visitata = ? ";

    private static final String GET_STORICI_ACCESSIBILI_SQL = "SELECT titolopag_commit FROM proposta WHERE username_committente = ? " ;

    private static final String POPULATE_STORICI_SQL = "SELECT * FROM paragrafo WHERE ( titolopag = ? AND stato = 'expired' ) OR (titolopag = ? AND stato = 'accettato') ORDER BY posizione ASC";

    private static final String POPULATE_NOTIFICHE_SQL = "SELECT * FROM paragrafo WHERE titolopag = ? AND stato = 'in attesa' ORDER BY posizione ASC ";

    private static final String REMOVE_PARAGRAFI_SCARTATI = "DELETE FROM paragrafo WHERE titolopag = ? AND data = ? AND orario = ? AND posizione = ? AND stato = 'in attesa' ";


    public  static void connectDAO() {

        try {
            connection = ConnessioneDatabase.getInstance().connection;
        } catch (SQLException e) {
            System.out.println("Errore connessione al database " + e.getMessage());
        }
    }

    public static int nuovoUtenteDaDB()
    {
        int idScorsoUtente = 0;

        try {

            Statement leggiutentiPS = connection.createStatement
                    (ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = leggiutentiPS.executeQuery("SELECT * FROM \"utente\"");

            while (rs.next())
            {
                idScorsoUtente = rs.getInt("idutente");
            }

            rs.close();
            leggiutentiPS.close();
            connection.close();

        } catch (Exception e) {

            System.out.println("Errore lettura utenti " + e.getMessage());
        }

        return idScorsoUtente + 1;
    }

    public static void confermaNuovoIdUtenteDB(int id){

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL))
        {
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }
    }

    public  static boolean confermaCredenzialiDB(String username, String password){

        boolean check = false;

        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM autore WHERE username =?  AND password = ?")){

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {

                String usernameDaCaricare;
                String passwordDaCaricare;
                Date dataDaCaricare;
                java.util.Date dataTemp;
                int punteggioDaCaricare;

                usernameDaCaricare = resultSet.getString("username");
                passwordDaCaricare = resultSet.getString("password");
                dataDaCaricare = resultSet.getDate("data_iscrizione");

                dataTemp = new java.util.Date(dataDaCaricare.getTime());
                punteggioDaCaricare = resultSet.getInt("punteggio");
                Controller.caricaAutoreLoggato(usernameDaCaricare, passwordDaCaricare,dataTemp, punteggioDaCaricare);

                check = true;
            }else
                System.out.println("Nessun account corrispondente");

            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

        return check;
    }

    public static boolean ottieniInfoGeneraliPagina(String titoloPagina) {

        String titoloDaCaricare = null;
        String usernameProprietarioDaCaricare = null;

        try(PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINA_SQL)){

            preparedStatement.setString(1, titoloPagina);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                titoloDaCaricare = resultSet.getString(1);
                usernameProprietarioDaCaricare = resultSet.getString(3);
            }


            if(titoloDaCaricare != null) {
                Controller.impostaPaginaTemporanea(titoloDaCaricare, usernameProprietarioDaCaricare);
            }


            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
            return false;
        }

        if(titoloDaCaricare == null){
            return false;
        }

        return true;
    }


    public static boolean verificaEsistenzaPagina(String titoloPagina) {

        boolean risultato = false;

        try(PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINA_SQL)){

            preparedStatement.setString(1, titoloPagina);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                risultato = true;
            }


            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

        return risultato;
    }



    public static int ottieniPunteggioPagina(String titolo) {

        int punteggio = 0;
        int counterValutazione = 0;

        try(PreparedStatement preparedStatement = connection.prepareStatement(GET_PUNTEGGIO_PAGINA_SQL)) {

            preparedStatement.setString(1,titolo);

            ResultSet rs = preparedStatement.executeQuery();

            while(rs.next()){

                punteggio = punteggio + rs.getInt("valutazione");
                counterValutazione = counterValutazione + 1;
            }

            rs.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }


        if(counterValutazione != 0 ) {
            punteggio = punteggio / counterValutazione;
        }else {
            punteggio = 0;
        }

        return punteggio;
    }


    public static void caricaCollegamentoSulDB(String titoloPaginaPartenza,String titoloPaginaDestinazione,int posizione, Date data, Time orario)
    {
        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_COLLEGAMENTO_SQL)) {

            preparedStatement.setString(1,titoloPaginaPartenza);
            preparedStatement.setDate(2,data);
            preparedStatement.setInt(3,posizione);
            preparedStatement.setString(4,titoloPaginaDestinazione);
            preparedStatement.setTime(5,orario);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

    }

     public static void caricaPropostaSulDB(String autoreMittente,int posizione, String pagina,Date data,Time orario)
     {

         try {

             String storedProcedureCall = "CALL create_relation_4new_paragrafo_proposto_procedure(?, ?, ?, ?, ?)";

             CallableStatement callableStatement = connection.prepareCall(storedProcedureCall);
             callableStatement.setString(1,autoreMittente);
             callableStatement.setDate(2,data);
             callableStatement.setTime(3,orario);
             callableStatement.setString(4,pagina);
             callableStatement.setInt(5,posizione);

             callableStatement.execute();

             callableStatement.close();
             connection.close();

         } catch (SQLException e) {

             System.out.println(e.getMessage());
         }

     }

    public static void caricaParagrafoSulDB(String contenuto, int posizione, String titoloPagina,Date dataCreazione, Time orarioCreazione, String stato) {

        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_PARAGRAFO_SQL)) {

            preparedStatement.setString(1, contenuto);
            preparedStatement.setDate(2, dataCreazione);
            preparedStatement.setString(3, titoloPagina);
            preparedStatement.setInt(4, posizione);
            preparedStatement.setString(5,stato);
            preparedStatement.setTime(6,orarioCreazione);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

    }

    public static void confermaParagrafoSulDB(int posizione, java.util.Date data, Time orario, String titoloPagina)
    {
          try(PreparedStatement preparedStatement = connection.prepareStatement(CONFIRM_PARAGRAFO_SQL)) {

              java.sql.Date sqlDate = new java.sql.Date(data.getTime());

              preparedStatement.setDate(1,sqlDate);
              preparedStatement.setInt(2,posizione);
              preparedStatement.setTime(3,orario);
              preparedStatement.setString(4,titoloPagina);

              preparedStatement.executeUpdate();

              preparedStatement.close();
              connection.close();


          }catch (SQLException e){

              System.out.println(e.getMessage());
          }


    }

    public static ArrayList<String> ottieniStoriciAccessibili(String nomeAutore){

        ArrayList<String> storiciAccessibili = new ArrayList<String>();

        try(PreparedStatement preparedStatement = connection.prepareStatement(GET_STORICI_ACCESSIBILI_SQL)) {

            preparedStatement.setString(1,nomeAutore);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()){

                String titoloPaginaAccessibile = rs.getString("titolopag_commit");

                if(!storiciAccessibili.contains(titoloPaginaAccessibile)) {
                    storiciAccessibili.add(titoloPaginaAccessibile);
                }
            }

            rs.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

        return storiciAccessibili;
    }

     public static HashMap<String,HashMap<Integer,ArrayList<String>>> ottieniStoricoAutore(ArrayList<String> storiciAccessibili)
     {
         HashMap<String,HashMap<Integer,ArrayList<String>>> hashMapStoriciDaRitornare = new  HashMap<>();

         for(String titolo : storiciAccessibili)
         {
             connectDAO();

             String contenutoCaricato;
             int posizione;

             try (PreparedStatement preparedStatement = connection.prepareStatement(POPULATE_STORICI_SQL)) {

                 preparedStatement.setString(1,titolo);
                 preparedStatement.setString(2,titolo);

                 ResultSet rs = preparedStatement.executeQuery();

                 if(!hashMapStoriciDaRitornare.containsKey(titolo)) {
                     hashMapStoriciDaRitornare.put(titolo, new HashMap<>());
                 }

                 while (rs.next()){

                     contenutoCaricato = rs.getString("contenuto");
                     posizione = rs.getInt("posizione");


                     if(!hashMapStoriciDaRitornare.get(titolo).containsKey(posizione)) {
                         hashMapStoriciDaRitornare.get(titolo).put(posizione,new ArrayList<>());
                     }

                     hashMapStoriciDaRitornare.get(titolo).get(posizione).add(contenutoCaricato);
                 }

                 rs.close();
                 preparedStatement.close();
                 connection.close();

             } catch (SQLException e) {

                 System.out.println(e.getMessage());
             }

         }

         return hashMapStoriciDaRitornare;
     }

     public static ArrayList<String> ottieniListaNomiPagineSoggetteAProposte(String nomeAutore)
     {
         ArrayList<String> listaTitoliPagine = new ArrayList<>();
         String titoloPagina;

         try(PreparedStatement preparedStatement = connection.prepareStatement(GET_PAGINE_CON_PROPOSTE_SQL)){

             preparedStatement.setString(1,nomeAutore);

             ResultSet rs = preparedStatement.executeQuery();

             while(rs.next()){

                 titoloPagina = rs.getString(1);
                 if(!listaTitoliPagine.contains(titoloPagina)) {

                     listaTitoliPagine.add(titoloPagina);
                 }
             }

             rs.close();
             preparedStatement.close();
             connection.close();

         }catch (SQLException e){

             System.out.println(e.getMessage());
         }

         return listaTitoliPagine;
     }


     public static ArrayList<String[]> ottieniListaInfoParagrafi(String titoloPagina)
     {
           ArrayList<String[]> infoParagrafiDaRitornare = new ArrayList<>();

           String contenuto;
           String posizione;
           String data;
           String orario;

           try(PreparedStatement preparedStatement = connection.prepareStatement(POPULATE_NOTIFICHE_SQL)) {

               preparedStatement.setString(1,titoloPagina);

               ResultSet rs = preparedStatement.executeQuery();

               SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
               SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

               while(rs.next()){

                   contenuto = rs.getString("contenuto");
                   posizione = String.valueOf(rs.getInt("posizione"));
                   data = dateFormat.format(rs.getDate("data"));
                   orario =  timeFormat.format(rs.getTime("orario"));

                   infoParagrafiDaRitornare.add(new String[]{contenuto,posizione,data,orario});
               }

               rs.close();
               preparedStatement.close();
               connection.close();

           }catch (SQLException e){

               System.out.println(e.getMessage());
           }

            return infoParagrafiDaRitornare;
     }


     public static void rimuoviPaginaScartataDalDB(String paginaDaScartare)
     {

         try(PreparedStatement preparedStatement = connection.prepareStatement(REMOVE_PAGINA_SQL)) {

             preparedStatement.setString(1,paginaDaScartare);

             int pagineRimosseCounter = preparedStatement.executeUpdate();

             if (pagineRimosseCounter > 0) {
                 System.out.println("Rimossa la seguente pagina: " + paginaDaScartare);
             } else {
                 System.out.println("Nessuna pagina trovata con questo titolo: " + paginaDaScartare);
             }

             preparedStatement.close();
             connection.close();

         }catch (SQLException e){

             System.out.println(e.getMessage());

         }
     }

    public static void raccogliTesto(String titolo) {

        String contenutoDaCaricare;
        Time orarioDaCaricare;
        int posizioneDaCaricare;
        Date dataDaConvertire;

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(POPULATE_TEXT_PAGINA_VISITATA);

            preparedStatement.setString(1, titolo);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                contenutoDaCaricare = resultSet.getString("contenuto");
                posizioneDaCaricare = resultSet.getInt("posizione");
                dataDaConvertire = resultSet.getDate("data");
                orarioDaCaricare = resultSet.getTime("orario");

                Controller.aggiungiParagrafoAPaginaTemporanea(contenutoDaCaricare, posizioneDaCaricare, dataDaConvertire, orarioDaCaricare);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch(SQLException e){

            System.out.println("Errore nella raccolta del testo" + e.getMessage());
        }
    }

    public static Boolean cercaCollegamentisuDB(int posizione, String titolopaginaDiPartenza, java.util.Date data, Time orario){

        String titoloPaginaDestinazione;
        boolean check = false;

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(SEARCH_COLLEGAMENTO);

            java.sql.Date sqlDate = new java.sql.Date(data.getTime());

            preparedStatement.setString(1, titolopaginaDiPartenza);
            preparedStatement.setDate(2,sqlDate);
            preparedStatement.setInt(3, posizione);
            preparedStatement.setTime(4,orario);

            ResultSet resultSet = preparedStatement.executeQuery();

            while ( resultSet.next() ){

                titoloPaginaDestinazione = resultSet.getString("titolopag_destinazione");

                Controller.creaCollegamentoTemporaneo(titolopaginaDiPartenza,titoloPaginaDestinazione);
                check = true;
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }

      return check;
    }


    public static void caricaNuovoAutoreSulDB(String username, String password, java.util.Date dataIscrizione) {

        try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_AUTHOR_SQL)) {

            Date conversioneData = new java.sql.Date(dataIscrizione.getTime());
            int punteggio = 0;

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setDate(3,conversioneData);
            preparedStatement.setInt(4, punteggio);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }
    }


    public static void mandaValutazioneEVisita(int valutazione, String TitolopaginaVisitata, int idutente){


        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_VISITandVALUTATION_SQL)){

            LocalDate dataCorrente = LocalDate.now();
            Date dataSql = Date.valueOf(dataCorrente);

            preparedStatement.setInt(1, idutente);
            preparedStatement.setDate(2, dataSql);
            preparedStatement.setInt(3, valutazione);
            preparedStatement.setString(4,TitolopaginaVisitata);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    public static void memorizzaPaginaSulDB(String titoloPagina, Date data , String nomeCreatore) {

        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_NEW_PAGINA_SQL)) {

            preparedStatement.setString(1,titoloPagina);
            preparedStatement.setDate(2,data);
            preparedStatement.setString(3,nomeCreatore);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }
    }

    public static void rifiutaParagrafo(String titoloPagina, int posizione, Time orario, Date data) {

        try(PreparedStatement preparedStatement = connection.prepareStatement(REMOVE_PARAGRAFI_SCARTATI)){

            preparedStatement.setString(1,titoloPagina);
            preparedStatement.setDate(2,data);
            preparedStatement.setTime(3,orario);
            preparedStatement.setInt(4,posizione);

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

        }catch (SQLException e){

            System.out.println(e.getMessage());
        }
    }
}
