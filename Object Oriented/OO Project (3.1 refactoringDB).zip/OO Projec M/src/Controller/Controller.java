package Controller;

import Model.*;
import ImplementazioneDAO.*;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Controller extends GestioneAnomalia
{
        private static Utente utente;
        private Autore autoreLoggato;
        private Autore destinatarioTemporaneo;
        private Pagina paginaTemporanea;
        private Collegamento collegamentoDaImplementare;
        public String messaggioDaProporre;

        public void creaUtente() {

                ImplementazionePostgresDAO.connectDAO();
               
               int id = ImplementazionePostgresDAO.nuovoutentedaDB();
               
               ImplementazionePostgresDAO.connectDAO();

               ImplementazionePostgresDAO.confermaNuovoIdUtenteDB(id);

               utente = new Utente(id);

        }

        public  void scartaUtenteInUso()
        {
                utente = null;
        }

        public  boolean accessoAutore(String username, String password)
        {
                if(!Autore.controllaCredenzialiAccesso(username, password))
                        return false;

                ImplementazionePostgresDAO.connectDAO();
                autoreLoggato = ImplementazionePostgresDAO.LogAsSignedAuthor(username,password);
                
                return true;
        }
        

        public  boolean creaAutore(String username, String password, Date dataIscrizione)
        {
                if(Autore.controllaCredenzialiAccesso(username, password))
                        return false;

                
                // 1. si deve aggiustare la funzione che inserisce l'utente al database
                
                //autoreLoggato = impPostegresDAO.AggiunginuovoAutore(autoreLoggato);
                
                return true;
        }
        
        public Autore ottieniAutore()
        {
                return  autoreLoggato;
        }
        public boolean creaPagina(String titolo)
        {
               if(controllaEsistenzaPagina(titolo) == null)
               {
                       paginaTemporanea = new Pagina(titolo, autoreLoggato);
                       ImplementazionePostgresDAO.memorizzaPaginaSulDB(paginaTemporanea);
               }

               return true; // da modificare
        }

        public Pagina controllaEsistenzaPagina(String titolo)
        {
                if(titolo.isBlank())
                        return null;

                Pagina paginaDaRitornare;
                ImplementazionePostgresDAO.ottieniInfoGeneraliPagina(titolo, paginaTemporanea.titolo);

                return paginaDaRitornare;
        }

        public void memorizzaPaginaTemporanea(Pagina paginaDiRiferimento)
        {
                paginaTemporanea = paginaDiRiferimento;
                destinatarioTemporaneo= paginaTemporanea.ottieniAutore();
        }

        public Pagina ottieniPaginaTemporanea(){
                return paginaTemporanea;
        }

        public void svuotaDatiPaginaTemporanea(){

                paginaTemporanea = null;
                destinatarioTemporaneo = null;
        }

        public int ottieniNumeroParagrafiScritti()
        {
                return paginaTemporanea.testo.size();
        }

        public void memorizzaPagina()
        {
                ImplementazionePostgresDAO.memorizzaPaginaSulDB(paginaTemporanea);
                autoreLoggato.creaPagina(paginaTemporanea.titolo);
        }

        public  HashMap<String, HashMap<Integer, ArrayList<Paragrafo>>>  ottieniInfoNotifiche()
        {
              return autoreLoggato.ottieniNotifiche();
        }

        public void implementaParagrafoInUnaNuovaPagina(String contenuto)
        {
                Paragrafo daImplementare = autoreLoggato.creaParagrafo(contenuto ,
                                                                paginaTemporanea.testo.size(),
                                                                paginaTemporanea);

                daImplementare.impostaCollegamento(collegamentoDaImplementare);
                svuotaCollegamentoTemporaneo();

                daImplementare.impostaStato(Stato.Approvato);

                paginaTemporanea.applicaParagrafo(daImplementare);
        }

        public void inviaProposta(String contenutoParagrafo, int posizione,  Azione azione, Collegamento collegamentoParagrafo)
        {

                Paragrafo daInviare = new Paragrafo(contenutoParagrafo, posizione ,  paginaTemporanea, autoreLoggato);
                daInviare.impostaCollegamento(collegamentoParagrafo);

                autoreLoggato.inviaProposta(daInviare,destinatarioTemporaneo, paginaTemporanea.titolo);
        }

        public  void implementaParagrafoInPaginaEsistente(Paragrafo daImplementare, int indiceParagrafo, String pagina)
        {
                autoreLoggato.elaborazioneProposta(daImplementare, indiceParagrafo, pagina);
        }

        public void scartaOgniPropostaDiUnIndice(String paginaDiRiferimento, int indiceDaScartare)
        {
                autoreLoggato.rifiutaTutteLeProposteDiUnIndice(indiceDaScartare, paginaDiRiferimento);
        }

        public  ArrayList<Pagina> ottieniListaStorici()
        {

                return  autoreLoggato.ottieniListaStorici();
        }

        public  HashMap<Integer, ArrayList<Paragrafo>> ottieniStorico( Pagina paginaDiRiferimento)
        {
                // richiedi al database (da fare nel model)
                HashMap<Integer, ArrayList<Paragrafo>> storico  = paginaDiRiferimento.storicoPagina;
                return storico ;
        }

        public  boolean cercaPaginaSulDB(String titoloPagina)
        {
                ArrayList<Paragrafo> testo = new ArrayList<>();
                ArrayList<String>    contenutoParagrafi = new ArrayList<>();
                ArrayList<Time>      orariParagrafi = new ArrayList<>();
                ArrayList<Date>      dataParagrafi = new ArrayList<>();
                String nomeProprietario = null;

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.ottieniInfoGeneraliPagina(titoloPagina, nomeProprietario);

                paginaTemporanea = new Pagina(titoloPagina, null ,nomeProprietario);

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.raccogliTesto(titoloPagina, contenutoParagrafi, orariParagrafi, dataParagrafi);

                for(int i = 0; i < contenutoParagrafi.size(); i++) {

                        Paragrafo temp = new Paragrafo(contenutoParagrafi.get(i), i, paginaTemporanea,  dataParagrafi.get(i), orariParagrafi.get(i));
                        String destinazione = null;

                        ImplementazionePostgresDAO.connectDAO();
                        ImplementazionePostgresDAO.cercaCollegamentisuDB(i, paginaTemporanea.titolo, destinazione);

                        temp.impostaCollegamento(new Collegamento(paginaTemporanea.titolo, destinazione));

                        testo.add(temp);
                }

                paginaTemporanea.testo = testo;

                utente.visitaPagina(paginaTemporanea);

                return paginaTemporanea != null? true : false;
        }

        public  void salvaValutazioneEVisita(int Valutazione){

                utente.recensisciPagina(Valutazione);
        }

        public void impostaCollegamentoTemporaneo(String titoloPaginaDiDestinazione){

                collegamentoDaImplementare = new Collegamento(paginaTemporanea.titolo, titoloPaginaDiDestinazione);
        }

        public Collegamento ottieniCollegamentoTemporaneo(){
                return  collegamentoDaImplementare;
        }

        public void svuotaCollegamentoTemporaneo(){
                collegamentoDaImplementare = null;
        }

        public void scartaPagina() {

                ImplementazionePostgresDAO.rimuoviPaginaScartataDalDB(paginaTemporanea.titolo);
                paginaTemporanea = null;
        }

        public int ottieniPunteggioPagina() {

                ImplementazionePostgresDAO.ottieniPunteggioPagina(paginaTemporanea.titolo);
        }

        public String elaboraCodiceHtml() {

                String stringHTML = "<html>";

                for (Paragrafo par : paginaTemporanea.testo)
                {
                        if (par.ottienicollegamento() != null)
                        {

                                // Se il paragrafo possiede un collegamneto,
                                // allora viene creato un hypertext, il quale
                                //  consente la visualizzazione di un' altra pagina se cliccato.

                                stringHTML += "<a href = \"";
                                stringHTML += par.ottienicollegamento().titoloPaginaDiDestinazione;
                                stringHTML += "\">";
                                stringHTML += par.ottieniContenuto();
                                stringHTML += "</a>";

                        } else {

                                stringHTML += "<p style=\"background-color:White;\">";
                                stringHTML += par.ottieniContenuto();
                                stringHTML += "</p>";

                        }
                }

                stringHTML += "</html>";

                return stringHTML;
        }
}
