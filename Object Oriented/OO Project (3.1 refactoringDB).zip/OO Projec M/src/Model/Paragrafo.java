package Model;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;

public class Paragrafo
{
    private String contenuto;
    private Stato stato = Stato.InAttesa;
    private java.util.Date data_creazione;
    private Time orario_creazione;
    private int posizione;
    private Autore proprietario;
    private String nomeAutore;
    private Pagina paginaDiRiferimento;
    private Collegamento collegamento = null;

    /** utilizzato per la creazione di paragrafi */
    public Paragrafo(String contenuto, int posizione, Pagina pagina, Autore proprietario)
    {

        this.contenuto = contenuto;
        this.proprietario = proprietario;
        this.posizione = posizione;
        paginaDiRiferimento = pagina;

        long current_date=System.currentTimeMillis();
        LocalTime current_Time = LocalTime.now();

        this.orario_creazione = Time.valueOf(current_Time);
        this.data_creazione = new java.sql.Date(current_date);

        proprietario.paragrafiScritti.add(this);
    }

    /** utilizzato per la creazione di paragrafi con dati caricati dal DB*/
    public Paragrafo(String contenuto, int posizione, Pagina pagina, java.util.Date data_creazione, Time orario_creazione)
    {
        this.contenuto = contenuto;
        this.posizione = posizione;
        paginaDiRiferimento = pagina;
        this.orario_creazione = orario_creazione;
        this.data_creazione = data_creazione;
    }

    public void impostaStato(Stato stato){
        this.stato = stato;
    }
    public Collegamento ottienicollegamento(){
        return collegamento;
    }
    public  void impostaCollegamento(Collegamento collegamento){
        this.collegamento = collegamento;
    }
    public String ottieniContenuto(){
        return  contenuto;
    }
    public Pagina ottieniPaginaDiRiferimento(){
        return  paginaDiRiferimento;
    }
    public int ottieniPosizione(){
        return posizione;
    }
    public String ottieniNomeAutore(){ return this.nomeAutore;}

}
