package Model;

import java.util.*;

public class Utente  extends GestioneAnomalia {

    private int id;
    public Pagina paginaAttualmenteVisitata;

    public Utente(int id)
    {
        this.id = id;
    }
    public Autore signUpComeAutore(String username, String password, Date data_corrente, int punteggio)
    {
       if(!determinaAnomalie(new String[]{username,null},0))
           return null;

       if(!determinaAnomalie(new String[]{password,null},0))
           return null;

        if(username.isBlank())
            return null;

        if(password.isBlank())
            return null;

        System.out.println("> Registrazione ultimata con successo");


        return  new Autore(username,password,data_corrente,0);
    }

     public int getIDutente(Utente u){


        return this.id ;

    }


    /*public void visitaPaginaTramiteCollegamento(Collegamento collegamento)
    {
        paginaAttualmenteVisitata = collegamento.paginaDaRaggiungere;
       // collegamento.paginaDaRaggiungere.mostraTesto();
    }*/  // X FEDE ANCORA QUI COLLEGAMENTO USA LE PAGINE

    public void recensisciPagina(int recensione, Pagina daRecensire)
    {
        if(!determinaAnomalie(new Object[]{daRecensire,null},21))
            return;

        if(!determinaAnomalie(new Object[]{paginaAttualmenteVisitata, daRecensire},19))
            return;

        if(!determinaAnomalie(new int[]{recensione,1},17))
            return;

        if(!determinaAnomalie(new int[]{recensione,5},18))
            return;
    }
}
