package Controller;

import Model.*;
import ImplementazioneDAO.*;

import javax.swing.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Controller extends GestioneAnomalia
{
        private static Utente utente;
        private Autore autore;
        private static   Autore autore_loggato;
        private  Autore destinatarioProposta;
        private Pagina paginaDaCreare;
        private Pagina paginaDiDestinazione;
        private Pagina paginaDaVisitare;
        public Collegamento collegamentoDaImplementare;
        public String messaggioDaProporre;

        public Visita visitaPaginaInCorso;

        public static String getPassword(Autore autore){

            return autore.ottieniPassword();
        }

        public void creaUtente() {

                ImplementazionePostgresDAO.connectDAO();
               int id = ImplementazionePostgresDAO.nuovoutentedaDB();
               ImplementazionePostgresDAO.connectDAO();

               ImplementazionePostgresDAO.confirmednuovoutenteDB(id);

               utente = new Utente(id);

        }

       /* public void caricaPagine()
        {
                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.getpaginedaDB();

        }*/

       /* public void caricaAutori()
        {
                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.loadAutorifromDB();

        }*/

        public void eliminaUtente()
        {
                utente = null;
        }
        public boolean controllaCredenzialiAccesso(String username, String password)
        {
                boolean check = true;

                ImplementazionePostgresDAO.connectDAO();
                check = ImplementazionePostgresDAO.confermacredenzialiDB(username,password);

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.LogAsSignedAuthor(username,password);

                System.out.println("check =" +(check));

                return check;
        }

        public static boolean creaAutore(String username, String password, Date data_iscrizione, int punteggio, boolean nuova_iscrizione)
        {

                Autore autore = null;

                if(nuova_iscrizione){

                        autore = utente.signUpComeAutore(username, password,data_iscrizione,punteggio);
                        if(autore != null){
                                ImplementazionePostgresDAO.connectDAO();
                                Controller.autore_loggato = autore;
                                ImplementazionePostgresDAO.AggiunginuovoAutore(username,password,data_iscrizione);
                                System.out.println("Iscrizione avvenuta con successo");
                        }

                }else {

                        autore = utente.signUpComeAutore(username, password,data_iscrizione,punteggio);

                        if(autore != null){

                                Controller.autore_loggato = autore;
                                System.out.println("Accesso avvenuto con successo");
                        }

                }


                return autore == null ? false : true;
        }



        public Autore ottieniAutore()
        {
                return  autore;
        }
        public boolean creaPagina(String titolo)
        {
               if(controllaEsistenzaPagina(titolo) == null)
                        paginaDaCreare = new Pagina(titolo, autore_loggato);

               return true; // da modificare
        }

        public Pagina controllaEsistenzaPagina(String titolo)
        {
                if(titolo.isBlank())
                        return null;

                // controlla su db se esiste una pagina con lo stesso nome (da fare nel model)
                return null;
        }

        public Pagina memorizzaPaginaTemporanea(String titolo)
        {
                Pagina paginaDiDestinazione = new Pagina(titolo,autore_loggato);
                destinatarioProposta = paginaDiDestinazione.proprietario;
                return paginaDiDestinazione;
        }

        public int ottieniNumeroParagrafiScritti()
        {
                return paginaDaCreare.testo.size();
        }

        public void memorizzaPagina()
        {
                // memorizza la pagina sul database (da fare nel model)
                autore_loggato.creaPagina(paginaDaCreare);
        }

        public  HashMap<Pagina, HashMap<Integer, ArrayList<Paragrafo>>>  ottieniInfoNotifiche()
        {
              return autore_loggato.ottieniProposte();
        }

        public void implementaParagrafoInUnaNuovaPagina(String contenuto)
        {
                Paragrafo daImplementare = autore_loggato.creaParagrafo(contenuto ,
                                                                paginaDaCreare.testo.size(),
                                                                Azione.Aggiungere,
                                                                paginaDaCreare);

                daImplementare.impostaCollegamento(collegamentoDaImplementare);
                collegamentoDaImplementare = null;

                daImplementare.impostaStato(Stato.Approvato);

                paginaDaCreare.applicaParagrafo(daImplementare);
        }

        public void inviaProposta(String contenutoParagrafo, int posizione, Pagina destinazione,  Azione azione, Collegamento collegamentoParagrafo)
        {

                Paragrafo daInviare = new Paragrafo(contenutoParagrafo, posizione ,azione,  destinazione, autore_loggato);
                daInviare.impostaCollegamento( collegamentoParagrafo);

                autore_loggato.inviaProposta(daInviare, destinatarioProposta);
        }

        public  void implementaParagrafoInPaginaEsistente(Paragrafo daImplementare)
        {
                autore_loggato.elaborazioneProposta(daImplementare);
        }

        public void scartaOgniProposta(Pagina paginaDiRiferimento, int indiceDaScartare)
        {
                autore_loggato.rifiutaTutteLeProposte(indiceDaScartare, paginaDiRiferimento);
        }

     /*   public  ArrayList<Pagina> ottieniListaStorici()
        {
                return  autore_loggato.storiciAccessibili;
        }*/

        public  HashMap<Integer, ArrayList<Paragrafo>> ottieniStorico( Pagina paginaDiRiferimento)
        {
                // richiedi al database (da fare nel model)
                HashMap<Integer, ArrayList<Paragrafo>> storico  = paginaDiRiferimento.storicoPagina;
                return storico ;
        }

        public static Pagina cercaPaginasulDB(String titoloPagina)
        {

                Pagina paginaDaVisitare;

                ImplementazionePostgresDAO.connectDAO();
                paginaDaVisitare = ImplementazionePostgresDAO.ottieniPagina(titoloPagina);

                ImplementazionePostgresDAO.connectDAO();
                paginaDaVisitare.testo=ImplementazionePostgresDAO.raccogliTesto(titoloPagina,paginaDaVisitare);

                return paginaDaVisitare;
        }

        public static void cercaCollegamenti(Paragrafo par, Pagina paginaDiRiferifemento)
        {
                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.cercaCollegamentisuDB(par,paginaDiRiferifemento);
        }

        public static Pagina Linking(Collegamento collegamento){

                Pagina Linkata = null;

                ImplementazionePostgresDAO.connectDAO();
                Linkata = ImplementazionePostgresDAO.ottieniPagina(collegamento.titolo_diDestinazione);

                return Linkata;

        }

        public static void SalvaValutazioneAndVisita(int Valutazione, Pagina paginaVisitata)
        {

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.MandaValutazioneAndVisita( Valutazione, paginaVisitata.titolo,Controller.getIdutente(utente));
        }

        public static int getIdutente(Utente utente){

                return utente.getIDutente(utente);


        }

       /* public void creaCollegamento(Pagina paginaDiPartenza, String titoloPaginaDestinazione)
        {
                Pagina risultato = controllaEsistenzaPagina(titoloPaginaDestinazione);

                risultato = autore.pagScritte.get(0); // da eliminare !!

                if(risultato != null)
                        collegamentoDaImplementare = new Collegamento(paginaDiPartenza, risultato);
                else
                        collegamentoDaImplementare = null;
        }*/ // x FEDE anche qui bisogna sistemare a causa di Collegamento


        public Paragrafo ottieniParagrafoTramiteContenuto(ArrayList<Paragrafo> lista, String contenuto)
        {
                if(lista.isEmpty())
                        return null;

                for(Paragrafo par : lista)
                {
                        if(par.ottieniContenuto().contentEquals(contenuto))
                                return par;
                }

                return null;
        }
}
