package Model;

public class Collegamento extends GestioneAnomalia
{
    public String titoloPaginaDiArrivo;
    public String titoloPaginaDiDestinazione;

    public Collegamento(String titoloPaginaDiArrivo, String titoloPaginaDiDestinazione)
    {
        this.titoloPaginaDiArrivo = titoloPaginaDiArrivo;
        this.titoloPaginaDiDestinazione = titoloPaginaDiDestinazione;
    }
}
