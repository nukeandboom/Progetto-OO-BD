package Model;

import ImplementazioneDAO.ImplementazionePostgresDAO;
import com.sun.source.tree.Tree;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.logging.Logger;

public class Autore extends GestioneAnomalia
{
    public final String username;
    private final Date dataIscrizione;
    private final String password;
    public int punteggio = 0;
    public ArrayList<Pagina> pagScritte = new ArrayList<>();
    public ArrayList<Paragrafo> paragrafiScritti = new ArrayList<>();
   // private ArrayList<Pagina> storiciAccessibili = new ArrayList<>();
    private HashMap<Pagina,HashMap<Integer,ArrayList<Paragrafo>>> proposteInAttesa  = new HashMap<>();

    public Autore(String username, String password, Date dataIscrizione, int punteggio)
    {
        this.username = username;
        this.password = password;
        this.dataIscrizione = dataIscrizione;
        this.punteggio = punteggio;
    }

    public static boolean controllaCredenzialiAccesso(String username, String password)
    {
        if(!determinaAnomalie(new String[]{username,null},0))
            return false;

        if(!determinaAnomalie(new String[]{password,null},0))
            return false;

        if(username.isBlank())
            return false;

        if(password.isBlank())
            return false;

        ImplementazionePostgresDAO.connectDAO();

        return ImplementazionePostgresDAO.confermacredenzialiDB(username,password);
    }

    public void creaPagina(Pagina paginaDiRiferimento)
    {
        pagScritte.add(paginaDiRiferimento);
       // storiciAccessibili.add(paginaDiRiferimento);
    }

    public Paragrafo creaParagrafo(String contenutoParagrafo, int posizione, Azione azione, Pagina paginaDiDestinazione)
    {
        return  new Paragrafo(contenutoParagrafo,
                posizione,
                azione,
                paginaDiDestinazione,
                this);
    }

    public void inviaProposta(Paragrafo daRevisionare, Autore destinatario)
    {
        if(destinatario != this)
            destinatario.riceviNotifica(daRevisionare);
        else
        {
            daRevisionare.impostaStato(Stato.Approvato);
            daRevisionare.ottieniPaginaDiRiferimento().applicaParagrafo(daRevisionare);
        }
    }

    public  void riceviNotifica(Paragrafo daNotificare)
    {
        ArrayList<Paragrafo> listaTemporanea = new ArrayList<>();
        HashMap<Integer,ArrayList<Paragrafo>> hashMapTemporanea = new HashMap<>();
        var nomeTemporaneo = proposteInAttesa.get(daNotificare.ottieniPaginaDiRiferimento());

        if(proposteInAttesa.containsKey(daNotificare.ottieniPaginaDiRiferimento()))
            if(nomeTemporaneo.containsKey(daNotificare.ottieniPosizione()))
            {
                nomeTemporaneo.get(daNotificare.ottieniPosizione()).add(daNotificare);
            }
            else
            {
                listaTemporanea.add(daNotificare);
                nomeTemporaneo.put(daNotificare.ottieniPosizione(),listaTemporanea);
            }
        else
        {
            listaTemporanea.add(daNotificare);
            hashMapTemporanea.put(daNotificare.ottieniPosizione(), listaTemporanea);

            proposteInAttesa.put(daNotificare.ottieniPaginaDiRiferimento(), hashMapTemporanea);
        }
    }

    /** Visualizza le pagine interessate dalle proposte ricevute. */
    public void mostraPagineSoggetteAProposta()
    {
        System.out.println("> Sono disponibili modifiche alle seguenti pagine: ");

        for( var pag: proposteInAttesa.keySet())
        {
            System.out.println(pag.titolo);
        }

    }

    public HashMap<Pagina,HashMap<Integer,ArrayList<Paragrafo>>>  ottieniProposte()
    {
        // ottiene dal database la lista delle proposte inerenti a questo autore

        ArrayList<Paragrafo> listaProposte = new ArrayList<>();


        listaProposte.add(new Paragrafo("ciao", 0, Azione.Aggiungere, pagScritte.get(0), this)); // da eliminare
        listaProposte.add(new Paragrafo("cola", 0, Azione.Aggiungere, pagScritte.get(1), this));// da eliminare
        listaProposte.add(new Paragrafo(null, 0,    Azione.Svuotare, pagScritte.get(1), this));// da eliminare
        listaProposte.add(new Paragrafo("birra", 0, Azione.Aggiornare, pagScritte.get(0), this));// da eliminare
        listaProposte.add(new Paragrafo("alcol", 1, Azione.Aggiungere,pagScritte.get(0), this));// da eliminare

        for(Paragrafo par : listaProposte)
        {
            if(!proposteInAttesa.containsKey(par.ottieniPaginaDiRiferimento()))
                proposteInAttesa.put(par.ottieniPaginaDiRiferimento(), new HashMap<>());
        }

        for(Paragrafo par : listaProposte)
        {
            if(!proposteInAttesa.get(par.ottieniPaginaDiRiferimento()).containsKey(par.ottieniPosizione()))
                proposteInAttesa.get(par.ottieniPaginaDiRiferimento()).put(par.ottieniPosizione(), new ArrayList<>());
        }

        for(Pagina pag : proposteInAttesa.keySet())
        {
            for(int pos : proposteInAttesa.get(pag).keySet())
            {
                for(Paragrafo par : listaProposte)
                {
                    if(par.ottieniPaginaDiRiferimento() == pag && par.ottieniPosizione() == pos)
                        proposteInAttesa.get(pag).get(pos).add(par);
                }
            }
        }

        return proposteInAttesa;
    }

    public Pagina ottieniPagina(String titolo)
    {
        if(!determinaAnomalie(new Object[]{titolo, null},12))
            return null;

        for (var pag : proposteInAttesa.keySet())
        {
            if(pag.titolo.contentEquals(titolo))
                return pag;
        }

        inviaAnomalia(22);
        return  null;
    }

    /** Visualizza i paragrafi, della pagina in esame, che sono indicati nelle notifiche. */
    public void mostraIndiciParagrafiSoggettiAProposte(Pagina paginaSelezionata)
    {
        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            inviaAnomalia(14);
            return;
        }

        System.out.println("> Indici paragrafi soggetti a proposte: ");

        for ( var key : proposteInAttesa.get(paginaSelezionata).keySet())
        {
            System.out.println("Indice [" + key.intValue() + "]");

            for(int i = 0; i < proposteInAttesa.get(paginaSelezionata).get(key).size(); i++)
            {
                System.out.print("  " + i + ")  [");
                System.out.print((proposteInAttesa.get(paginaSelezionata).get(key).get(i).ottieniAzione()));
                System.out.print("] ");
                System.out.println(proposteInAttesa.get(paginaSelezionata).get(key).get(i).ottieniContenuto());
            }
        }
    }

    public Paragrafo ottieniParagrafo(int indiceProposta, int indiceParagrafo, Pagina paginaSelezionata)
    {
        if(!proposteInAttesa.containsKey(paginaSelezionata))
        {
            inviaAnomalia(14);
            return null;
        }

        if(!proposteInAttesa.get(paginaSelezionata).containsKey(indiceParagrafo))
        {
            inviaAnomalia(15);
            return null;
        }

        if(!determinaAnomalie(new int[]{indiceProposta,0},20))
            return null;

        if(!determinaAnomalie(new int[]{indiceProposta, proposteInAttesa.get(paginaSelezionata).size()},15))
            return null;

        return  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo).get(indiceProposta);
    }

    public void elaborazioneProposta(Paragrafo propostaSelezionata)
    {
        // dire al database che il paragrado è stato accettato
        propostaSelezionata.impostaStato(Stato.Approvato);
        propostaSelezionata.ottieniPaginaDiRiferimento().applicaParagrafo(propostaSelezionata);

       // var storiciVistiDalMittente  = propostaSelezionata.ottieniProprietario().storiciAccessibili;

       // if(!storiciVistiDalMittente.contains(propostaSelezionata.ottieniPaginaDiRiferimento()))
       //     storiciVistiDalMittente.add(propostaSelezionata.ottieniPaginaDiRiferimento());

        var indiceParagrafo = proposteInAttesa.get(propostaSelezionata.ottieniPaginaDiRiferimento()).get(propostaSelezionata.ottieniPosizione());

        indiceParagrafo.remove(propostaSelezionata);

        while (!indiceParagrafo.isEmpty())
        {
            // dire al database che sono stati rifiutati
            indiceParagrafo.getFirst().impostaStato(Stato.Rifiutato);
            indiceParagrafo.remove(indiceParagrafo.getFirst());
        }

        proposteInAttesa.get(propostaSelezionata.ottieniPaginaDiRiferimento()).remove(propostaSelezionata.ottieniPosizione());
    }

    public void rifiutaTutteLeProposte(int indiceParagrafo, Pagina paginaSelezionata)
    {
        var listaProposte =  proposteInAttesa.get(paginaSelezionata).get(indiceParagrafo);

        do
        {   // informare il db
            listaProposte.get(0).impostaStato(Stato.Rifiutato);
            listaProposte.remove(0);
        }while (listaProposte.isEmpty());

        proposteInAttesa.get(paginaSelezionata).remove(indiceParagrafo);
    }

    public ArrayList<Pagina> ottieniListaStorici()
    {
        return ImplementazionePostgresDAO.ottieniStoricoAutore(this);
    }

    /*
    public void mostraStoriciAccessibili()
    {
        System.out.println("> lista storici accessibili: ");

        for( int i = 0; i < storiciAccessibili.size(); i++)
        {
            System.out.print(i);
            System.out.print(") ");
            System.out.print(storiciAccessibili.get(i).titolo);

            if(storiciAccessibili.get(i).ottieniAutore() == this)
                System.out.println(" [Proprietario]");

            System.out.println();
        }
    }

    public Pagina ottienePaginaDaListaStorici(String titoloPagina)
    {
        for(var pag : storiciAccessibili)
        {
            if(pag.titolo.contentEquals(titoloPagina))
                return pag;
        }

        inviaAnomalia(15);
        return null;
    }

    public void mostraStorico(Pagina paginaDiRiferimento, int indiceParagrafo)
    {
        if(!storiciAccessibili.contains(paginaDiRiferimento))
        {
            inviaAnomalia(25);
            return;
        }

        var storicoInEsame = paginaDiRiferimento.storicoPagina;

        if(!storicoInEsame.containsKey(indiceParagrafo))
        {
            inviaAnomalia(15);
            return;
        }

        System.out.println("> info storico -> paragrafo " + indiceParagrafo + ":");

        for( Paragrafo par :  storicoInEsame.get(indiceParagrafo))
        {
            System.out.println(par.ottieniContenuto());
        }
    }


     */
}