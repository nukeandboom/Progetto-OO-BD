package Controller;

import Model.*;

import java.util.ArrayList;

public class Controller extends GestioneAnomalia
{
        private Utente utente;
        private Autore autore;
        private ArrayList<Paragrafo> bozzeParagrafi = new ArrayList<>();

        public void creaUtente()
        {
                int id = 0; // richiedi al database un id
                utente = new Utente(id);
        }

        public void eliminaUtente()
        {
                utente = null;
        }
        public boolean controllaCredenzialiAccesso(String username, String password)
        {
                boolean check = true;

                // ricerca esistenza username

                // se non è presente nessun username uguale a quello indicato
                if(!check)
                        inviaAnomalia(26);

                if(!determinaAnomalie(new String[]{password, autore.ottieniPassword()}, 3))
                        return false;

                return true;
        }

        public boolean creaAutore(String username, String password)
        {
                autore = utente.signUpComeAutore(username, password);

                if(autore == null)
                        return false;
                else
                        return true;
        }

        public void aggiungiParagrafo(Paragrafo paragrafo)
        {
                bozzeParagrafi.add(paragrafo);
        }

        public void creaPagina(String titolo)
        {
                autore.creaPagina(titolo);

                for (Paragrafo par : bozzeParagrafi)
                {
                        autore.inviaProposta(par, autore);
                }

                bozzeParagrafi.clear();
        }
}
