package Model;

import java.util.ArrayList;

public class Utente  extends GestioneAnomalia {
    protected int id;
    private boolean ConnectedAsUser;
    public ArrayList<Visita> cronologia = new ArrayList<>();
    public Pagina paginaAttualmenteVisitata;
    public Autore child;
    public Utente(int id)
    {
        this.id = id;
        ConnectedAsUser = false;
    }
    public Autore signUpComeAutore(String username, String password)
    {
       if(!determinaAnomalie(ConnectedAsUser,true,0))
           return null;

       if(!determinaAnomalie(new String[]{username,null},1))
           return null;

       if(!determinaAnomalie(new String[]{password,null},1))
           return null;

        if(username.isBlank())
            return null;

        if(password.isBlank())
            return null;

        System.out.println("> Registrazione ultimata con successo");
        return  new Autore(username,password);
    }

    public void visitaPaginaTramiteCollegamento(Collegamento collegamento)
    {
        if(!determinaAnomalie(ConnectedAsUser,true,0))
            return;

        cronologia.add(new Visita(this,collegamento.paginaDaRaggiungere));
        paginaAttualmenteVisitata = collegamento.paginaDaRaggiungere;
        collegamento.paginaDaRaggiungere.mostraTesto();
    }

    public void recensisciPagina(int recensione, Pagina daRecensire)
    {
        if(!determinaAnomalie(ConnectedAsUser,true,0))
            return;

        if(!determinaAnomalie(new Object[]{daRecensire,null},21))
            return;

        if(!determinaAnomalie(new Object[]{paginaAttualmenteVisitata, daRecensire},19))
            return;

        if(!determinaAnomalie(new int[]{recensione,1},17))
            return;

        if(!determinaAnomalie(new int[]{recensione,5},18))
            return;

        cronologia.getLast().recensione += recensione;
    }


    public void logIn()
    {
        ConnectedAsUser = true;
        System.out.println("> Accesso effettuato : <Model.Utente>");
    }

    public void logOut()
    {
        ConnectedAsUser = false;

        if(child.connessoComeAutore)
            child.logOut();

        System.out.println("> Model.Utente disconnesso!");
    }
}
