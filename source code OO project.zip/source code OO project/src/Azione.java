public enum Azione
{
    Add,
    Remove,
    Update,
    None
}
