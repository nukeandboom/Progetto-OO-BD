package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

public class SchermataStorici extends FunzioniDiSupportoGUI {

    private JFrame frameCorrente;
    private JPanel pannelloPrincipale;
    private JTextArea mostraStoricoTxArea;
    private JComboBox selezionaStoricoCbBox;
    private JButton indietroBtn;
    private JLabel titoloPaginaLabel;
    private JLabel comboBoxLabel;
    private JLabel IndiceParagrafoLabel;
    private JLabel posizioneLabel;
    private JComboBox indiceParagrafoComboBox;
    private JLabel indiceVoceStoricoLabel;
    private JComboBox indiceVoceStoricoComboBox;

    private int check1 = 0;
    private int check2 = 0;
    private int check3 = 0;


    public SchermataStorici(Controller controller, JFrame frameDiRitorno) {

        frameCorrente = inizializzaNuovaFinestra("SchermataStorici", pannelloPrincipale);

        // I trattini simboleggiano lo stato di default delle comboBox.
        indiceParagrafoComboBox.addItem("---");
        indiceVoceStoricoComboBox.addItem("---");
        selezionaStoricoCbBox.addItem("---");

        HashMap<String, HashMap<Integer, ArrayList<String>>> hashMapStoriciAccessibili = controller.ottieniListaStorici();
        ArrayList<String> listaPagine = controller.ottieniListaPagineStorico();

        for (String str : listaPagine) {
            selezionaStoricoCbBox.addItem(str);
        }

        indietroBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chiudiFinestra(frameDiRitorno, frameCorrente);
            }
        });

        selezionaStoricoCbBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {

                if (evento.getStateChange() == ItemEvent.DESELECTED) {

                    indiceParagrafoComboBox.removeAllItems();
                    indiceParagrafoComboBox.addItem("---");

                    indiceVoceStoricoComboBox.removeAllItems();
                    indiceVoceStoricoComboBox.addItem("---");
                }

                if (evento.getStateChange() == ItemEvent.SELECTED) {

                    if (selezionaStoricoCbBox.getSelectedIndex() != check1) {

                        check1 = selezionaStoricoCbBox.getSelectedIndex();

                        if (selezionaStoricoCbBox.getSelectedIndex() != 0) {


                            String chiave = listaPagine.get(selezionaStoricoCbBox.getSelectedIndex() - 1);


                            for (int index = 0; index < hashMapStoriciAccessibili.get(chiave).size(); index++) {
                                indiceParagrafoComboBox.addItem(String.valueOf(index));

                            }
                        }
                    }
                }
            }
        });

        indiceParagrafoComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {

                if (evento.getStateChange() == ItemEvent.DESELECTED) {

                    indiceVoceStoricoComboBox.removeAllItems();
                    indiceVoceStoricoComboBox.addItem("---");
                }

                if (evento.getStateChange() == ItemEvent.SELECTED) {

                    if (indiceParagrafoComboBox.getSelectedIndex() != check2) {

                        check2 = selezionaStoricoCbBox.getSelectedIndex();

                        if (indiceParagrafoComboBox.getSelectedIndex() != 0) {


                            String chiave = listaPagine.get(selezionaStoricoCbBox.getSelectedIndex() - 1);
                            int indiceParagrafo = indiceParagrafoComboBox.getSelectedIndex() - 1;


                            for (int i = 1; i <= hashMapStoriciAccessibili.get(chiave).get(indiceParagrafo).size(); i++) {
                                indiceVoceStoricoComboBox.addItem(String.valueOf(i));
                            }
                        }
                    }
                }
            }
        });

        indiceVoceStoricoComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent evento) {


                if (evento.getStateChange() == ItemEvent.SELECTED) {

                    if (indiceVoceStoricoComboBox.getSelectedIndex() != check3) {

                        check3 = indiceVoceStoricoComboBox.getSelectedIndex();

                        if (indiceVoceStoricoComboBox.getSelectedIndex() != 0) {


                            String chiave = listaPagine.get(selezionaStoricoCbBox.getSelectedIndex() - 1);
                            int indiceParagrafo = Integer.parseInt((String) indiceParagrafoComboBox.getItemAt(indiceParagrafoComboBox.getSelectedIndex()));
                            int indiceVoce = indiceVoceStoricoComboBox.getSelectedIndex() - 1;

                            String voceStorico = hashMapStoriciAccessibili.get(chiave).get(indiceParagrafo).get(indiceVoce);

                            mostraStoricoTxArea.setText(voceStorico);
                        }
                    }
                }
            }
        });
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        pannelloPrincipale = new JPanel();
        pannelloPrincipale.setLayout(new GridBagLayout());
        pannelloPrincipale.setBackground(new Color(-14342875));
        pannelloPrincipale.setPreferredSize(new Dimension(1200, 720));
        mostraStoricoTxArea = new JTextArea();
        mostraStoricoTxArea.setBackground(new Color(-13158601));
        Font mostraStoricoTxAreaFont = this.$$$getFont$$$("Fira Code", Font.BOLD, 16, mostraStoricoTxArea.getFont());
        if (mostraStoricoTxAreaFont != null) mostraStoricoTxArea.setFont(mostraStoricoTxAreaFont);
        mostraStoricoTxArea.setForeground(new Color(-331531));
        mostraStoricoTxArea.setLineWrap(true);
        mostraStoricoTxArea.setOpaque(true);
        mostraStoricoTxArea.setPreferredSize(new Dimension(400, 400));
        mostraStoricoTxArea.setText("");
        mostraStoricoTxArea.setWrapStyleWord(true);
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridheight = 5;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(20, 0, 0, 0);
        pannelloPrincipale.add(mostraStoricoTxArea, gbc);
        indietroBtn = new JButton();
        indietroBtn.setAlignmentX(0.5f);
        indietroBtn.setAutoscrolls(false);
        indietroBtn.setBorderPainted(true);
        indietroBtn.setContentAreaFilled(false);
        indietroBtn.setFocusPainted(false);
        Font indietroBtnFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, indietroBtn.getFont());
        if (indietroBtnFont != null) indietroBtn.setFont(indietroBtnFont);
        indietroBtn.setForeground(new Color(-331531));
        indietroBtn.setMaximumSize(new Dimension(250, 50));
        indietroBtn.setPreferredSize(new Dimension(250, 50));
        this.$$$loadButtonText$$$(indietroBtn, this.$$$getMessageFromBundle$$$("GUI/it_IT", "indietro"));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.ipadx = 50;
        gbc.insets = new Insets(100, 0, 0, 50);
        pannelloPrincipale.add(indietroBtn, gbc);
        titoloPaginaLabel = new JLabel();
        Font titoloPaginaLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, titoloPaginaLabel.getFont());
        if (titoloPaginaLabelFont != null) titoloPaginaLabel.setFont(titoloPaginaLabelFont);
        titoloPaginaLabel.setForeground(new Color(-331531));
        titoloPaginaLabel.setHorizontalAlignment(2);
        titoloPaginaLabel.setHorizontalTextPosition(10);
        titoloPaginaLabel.setPreferredSize(new Dimension(300, 27));
        titoloPaginaLabel.setText("Storico della pagina :");
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        pannelloPrincipale.add(titoloPaginaLabel, gbc);
        selezionaStoricoCbBox = new JComboBox();
        selezionaStoricoCbBox.setBackground(new Color(-14342875));
        Font selezionaStoricoCbBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, selezionaStoricoCbBox.getFont());
        if (selezionaStoricoCbBoxFont != null) selezionaStoricoCbBox.setFont(selezionaStoricoCbBoxFont);
        selezionaStoricoCbBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        selezionaStoricoCbBox.setModel(defaultComboBoxModel1);
        selezionaStoricoCbBox.setOpaque(true);
        selezionaStoricoCbBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(20, 0, 0, 200);
        pannelloPrincipale.add(selezionaStoricoCbBox, gbc);
        indiceParagrafoComboBox = new JComboBox();
        indiceParagrafoComboBox.setBackground(new Color(-14342875));
        Font indiceParagrafoComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceParagrafoComboBox.getFont());
        if (indiceParagrafoComboBoxFont != null) indiceParagrafoComboBox.setFont(indiceParagrafoComboBoxFont);
        indiceParagrafoComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel2 = new DefaultComboBoxModel();
        indiceParagrafoComboBox.setModel(defaultComboBoxModel2);
        indiceParagrafoComboBox.setOpaque(true);
        indiceParagrafoComboBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(20, 0, 0, 200);
        pannelloPrincipale.add(indiceParagrafoComboBox, gbc);
        IndiceParagrafoLabel = new JLabel();
        Font IndiceParagrafoLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, IndiceParagrafoLabel.getFont());
        if (IndiceParagrafoLabelFont != null) IndiceParagrafoLabel.setFont(IndiceParagrafoLabelFont);
        IndiceParagrafoLabel.setForeground(new Color(-331531));
        IndiceParagrafoLabel.setHorizontalAlignment(2);
        IndiceParagrafoLabel.setHorizontalTextPosition(10);
        IndiceParagrafoLabel.setPreferredSize(new Dimension(300, 27));
        this.$$$loadLabelText$$$(IndiceParagrafoLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "seleziona.indice.paragrafo"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(100, 0, 0, 0);
        pannelloPrincipale.add(IndiceParagrafoLabel, gbc);
        posizioneLabel = new JLabel();
        Font posizioneLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, posizioneLabel.getFont());
        if (posizioneLabelFont != null) posizioneLabel.setFont(posizioneLabelFont);
        posizioneLabel.setForeground(new Color(-331531));
        posizioneLabel.setHorizontalAlignment(2);
        posizioneLabel.setHorizontalTextPosition(10);
        posizioneLabel.setPreferredSize(new Dimension(300, 27));
        posizioneLabel.setText("In posizione :");
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        pannelloPrincipale.add(posizioneLabel, gbc);
        comboBoxLabel = new JLabel();
        Font comboBoxLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, comboBoxLabel.getFont());
        if (comboBoxLabelFont != null) comboBoxLabel.setFont(comboBoxLabelFont);
        comboBoxLabel.setForeground(new Color(-331531));
        comboBoxLabel.setHorizontalAlignment(2);
        comboBoxLabel.setHorizontalTextPosition(10);
        comboBoxLabel.setPreferredSize(new Dimension(300, 27));
        this.$$$loadLabelText$$$(comboBoxLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "seleziona.storico"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        pannelloPrincipale.add(comboBoxLabel, gbc);
        indiceVoceStoricoLabel = new JLabel();
        Font indiceVoceStoricoLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceVoceStoricoLabel.getFont());
        if (indiceVoceStoricoLabelFont != null) indiceVoceStoricoLabel.setFont(indiceVoceStoricoLabelFont);
        indiceVoceStoricoLabel.setForeground(new Color(-331531));
        indiceVoceStoricoLabel.setHorizontalAlignment(2);
        indiceVoceStoricoLabel.setHorizontalTextPosition(10);
        indiceVoceStoricoLabel.setPreferredSize(new Dimension(300, 27));
        this.$$$loadLabelText$$$(indiceVoceStoricoLabel, this.$$$getMessageFromBundle$$$("GUI/it_IT", "seleziona.paragrafo"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(100, 0, 0, 0);
        pannelloPrincipale.add(indiceVoceStoricoLabel, gbc);
        indiceVoceStoricoComboBox = new JComboBox();
        indiceVoceStoricoComboBox.setBackground(new Color(-14342875));
        Font indiceVoceStoricoComboBoxFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 20, indiceVoceStoricoComboBox.getFont());
        if (indiceVoceStoricoComboBoxFont != null) indiceVoceStoricoComboBox.setFont(indiceVoceStoricoComboBoxFont);
        indiceVoceStoricoComboBox.setForeground(new Color(-331531));
        final DefaultComboBoxModel defaultComboBoxModel3 = new DefaultComboBoxModel();
        indiceVoceStoricoComboBox.setModel(defaultComboBoxModel3);
        indiceVoceStoricoComboBox.setOpaque(true);
        indiceVoceStoricoComboBox.setPreferredSize(new Dimension(250, 50));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(20, 0, 0, 200);
        pannelloPrincipale.add(indiceVoceStoricoComboBox, gbc);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    private static Method $$$cachedGetBundleMethod$$$ = null;

    private String $$$getMessageFromBundle$$$(String path, String key) {
        ResourceBundle bundle;
        try {
            Class<?> thisClass = this.getClass();
            if ($$$cachedGetBundleMethod$$$ == null) {
                Class<?> dynamicBundleClass = thisClass.getClassLoader().loadClass("com.intellij.DynamicBundle");
                $$$cachedGetBundleMethod$$$ = dynamicBundleClass.getMethod("getBundle", String.class, Class.class);
            }
            bundle = (ResourceBundle) $$$cachedGetBundleMethod$$$.invoke(null, path, thisClass);
        } catch (Exception e) {
            bundle = ResourceBundle.getBundle(path);
        }
        return bundle.getString(key);
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadLabelText$$$(JLabel component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setDisplayedMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    private void $$$loadButtonText$$$(AbstractButton component, String text) {
        StringBuffer result = new StringBuffer();
        boolean haveMnemonic = false;
        char mnemonic = '\0';
        int mnemonicIndex = -1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '&') {
                i++;
                if (i == text.length()) break;
                if (!haveMnemonic && text.charAt(i) != '&') {
                    haveMnemonic = true;
                    mnemonic = text.charAt(i);
                    mnemonicIndex = result.length();
                }
            }
            result.append(text.charAt(i));
        }
        component.setText(result.toString());
        if (haveMnemonic) {
            component.setMnemonic(mnemonic);
            component.setDisplayedMnemonicIndex(mnemonicIndex);
        }
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return pannelloPrincipale;
    }

}
