package Controller;

import Model.*;
import ImplementazioneDAO.*;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Controller extends GestioneAnomalia
{
        private static Utente utente;
        private  Autore autoreLoggato;
        private Autore destinatarioTemporaneo;
        private Pagina paginaTemporanea;
        private Collegamento collegamentoDaImplementare;
        private String messaggioTemporaneo;

        public void creaUtente()
        {
               ImplementazionePostgresDAO.connectDAO();
               int id = ImplementazionePostgresDAO.nuovoutentedaDB();
               
               ImplementazionePostgresDAO.connectDAO();
               ImplementazionePostgresDAO.confermaNuovoIdUtenteDB(id);

               utente = new Utente(id);
        }

        public  void scartaUtenteInUso()
        {
                utente = null;
        }

        public  boolean accessoAutore(String username, String password)
        {
                ImplementazionePostgresDAO.connectDAO();
                boolean check = ImplementazionePostgresDAO.confermacredenzialiDB(username,password);

                if(!check)
                        return false;

                int punteggio = 0;
                Date dataRegistrazione = null;

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.ottieniInfoAutoreEsistente(username, password, dataRegistrazione, punteggio);

                autoreLoggato = new Autore(username, password, dataRegistrazione, punteggio);

                return check;
        }

        public  boolean creaAutore(String username, String password)
        {
                if(!determinaAnomalie(new String[]{username,null},0))
                        return false;

                if(!determinaAnomalie(new String[]{password,null},0))
                        return false;

                if(username.isBlank())
                        return false;

                if(password.isBlank())
                        return false;

                Date dataAttuale = new Date(System.currentTimeMillis());

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.caricaNuovoAutoreSulDB(username, password,dataAttuale );

                autoreLoggato = new Autore(username, password, dataAttuale, 0);

                return true;
        }

        public void svuotaDatiPaginaTemporanea(){

                paginaTemporanea = null;
                destinatarioTemporaneo = null;
        }

        public  HashMap<String, HashMap<Integer, ArrayList<String[]>>>  ottieniInfoNotifiche()
        {
                ArrayList<String> titoliPagine =  ImplementazionePostgresDAO.ottieniListaNomiPagineSoggetteAProposte();

                HashMap<String,HashMap<Integer,ArrayList<String[]>>> hashMapNotifiche = new HashMap<>();
                HashMap<Integer,ArrayList<String[]>> hashMapIndiciParagrafi;

                for(String str : titoliPagine)
                {
                        hashMapIndiciParagrafi = ImplementazionePostgresDAO.ottieniHashMapIndiceParagrafiInAttesa(str);
                        hashMapNotifiche.put(str, hashMapIndiciParagrafi);
                }

                return hashMapNotifiche;
        }

        public void implementaParagrafoInUnaNuovaPagina(String contenuto)
        {
                ImplementazionePostgresDAO.caricaParagrafoSulDB(contenuto,
                        collegamentoDaImplementare.titoloPaginaDiDestinazione,
                        collegamentoDaImplementare.titoloPaginaCorrente,
                        paginaTemporanea.testo.size(),
                        paginaTemporanea.titolo,
                        autoreLoggato.username);

                svuotaCollegamentoTemporaneo();
                impostaMessaggioTemporaneo(null);
        }

        public void inviaProposta(String contenutoParagrafo, int posizione)
        {
                ImplementazionePostgresDAO.caricaPropostaNelDB( contenutoParagrafo,
                                                                collegamentoDaImplementare.titoloPaginaCorrente,
                                                                collegamentoDaImplementare.titoloPaginaDiDestinazione,
                                                                posizione,
                                                                paginaTemporanea.titolo,
                                                                paginaTemporanea.nomeAutore);
        }

        public  void implementaParagrafoInPaginaEsistente(String[] infoParagrafo , int indiceParagrafo, String pagina)
        {
                ImplementazionePostgresDAO.aumentaPunteggioAutore(infoParagrafo[1]);
                ImplementazionePostgresDAO.caricaParagrafoSulDB(infoParagrafo[0],infoParagrafo[2], infoParagrafo[3], indiceParagrafo, pagina, infoParagrafo[1]);
        }

        public void scartaOgniPropostaDiUnIndice(String paginaDiRiferimento, int indiceDaScartare)
        {
                ImplementazionePostgresDAO.eliminaProposteInerentiAdUnParagrafo(paginaDiRiferimento, indiceDaScartare);
        }

        public  HashMap<Integer, ArrayList<Paragrafo>> ottieniStorico( Pagina paginaDiRiferimento)
        {
                // richiedi al database (da fare nel model)
                HashMap<Integer, ArrayList<Paragrafo>> storico  = paginaDiRiferimento.storicoPagina;
                return storico ;
        }

        public void memorizzaPaginaTemporaneaSulDB()
        {
                ImplementazionePostgresDAO.memorizzaPaginaSulDB(paginaTemporanea);
        }

        public void caricaDatiSuPaginaTemporanea(String titoloPaginaDiRiferimento, String proprietario)
        {
                paginaTemporanea = new Pagina(titoloPaginaDiRiferimento,proprietario);
                destinatarioTemporaneo = paginaTemporanea.ottieniAutore();
        }

        public  boolean controllaEsistenzaPaginaSulDB(String titoloPagina)
        {
                if(titoloPagina == null)
                        return false;

                if(titoloPagina.isBlank())
                        return false;

                ImplementazionePostgresDAO.connectDAO();
                boolean check =  ImplementazionePostgresDAO.ottieniInfoGeneraliPagina(titoloPagina, new String());

                return check;
        }

        public boolean ottieniPaginaDalDB(String titoloPagina)
        {
                if(titoloPagina == null)
                        return false;

                if(titoloPagina.isBlank())
                        return false;

                String nomeProprietario = null;

                ImplementazionePostgresDAO.connectDAO();
                boolean check =  ImplementazionePostgresDAO.ottieniInfoGeneraliPagina(titoloPagina, nomeProprietario);

                if(!check)
                        return false;

                ottieniTestoDiunaPagina(titoloPagina);
                caricaDatiSuPaginaTemporanea(titoloPagina, nomeProprietario);

                return check;
        }

        public void ottieniTestoDiunaPagina(String titoloPagina)
        {
                ArrayList<Paragrafo> testo = new ArrayList<>();
                ArrayList<String>    contenutoParagrafi = new ArrayList<>();
                ArrayList<Time>      orariParagrafi = new ArrayList<>();
                ArrayList<Date>      dataParagrafi = new ArrayList<>();

                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.raccogliTesto(titoloPagina, contenutoParagrafi, orariParagrafi, dataParagrafi);

                for(int i = 0; i < contenutoParagrafi.size(); i++) {

                        Paragrafo temp = new Paragrafo(contenutoParagrafi.get(i), i, paginaTemporanea,  dataParagrafi.get(i), orariParagrafi.get(i));
                        String destinazione = null;

                        ImplementazionePostgresDAO.connectDAO();
                        ImplementazionePostgresDAO.cercaCollegamentisuDB(i, paginaTemporanea.titolo, destinazione);

                        if(destinazione != null)
                                temp.impostaCollegamento(new Collegamento(paginaTemporanea.titolo, destinazione));

                        testo.add(temp);
                }

                paginaTemporanea.testo = testo;
        }

        public void salvaValutazioneEVisita(int Valutazione)
        {
                ImplementazionePostgresDAO.connectDAO();
                ImplementazionePostgresDAO.MandaValutazioneEVisita( Valutazione, paginaTemporanea.titolo,utente.ottieniIdUtente());
        }

        public void impostaCollegamentoTemporaneo(String titoloPaginaDiDestinazione){

                collegamentoDaImplementare = new Collegamento(paginaTemporanea.titolo, titoloPaginaDiDestinazione);
        }

        public  HashMap<String,HashMap<Integer,ArrayList<String>>> ottieniListaStorici()
        {
                HashMap<String,HashMap<Integer,ArrayList<String>>> hashMapStorici;
                hashMapStorici = ImplementazionePostgresDAO.ottieniStoricoAutore(autoreLoggato.username);

                return hashMapStorici;
        }
        public Autore ottieniAutore()
        {
                return  autoreLoggato;
        }
        public Pagina ottieniPaginaTemporanea(){
                return paginaTemporanea;
        }
        public Collegamento ottieniCollegamentoTemporaneo(){return  collegamentoDaImplementare;}
        public void svuotaCollegamentoTemporaneo(){
                collegamentoDaImplementare = null;
        }

        public void scartaPagina() {

                ImplementazionePostgresDAO.rimuoviPaginaScartataDalDB(paginaTemporanea.titolo);
                paginaTemporanea = null;
        }

        public int ottieniPunteggioPagina() {

               return  ImplementazionePostgresDAO.ottieniPunteggioPagina(paginaTemporanea.titolo);
        }

        public String elaboraCodiceHtml() {

                String stringHTML = "<html>";

                for (Paragrafo par : paginaTemporanea.testo)
                {
                        if (par.ottienicollegamento() != null)
                        {
                                // Se il paragrafo possiede un collegamneto,
                                // allora viene creato un hypertext, il quale
                                //  consente la visualizzazione di un' altra pagina se cliccato.

                                stringHTML += "<a href = \"";
                                stringHTML += par.ottienicollegamento().titoloPaginaDiDestinazione;
                                stringHTML += "\">";
                                stringHTML += par.ottieniContenuto();
                                stringHTML += "</a>";

                        } else {

                                stringHTML += "<p style=\"background-color:White;\">";
                                stringHTML += par.ottieniContenuto();
                                stringHTML += "</p>";

                        }
                }

                stringHTML += "</html>";

                return stringHTML;
        }


        public String ottieniMessaggioTemporaneo()
        {
                return messaggioTemporaneo;
        }

        public void impostaMessaggioTemporaneo(String messaggio)
        {
                messaggioTemporaneo = messaggio;
        }
}
