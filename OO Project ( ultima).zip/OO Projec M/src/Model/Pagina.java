package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Pagina
{
    public String titolo;
    public Date   dataCreazione;
    private Autore proprietario;
    public String nomeAutore;
    public int valutazione;
    public ArrayList<Utente> visitatori = new ArrayList<>();
    public ArrayList<Paragrafo> testo = new ArrayList<>();
    public HashMap<Integer,ArrayList<Paragrafo>> storicoPagina = new HashMap<>();

    public Pagina(String titolo, Autore proprietario)
    {
        this.titolo = titolo;
        this.proprietario = proprietario;
        this.nomeAutore = proprietario.username;
        dataCreazione = new Date();
    }

    public Pagina(String titolo, String nomeAutore)
    {
        this.titolo = titolo;
        this.nomeAutore = nomeAutore;
    }

    public Autore ottieniAutore(){
        return this.proprietario;
    }
}
