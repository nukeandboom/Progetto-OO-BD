package Model;

public class Collegamento extends GestioneAnomalia
{
    public String titoloPaginaCorrente;
    public String titoloPaginaDiDestinazione;

    public Collegamento(String titoloPaginaCorrente, String titoloPaginaDiDestinazione)
    {
        this.titoloPaginaCorrente = titoloPaginaCorrente;
        this.titoloPaginaDiDestinazione = titoloPaginaDiDestinazione;
    }
}
